﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using FluentValidation;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PartialResponse.Extensions.DependencyInjection;
using Swashbuckle.AspNetCore.Swagger;
using TCS.HumanResourceManagement.Api.Filters;
using TCS.HumanResourceManagement.Api.MediatR;
using TCS.HumanResourceManagement.Api.Middlewares;
using TCS.HumanResourceManagement.Api.Swagger;
using TCS.HumanResourceManagement.Api.Validators;
using TCS.HumanResourceManagement.Business;
using TCS.HumanResourceManagement.Business.ApiClients;
using TCS.HumanResourceManagement.Business.ApiClients.PointOfSales;
using TCS.HumanResourceManagement.Business.Behaviours;
using TCS.HumanResourceManagement.Business.Constants;
using TCS.HumanResourceManagement.Business.Departments.AddNewDepartment;
using TCS.HumanResourceManagement.Business.Departments.GetAllDepartments;
using TCS.HumanResourceManagement.Business.Designations.AddNewDesignation;
using TCS.HumanResourceManagement.Business.Designations.GetAllDesignations;
using TCS.HumanResourceManagement.Business.Employees.AddNewEmployee;
using TCS.HumanResourceManagement.Business.Employees.AddOrUpdateDepartment;
using TCS.HumanResourceManagement.Business.Employees.AssignReportingManagerByEmployee;
using TCS.HumanResourceManagement.Business.Employees.EmployeeAsReportingManager;
using TCS.HumanResourceManagement.Business.Employees.EmployeePayroll;
using TCS.HumanResourceManagement.Business.Employees.GetAllEmployees;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeeAddreeses;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeeById;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeeExperience;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeeSalaryDetails;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeesByEmployeeCode;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.Business.Jobs.AddNewCandidate;
using TCS.HumanResourceManagement.Business.Jobs.CandidateSearch;
using TCS.HumanResourceManagement.Business.Jobs.GetCandidateByApplicationNumber;
using TCS.HumanResourceManagement.Business.Jobs.GetCandidates;
using TCS.HumanResourceManagement.Business.Jobs.OnRollCandidate;
using TCS.HumanResourceManagement.Business.Leaves.ApplyLeave;
using TCS.HumanResourceManagement.Business.Leaves.ApproveOrRejectLeave;
using TCS.HumanResourceManagement.Business.Leaves.GetAllEmployeeLeaves;
using TCS.HumanResourceManagement.Business.Leaves.GetAppliedLeaves;
using TCS.HumanResourceManagement.Business.Leaves.GetEmployeeLeavesById;
using TCS.HumanResourceManagement.Business.Leaves.GetLeaveTypes;
using TCS.HumanResourceManagement.Business.Model;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.EmployeeTimeAndAttendance;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.GetAttendanceSheet;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.GetOnDuties;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.GetTimeAndAttendance;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.OnDuty;
using TCS.HumanResourceManagement.Business.UploadData.EmployeeSalaryRevision;
using TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeBankAccountDetails;
using TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeDetails;
using TCS.HumanResourceManagement.Business.UploadData.UploadReportingManager;
using TCS.HumanResourceManagement.Business.Utilities;
using TCS.HumanResourceManagement.Business.Utilities.AgeCalculatorByDateOfBirth;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel;

namespace TCS.HumanResourceManagement.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging();

            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.Configure<AppSettings>(Configuration);

            services
               .AddMvc(options =>
               {
                   options.Filters.Add(typeof(ApiClientValidationExceptionAttribute));
                   options.Filters.Add(typeof(FluentValidationExceptionAttribute));
                   options.Filters.Add(typeof(ValidateModelAttribute));
                   options.Filters.Add(typeof(GlobalExceptionFilter));
                   options.OutputFormatters.RemoveType<JsonOutputFormatter>();
               })
               .AddPartialJsonFormatters()
               .SetCompatibilityVersion(CompatibilityVersion.Version_2_1);

            // Configure MediatR design pattern
            services.AddMediatR(typeof(AssemblyMaker));
            services.AddScoped<IMediator, SynchronousMediator>();

            // Configure Fluent Validation
            services.AddScoped(typeof(IPipelineBehavior<,>), typeof(ValidationBehaviour<,>));

            // Register the Swagger generator, defining 1 or more Swagger documents
            services.AddSwaggerGen(sw =>
            {
                sw.DescribeAllEnumsAsStrings();
                sw.DescribeStringEnumsInCamelCase();
                sw.DescribeAllParametersInCamelCase();

                // sw.SchemaFilter<FluentValidationSchemaFilter>();
                sw.SchemaFilter<DataTypeSchemaFilter>();

                sw.MapType<Guid>(() => new Schema
                {
                    Type = "string",
                    Format = "uuid",
                    Example = Guid.NewGuid().ToString(),
                    Pattern = "([0-9][a-f][A-F]){8}-(([0-9][a-f][A-F]){4}-){3}([0-9][a-f][A-F]){12}"
                });

                sw.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "TCS Human Resource Management API",
                    Description = "TCS Human Resource Management",
                    Contact = new Contact { Name = "The Chennai Silks,.", Email = "support@tcs.com" }
                });

                sw.AddSecurityDefinition("Bearer",
                new ApiKeyScheme
                {
                    In = "header",
                    Description = "Please enter into field the word 'Bearer' following by space and JWT",
                    Name = "Authorization",
                    Type = "apiKey"
                });
                sw.AddSecurityRequirement(new Dictionary<string, IEnumerable<string>> {
                { "Bearer", Enumerable.Empty<string>() },
                });

            });

            services.AddScoped<IAdminApiClient, AdminApiClient>(sp =>
                new AdminApiClient(
                    new Uri(Configuration.GetValue<string>("AdminApi:BaseAddress")),
                    sp.GetService<IHttpContextAccessor>()));

            services.AddScoped<IPointOfSalesApiClient, PointOfSalesApiClient>(sp =>
               new PointOfSalesApiClient(
                   new Uri(Configuration.GetValue<string>("PointOfSalesApi:BaseAddress")),
                   sp.GetService<IHttpContextAccessor>()));


            services.AddTransient<ICurrentUser, CurrentUser>();

            // Configuration for Cryptography
            services.AddScoped<ICryptographyHelper, CryptographyHelper>(cryptographyHelper => new CryptographyHelper
             (() => new AesManaged(),
              Configuration["EncryptionKey"],
              Configuration["VectorKey"]
              ));

            // Configure FluentValidation
            services.AddScoped<IValidator<AddNewEmployeeCommand>, AddNewEmployeeValidation>();
            services.AddScoped<IValidator<GetAllEmployeeQuery>, GetAllEmployeeValidation>();
            services.AddScoped<IValidator<ApplyLeaveCommand>, ApplyLeaveValidation>();
            services.AddScoped<IValidator<ApproveOrRejectLeaveCommand>, ApproveOrRejectLeaveValidation>();
            services.AddScoped<IValidator<GetEmployeeLeavesByIdQuery>, GetEmployeeLeavesByIdValidation>();
            services.AddScoped<IValidator<GetAllEmployeeLeavesQuery>, GetAllEmployeeLeavesValidation>();
            services.AddScoped<IValidator<AddNewDepartmentCommand>, AddNewDepartmentValidation>();
            services.AddScoped<IValidator<GetAllDepartmentsQuery>, GetAllDepartmentsValidation>();
            services.AddScoped<IValidator<AddOrUpdateDepartmentCommand>, AddOrUpdateDepartmentValidation>();
            services.AddScoped<IValidator<AgeCalculatorByDateOfBirthCommand>, AgeCalculatorByDateOfBirthValidation>();
            services.AddScoped<IValidator<EmployeeTimeAndAttendanceCommand>, EmployeeTimeAndAttendanceValidation>();
            services.AddScoped<IValidator<GetLeaveTypesQuery>, GetLeaveTypesValidation>();
            services.AddScoped<IValidator<EmployeeAsReportingManagerQuery>, EmployeeAsReportingManagerValidation>();
            services.AddScoped<IValidator<GetEmployeesByEmployeeCodeQuery>, GetEmployeesByEmployeeCodeValidation>();
            services.AddScoped<IValidator<GetEmployeeAddreesesQuery>, GetEmployeeAddreesesValidation>();
            services.AddScoped<IValidator<GetEmployeeExperienceQuery>, GetEmployeeExperienceValidation>();
            services.AddScoped<IValidator<GetEmployeeSalaryDetailsQuery>, GetEmployeeSalaryDetailsValidation>();
            services.AddScoped<IValidator<GetEmployeeByIdQuery>, GetEmployeeByIdValidation>();
            services.AddScoped<IValidator<AssignReportingManagerByEmployeeCommand>, AssignReportingManagerByEmployeeValidation>();
            services.AddScoped<IValidator<GetAppliedLeavesQuery>, GetAppliedLeavesValidation>();
            services.AddScoped<IValidator<GetTimeAndAttendanceQuery>, GetTimeAndAttendanceValidation>();
            services.AddScoped<IValidator<AddNewDesignationCommand>, AddNewDesignationValidation>();
            services.AddScoped<IValidator<GetAllDesignationsQuery>, GetAllDesignationsValidation>();
            services.AddScoped<IValidator<AddNewCandidateCommand>, AddNewCandidateValidation>();
            services.AddScoped<IValidator<GetCandidatesQuery>, GetCandidatesValidation>();
            services.AddScoped<IValidator<CandidateSearchQuery>, CandidateSearchValidation>();
            services.AddScoped<IValidator<GetCandidateByApplicationNumberCommand>, GetCandidateByApplicationNumberValidation>();
            services.AddScoped<IValidator<OnRollCandidatecommand>, OnRollCandidateValidation>();
            services.AddScoped<IValidator<UploadEmployeeDetailsCommand>, UploadEmployeeDetailsValidation>();
            services.AddScoped<IValidator<UploadEmployeeBankAccountDetailsCommand>, UploadEmployeeBankAccountDetailsValidation>();
            services.AddScoped<IValidator<UploadReportingManagerCommand>, UploadReportingManagerValidation>();
            services.AddScoped<IValidator<SalaryRevisionCommand>, SalaryRevisionValidation>();
            services.AddScoped<IValidator<EmployeePayrollQuery>, EmployeePayrollValidation>();
            services.AddScoped<IValidator<GetAttendanceSheetQuery>, GetAttendanceSheetValidation>();
            services.AddScoped<IValidator<OnDutyCommand>, OnDutyValidation>();
            services.AddScoped<IValidator<GetOnDutiesQuery>, GetOnDutiesValidation>();

            string jwtPublicKey = Configuration.GetValue<string>("JwtPublicKey");
            string authTokenIssuer = Configuration.GetValue<string>("AuthTokenIssuer");
            services.AddTransient<IJwtTokenValidator>(jwtTokenValidator => new JwtTokenValidator(jwtPublicKey, authTokenIssuer));

            services.AddAuthorization(options => options.AddPolicy(Policy.BearerOnly, policy => policy.Requirements.Add(new BearerTokenAttribute())));
            services.AddAuthorization(options => options.AddPolicy(Policy.TerritoryTokenHolderOnly, policy => policy.Requirements.Add(new TerritoryAuthorizeAttribute(Configuration.GetSection("TerritoryTokens").Get<TerritoryTokens[]>()))));

            services.AddDbContext<TCSHumanResourceManagementContext>(options => options.UseSqlServer(Configuration["ConnectionStrings:ConnectionString"]));
            services.AddScoped<IUnitOfWork, UnitOfWork>(ctx => new UnitOfWork(Configuration["ConnectionStrings:ConnectionString"]));

            var location = new Locations();
            Configuration.GetSection("TerritoryTokens").Bind(location);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseCors(builder => builder.WithOrigins(Configuration.GetSection("AllowedOrigins")
                .Get<string[]>())
                .AllowAnyHeader()
                .AllowAnyMethod());

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseMiddleware<AuthorizationMiddleware>();
            app.UseMvc();

            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Human.ResourceManagement.API - V1");
            });
        }
    }
}
