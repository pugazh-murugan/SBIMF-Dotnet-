﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Departments;

namespace TCS.HumanResourceManagement.Business.Departments.GetAllDepartments
{
    public class GetAllDepartmentsQuery : IRequest<List<Department>>
    {

    }
}
