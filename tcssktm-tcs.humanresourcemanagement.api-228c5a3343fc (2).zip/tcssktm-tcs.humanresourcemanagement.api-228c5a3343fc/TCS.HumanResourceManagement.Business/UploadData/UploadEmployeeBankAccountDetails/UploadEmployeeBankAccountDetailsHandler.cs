﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.Business.Model;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeBankAccountDetails
{
   public class UploadEmployeeBankAccountDetailsHandler : IRequestHandler<UploadEmployeeBankAccountDetailsCommand,List<UploadEmployeeDetailsResponse>>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        private readonly ICryptographyHelper cryptographyHelper;

        public UploadEmployeeBankAccountDetailsHandler(
           IUnitOfWork unitOfWork,
           ICurrentUser currentUser,
           ICryptographyHelper cryptographyHelper)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
            this.cryptographyHelper = cryptographyHelper;
        }

        public async Task<List<UploadEmployeeDetailsResponse>> Handle(UploadEmployeeBankAccountDetailsCommand requests, CancellationToken cancellationToken)
        {
            List<UploadEmployeeDetailsResponse> response = new List<UploadEmployeeDetailsResponse>();
            string employeeName = string.Empty;

            foreach (var request in requests.UploadEmployeeBankAccountDetails)
            {
                try
                {
                    var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);
                    if (employee != null)
                    {
                        employeeName = employee.FirstName;
                        var employeeBankAccount = new EmployeeBankAccounts()
                        {
                            Id = Guid.NewGuid(),
                            EmployeeId = employee.Id,
                            AccountantName = request.AccountantName,
                            AccountNumber = cryptographyHelper.Encrypt(request.AccountNumber),
                            BankName = cryptographyHelper.Encrypt(request.BankName),
                            IfscCode = cryptographyHelper.Encrypt(request.IfscCode),
                            CreatedBy = currentUser.UserId,
                            Created = DateTime.Now,
                            LastUpdatedBy = currentUser.UserId,
                            LastUpdated = DateTime.Now
                        };
                        await unitOfWork.EmployeeRepository.InserEmployeeBankAccount(employeeBankAccount);

                        response.Add(new UploadEmployeeDetailsResponse()
                        {
                            EmployeeCode = request.EmployeeCode,
                            EmployeeName = employeeName,
                            Status = 200
                        });
                    }
                    else
                    {
                        response.Add(new UploadEmployeeDetailsResponse()
                        {
                            EmployeeCode = request.EmployeeCode,
                            EmployeeName = employeeName,
                            Status = 500,
                            ErrorMessage="Does not exisit"
                        });
                    }
                }
                catch(Exception ex)
                {
                    response.Add(new UploadEmployeeDetailsResponse()
                    {
                        EmployeeCode = request.EmployeeCode,
                        EmployeeName = employeeName,
                        Status = 500,
                        ErrorMessage = ex.Message
                    });
                }
            }

            unitOfWork.Commit();
            return response;
        }
    }
}
