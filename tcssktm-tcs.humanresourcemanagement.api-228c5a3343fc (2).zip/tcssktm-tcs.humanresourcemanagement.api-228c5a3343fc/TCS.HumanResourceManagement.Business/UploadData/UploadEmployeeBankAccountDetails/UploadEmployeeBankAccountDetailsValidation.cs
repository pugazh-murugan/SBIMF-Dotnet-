﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeBankAccountDetails
{
    public class UploadEmployeeBankAccountDetailsValidation : AbstractValidator<UploadEmployeeBankAccountDetailsCommand>
    {
        public UploadEmployeeBankAccountDetailsValidation()
        {

        }
    }
}
