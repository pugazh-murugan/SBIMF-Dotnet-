﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeBankAccountDetails
{
    public class UploadEmployeeBankAccountDetailsCommand : IRequest<List<UploadEmployeeDetailsResponse>>
    {
        public List<Model.UploadEmployeeBankAccountDetails> UploadEmployeeBankAccountDetails { get; set; }
    }
}
