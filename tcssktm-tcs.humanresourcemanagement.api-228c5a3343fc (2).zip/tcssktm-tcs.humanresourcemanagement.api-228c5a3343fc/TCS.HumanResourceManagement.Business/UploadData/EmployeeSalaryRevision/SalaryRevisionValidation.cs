﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;

namespace TCS.HumanResourceManagement.Business.UploadData.EmployeeSalaryRevision
{
    public class SalaryRevisionValidation : AbstractValidator<SalaryRevisionCommand>
    {
        public SalaryRevisionValidation()
        {
            RuleForEach(x => x.SalaryRevisions).SetValidator(new SalaryRevisionValidator());
        }
    }
}
