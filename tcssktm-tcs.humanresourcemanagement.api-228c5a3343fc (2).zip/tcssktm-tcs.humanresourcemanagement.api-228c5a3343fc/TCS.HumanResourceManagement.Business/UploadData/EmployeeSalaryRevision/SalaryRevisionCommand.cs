﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.UploadData.EmployeeSalaryRevision
{
    public class SalaryRevisionCommand : IRequest
    {
        public List<SalaryRevision> SalaryRevisions { get; set; }
    }
}
