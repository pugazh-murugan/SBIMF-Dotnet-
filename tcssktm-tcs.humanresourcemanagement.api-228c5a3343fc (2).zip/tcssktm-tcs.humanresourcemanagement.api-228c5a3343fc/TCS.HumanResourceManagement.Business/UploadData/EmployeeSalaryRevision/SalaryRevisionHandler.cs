﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Designations;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.UploadData.EmployeeSalaryRevision
{
    public class SalaryRevisionHandler : IRequestHandler<SalaryRevisionCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        public SalaryRevisionHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<Unit> Handle(SalaryRevisionCommand request, CancellationToken cancellationToken)
        {
            var existingDesignations = await unitOfWork.DesignationRepository.GetAll();
            var employees = await unitOfWork.EmployeeRepository.GetAllEmployees();

            var newDesignations = request.SalaryRevisions.GroupBy(c => c.Designation).Select(c => c.Key).ToArray().Except(existingDesignations.Select(c => c.Description).ToArray());
            if (newDesignations.Any())
            {
                foreach (var designation in newDesignations)
                {
                    var newDesignation = new Designation()
                    {
                        Id = Guid.NewGuid(),
                        Code = designation,
                        Description = designation,
                        Status = true,
                        Created = DateTime.Now,
                        CreatedBy = currentUser.UserId,
                        LastUpdated = DateTime.Now,
                        LastUpdatedBy = currentUser.UserId
                    };
                    await unitOfWork.DesignationRepository.CreateNewDesignation(newDesignation);
                    existingDesignations.Add(newDesignation);
                }
            }

            foreach(var emploeeDetails in request.SalaryRevisions)
            {
                var employee = employees.FirstOrDefault(c => c.EmployeeCode.Equals(emploeeDetails.EmployeeCode));

                if(employee != null)
                {
                    var employeeDetail = new EmployeeDetails()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = employee.Id,
                        Designation = existingDesignations.FirstOrDefault(c => c.Description.Equals(emploeeDetails.Designation, StringComparison.OrdinalIgnoreCase)).Id,
                        BasicSalary = emploeeDetails.BasicSalary,
                        HRA = emploeeDetails.HRA,
                        PF = emploeeDetails.PF,
                        DA = emploeeDetails.DA,
                        SpecialAllowance = emploeeDetails.SpecialAllowance,
                        FoodAllowance = emploeeDetails.FoodAllowance,
                        CarAllowance = emploeeDetails.CarAllowance,
                        MedicalAllowance = emploeeDetails.MedicalAllowance,
                        MobileAllowance = emploeeDetails.MobileAllowance,
                        DepartmentId = null,
                        CreatedBy = currentUser.UserId,
                        Created = DateTime.Now,
                        LastUpdatedBy = currentUser.UserId,
                        LastUpdated = DateTime.Now
                    };
                    await unitOfWork.EmployeeRepository.CreateNewEmployeeDetails(employeeDetail);
                }
            }
            unitOfWork.Commit();

            return Unit.Value;
        }
    }
}
