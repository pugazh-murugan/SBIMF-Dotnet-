﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.Business.Model;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadReportingManager
{
    public class UploadReportingManagerHandler : IRequestHandler<UploadReportingManagerCommand, List<UploadEmployeeDetailsResponse>>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        public UploadReportingManagerHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }


        public async Task<List<UploadEmployeeDetailsResponse>> Handle(UploadReportingManagerCommand requests, CancellationToken cancellationToken)
        {
            List<UploadEmployeeDetailsResponse> response = new List<UploadEmployeeDetailsResponse>();

            foreach (var request in requests.UploadReportingManagers)
            {
                var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);
                var reportingManager = await unitOfWork.EmployeeRepository.GetEmployee(request.SupervisorCode);
                var floorHead = await unitOfWork.EmployeeRepository.GetEmployee(request.FloorHeadCode);

                if (employee != null && reportingManager!=null)
                {
                    await unitOfWork.EmployeeRepository.AssignReportingManagerToEmployee(employee.Id, reportingManager.Id, currentUser.UserId);

                    response.Add(new UploadEmployeeDetailsResponse()
                    {
                        EmployeeCode = string.Format("Employee : {0}, assign to Supervisor : {1}", request.EmployeeCode, request.SupervisorCode),
                        EmployeeName = string.Empty,
                        Status = 200
                    });
                }
                else
                {
                    response.Add(new UploadEmployeeDetailsResponse()
                    {
                        EmployeeCode = string.Format("Employee : {0}, Supervisor : {1}", request.EmployeeCode, request.SupervisorCode),
                        EmployeeName = string.Empty,
                        Status = 500,
                        ErrorMessage = "Either employee or supervisor does not exisit"
                    });
                }

                if (reportingManager != null && floorHead != null)
                {
                    await unitOfWork.EmployeeRepository.AssignReportingManagerToEmployee(reportingManager.Id, floorHead.Id, currentUser.UserId);

                    response.Add(new UploadEmployeeDetailsResponse()
                    {
                        EmployeeCode = string.Format("Supervisor : {0}, assign to Floor Head : {1}", request.SupervisorCode, request.FloorHeadCode),
                        EmployeeName = string.Empty,
                        Status = 200
                    });
                }
                else
                {
                    response.Add(new UploadEmployeeDetailsResponse()
                    {
                        EmployeeCode = string.Format("Supervisor : {0}, Floor Head : {1}", request.SupervisorCode, request.FloorHeadCode),
                        EmployeeName = string.Empty,
                        Status = 500,
                        ErrorMessage = "Either employee or supervisor does not exisit"
                    });
                }
            }
            unitOfWork.Commit();
            return response;
        }
    }
}
