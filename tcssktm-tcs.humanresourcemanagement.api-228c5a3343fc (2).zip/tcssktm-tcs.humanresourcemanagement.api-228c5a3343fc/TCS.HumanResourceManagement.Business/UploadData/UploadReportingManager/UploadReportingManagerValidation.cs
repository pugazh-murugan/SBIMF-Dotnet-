﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadReportingManager
{
    public class UploadReportingManagerValidation : AbstractValidator<UploadReportingManagerCommand>
    {
        public UploadReportingManagerValidation()
        {

        }
    }
}
