﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadReportingManager
{
    public class UploadReportingManagerCommand : IRequest<List<UploadEmployeeDetailsResponse>>
    {
        public List<Model.UploadReportingManager> UploadReportingManagers { get; set; }
    }
}
