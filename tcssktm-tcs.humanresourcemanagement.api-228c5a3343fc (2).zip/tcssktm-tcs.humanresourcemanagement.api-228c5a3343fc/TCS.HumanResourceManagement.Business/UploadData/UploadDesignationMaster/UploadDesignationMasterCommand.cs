﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadDesignationMaster
{
    class UploadDesignationMasterCommand
    {
    }
}
