﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.ApiClients;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.Business.Model;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeDetails
{
    public class UploadEmployeeDetailsHandler : IRequestHandler<UploadEmployeeDetailsCommand, List<UploadEmployeeDetailsResponse>>
    {
        private readonly IUnitOfWork unitOfWork;

        private ICurrentUser currentUser;

        private readonly IAdminApiClient adminApiClient;

        private readonly ICryptographyHelper cryptographyHelper;

        public UploadEmployeeDetailsHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser,
            IAdminApiClient adminApiClient,
            ICryptographyHelper cryptographyHelper)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
            this.adminApiClient = adminApiClient;
            this.cryptographyHelper = cryptographyHelper;
        }

        public async Task<List<UploadEmployeeDetailsResponse>> Handle(UploadEmployeeDetailsCommand requests, CancellationToken cancellationToken)
        {
            List<UploadEmployeeDetailsResponse> response = new List<UploadEmployeeDetailsResponse>();

            var branches = await adminApiClient.GetBranches();

            foreach (var request in requests.UploadEmployeeDetails)
            {
                try
                {
                    var employee = new DataModel.Model.Employees.Employee()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeCode = request.EmployeeCode,
                        FirstName = request.EmployeeName,
                        LastName = request.FatherName,
                        Gender = string.Empty,
                        Branch = branches.FirstOrDefault(c => c.Code.Equals(request.Branch, StringComparison.OrdinalIgnoreCase)).Id,
                        PersonalEmail = string.Empty,
                        OfficialEmail = string.Empty,
                        PANNumber = cryptographyHelper.Encrypt(request.EmployeeCode),
                        AadharNumber = cryptographyHelper.Encrypt(request.EmployeeCode),
                        MobileNumber = request.Mobile,
                        IsMobileNumberVerified = false,
                        AlternateNumber = string.Empty,
                        DateOfBirth = request.DateOfBirth,
                        DateOfJoin = request.DateOfJoin,
                        ReportingManageId = null,
                        IsMarried = request.MaritalStatus.Equals("MARRIED", StringComparison.OrdinalIgnoreCase) ? true : false,
                        SpouseName = string.Empty,
                        HaveChild = false,
                        NumberOfChild = 0,
                        IsActive = true,
                        IsExitInitiated = false,
                        CreatedBy = currentUser.UserId,
                        Created = DateTime.Now,
                        LastUpdatedBy = currentUser.UserId,
                        LastUpdated = DateTime.Now,
                        EmployeeAddresses = null,
                        EmployeeDetails = null,
                        ReportingManger = null,
                        EmployeeBankAccount = null,
                    };

                    await unitOfWork.EmployeeRepository.CreateNewEmployee(employee);
                    await unitOfWork.LeaveRepository.InitLeaves(employee.Id, currentUser.UserId, CalculateCasualLeave.InitCasualLeave(request.DateOfJoin));

                    await adminApiClient.PostUser(new Model.PostUserRequest()
                    {
                        DisplayName = request.EmployeeName,
                        UserName = employee.EmployeeCode,
                        Password = employee.EmployeeCode,
                        Avatar = string.Empty,
                        IsActive = true,
                        UserId = currentUser.UserId
                    });

                    response.Add(new UploadEmployeeDetailsResponse()
                    {
                        EmployeeCode = request.EmployeeCode,
                        EmployeeName = request.EmployeeName,
                        Status = 200
                    });
                }
                catch (Exception ex)
                {
                    response.Add(new UploadEmployeeDetailsResponse()
                    {
                        EmployeeCode = request.EmployeeCode,
                        EmployeeName = request.EmployeeName,
                        Status = 500,
                        ErrorMessage = ex.Message
                    });
                }

            }

            unitOfWork.Commit();
            return response;
        }
    }
}
