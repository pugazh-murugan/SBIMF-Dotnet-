﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeDetails
{
    public class UploadEmployeeDetailsCommand :  IRequest<List<UploadEmployeeDetailsResponse>>
    {
        public List<Model.UploadEmployeeDetails> UploadEmployeeDetails { get; set; }
    }
}
