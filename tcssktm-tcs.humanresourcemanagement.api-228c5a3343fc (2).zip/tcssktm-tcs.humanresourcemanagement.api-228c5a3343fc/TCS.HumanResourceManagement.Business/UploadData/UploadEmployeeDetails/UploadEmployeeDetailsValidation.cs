﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeDetails
{
    public class UploadEmployeeDetailsValidation : AbstractValidator<UploadEmployeeDetailsCommand>
    {
        public UploadEmployeeDetailsValidation()
        {

        }
    }
}
