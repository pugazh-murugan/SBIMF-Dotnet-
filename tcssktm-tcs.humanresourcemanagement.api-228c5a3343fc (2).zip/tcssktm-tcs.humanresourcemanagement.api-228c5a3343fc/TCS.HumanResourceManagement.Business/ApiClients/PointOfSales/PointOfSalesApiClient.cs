﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.ApiClients.PointOfSales
{
    public class PointOfSalesApiClient : IPointOfSalesApiClient
    {
        private readonly IHttpContextAccessor httpContextAccessor;

        private Uri BaseAddress { get; }

        public PointOfSalesApiClient(Uri baseAddress, IHttpContextAccessor httpContextAccessor)
        {
            BaseAddress = baseAddress;
            this.httpContextAccessor = httpContextAccessor;
        }

        public async Task<List<AssociatePayrollModel>> GetAssociateSalesForPayroll(string monthOfPayroll, string associateCode)
        {
            var client = new HttpClient { BaseAddress = BaseAddress };

            var authorizationRequestHeader = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            if (authorizationRequestHeader.Any())
            {
                client.DefaultRequestHeaders.Authorization = AuthenticationHeaderValue.Parse(authorizationRequestHeader);
            }

            using (var response = await client.GetAsync($"api/sales/getassociatesalesforpayroll?MonthOfPayroll={monthOfPayroll}&AssociateCode={associateCode}"))
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApiClientException(response);
                }

                string content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<List<AssociatePayrollModel>>(content);
                return result;
            }
        }

        public async Task<List<SalesAssociates>> GetAllAssociates()
        {
            var client = new HttpClient { BaseAddress = BaseAddress };

            var authorizationRequestHeader = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            if (authorizationRequestHeader.Any())
            {
                client.DefaultRequestHeaders.Authorization = AuthenticationHeaderValue.Parse(authorizationRequestHeader);
            }

            using (var response = await client.GetAsync($"api/associate/getallassociates"))
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApiClientException(response);
                }

                string content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<List<SalesAssociates>>(content);
                return result;
            }
        }

    }
}
