﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.ApiClients.PointOfSales
{
    public interface IPointOfSalesApiClient
    {
        Task<List<AssociatePayrollModel>> GetAssociateSalesForPayroll(string monthOfPayroll, string associateCode);

        Task<List<SalesAssociates>> GetAllAssociates();
    }
}
