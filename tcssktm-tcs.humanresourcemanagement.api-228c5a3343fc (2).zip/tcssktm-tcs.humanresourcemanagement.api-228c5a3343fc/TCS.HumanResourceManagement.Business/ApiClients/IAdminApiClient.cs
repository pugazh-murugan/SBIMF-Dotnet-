﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.ApiClients
{
    public interface IAdminApiClient
    {
        Task PostUser(PostUserRequest user);

        Task<List<Branches>> GetBranches();
    }
}
