﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.ApiClients
{
    public class AdminApiClient : IAdminApiClient
    {
        private readonly IHttpContextAccessor httpContextAccessor;

        private Uri BaseAddress { get; }

        public AdminApiClient(Uri baseAddress, IHttpContextAccessor httpContextAccessor)
        {
            BaseAddress = baseAddress;
            this.httpContextAccessor = httpContextAccessor;
        }

        public async Task PostUser(PostUserRequest user)
        {
            var client = new HttpClient { BaseAddress = BaseAddress };

            var authorizationRequestHeader = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            if (authorizationRequestHeader.Any())
            {
                client.DefaultRequestHeaders.Authorization = AuthenticationHeaderValue.Parse(authorizationRequestHeader);
            }

            var response = await client.PostAsync("api/user/newuser", new StringContent(JsonConvert.SerializeObject(user), Encoding.UTF8, "application/json"));

            if (response.StatusCode != HttpStatusCode.OK && response.StatusCode != HttpStatusCode.Created)
            {
                throw new ApiClientException(response);
            }
        }

        public async Task<List<Branches>> GetBranches()
        {
            var client = new HttpClient { BaseAddress = BaseAddress };

            var authorizationRequestHeader = httpContextAccessor.HttpContext.Request.Headers["Authorization"];
            if (authorizationRequestHeader.Any())
            {
                client.DefaultRequestHeaders.Authorization = AuthenticationHeaderValue.Parse(authorizationRequestHeader);
            }

            using (var response = await client.GetAsync("api/location/getallbranches"))
            {
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    throw new ApiClientException(response);
                }

                string content = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<List<Branches>>(content);
                return result;
            }

        }
    }
}
