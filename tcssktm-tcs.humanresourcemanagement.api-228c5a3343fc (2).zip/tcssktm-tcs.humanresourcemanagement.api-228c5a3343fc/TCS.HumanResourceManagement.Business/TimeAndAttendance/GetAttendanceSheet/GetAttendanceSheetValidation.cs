﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.GetAttendanceSheet
{
    public class GetAttendanceSheetValidation : AbstractValidator<GetAttendanceSheetQuery>
    {
        public GetAttendanceSheetValidation()
        {

        }
    }
}
