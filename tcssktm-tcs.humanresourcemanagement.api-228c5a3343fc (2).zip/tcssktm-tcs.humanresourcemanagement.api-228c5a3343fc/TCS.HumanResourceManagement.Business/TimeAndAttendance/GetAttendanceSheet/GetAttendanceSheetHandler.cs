﻿using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.ApiClients;
using TCS.HumanResourceManagement.Business.ApiClients.PointOfSales;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.GetAttendanceSheet
{
    public class GetAttendanceSheetHandler : IRequestHandler<GetAttendanceSheetQuery, List<AttendanceSheet>>
    {
        private readonly IUnitOfWork unitOfWork;

        public readonly IPointOfSalesApiClient pointOfSalesApiClient;

        private readonly IAdminApiClient adminApiClient;

        public GetAttendanceSheetHandler(
            IUnitOfWork unitOfWork,
            IPointOfSalesApiClient pointOfSalesApiClient,
            IAdminApiClient adminApiClient)
        {
            this.unitOfWork = unitOfWork;
            this.pointOfSalesApiClient = pointOfSalesApiClient;
            this.adminApiClient = adminApiClient;
        }

        public async Task<List<AttendanceSheet>> Handle(GetAttendanceSheetQuery request, CancellationToken cancellationToken)
        {
            List<AttendanceSheet> attendanceSheets = new List<AttendanceSheet>();

            var employees = request.Branch.HasValue
                ? await unitOfWork.EmployeeRepository.GetEmployeeByBranch(request.Branch.Value)
                : await unitOfWork.EmployeeRepository.GetEmployees();

            var salesAssociates = await pointOfSalesApiClient.GetAllAssociates();
            var branches = await adminApiClient.GetBranches();

            foreach (var employee in employees)
            {
                var section = salesAssociates.FirstOrDefault(c => c.AssociateCode == employee.EmployeeCode);

                attendanceSheets.Add(new AttendanceSheet()
                {
                    EmployeeCode = employee.EmployeeCode,
                    FirstName = employee.FirstName,
                    LastName = employee.LastName,
                    Branch = branches.FirstOrDefault(c => c.Id == employee.Branch).Name,
                    Section = section != null ? section.Description : "OTHERS"
                });
            }

            return attendanceSheets.OrderBy(c => c.Section).ThenBy(c => c.EmployeeCode).ToList();
        }
    }
}
