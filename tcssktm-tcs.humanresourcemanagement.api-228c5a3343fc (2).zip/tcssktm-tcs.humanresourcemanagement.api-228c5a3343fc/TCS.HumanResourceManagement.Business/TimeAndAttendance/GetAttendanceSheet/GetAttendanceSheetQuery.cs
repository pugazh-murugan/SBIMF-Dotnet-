﻿using System;
using System.Collections.Generic;
using System.Text;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.GetAttendanceSheet
{
    public class GetAttendanceSheetQuery : IRequest<List<AttendanceSheet>>
    {
       public Guid? Branch { get; set; }
    }
}
