﻿using System;
using MediatR;
using TCS.HumanResourceManagement.Business.Enums;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.EmployeeTimeAndAttendance
{
    public class EmployeeTimeAndAttendanceCommand : IRequest, IEmployeeCode
    {
        public string EmployeeCode { get; set; }

        public DateTime PunchInOrOutTime { get; set; }

        public string BioMetricIP { get; set; }

        public string BioMetricSerialNumber { get; set; }

        public Guid LocationId { get; set; }

        public PunchTypes PunchType { get; set; }

        public bool IsManual { get; set; } = false;

        public string Remarks { get; set; }

    }
}
