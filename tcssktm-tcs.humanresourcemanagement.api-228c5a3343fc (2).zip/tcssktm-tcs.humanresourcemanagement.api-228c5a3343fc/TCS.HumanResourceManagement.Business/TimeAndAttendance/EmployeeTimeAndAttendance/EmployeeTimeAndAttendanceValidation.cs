﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;
using TCS.HumanResourceManagement.Business.Enums;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.EmployeeTimeAndAttendance
{
    public class EmployeeTimeAndAttendanceValidation : AbstractValidator<EmployeeTimeAndAttendanceCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        public EmployeeTimeAndAttendanceValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            RuleFor(c => c.EmployeeCode)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.LocationId)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank")
                .When(c => !c.IsManual);

            this.IsEmployeeCodeNotExist(unitOfWork);

            RuleFor(c => c.Remarks)
               .NotNull()
               .WithMessage(command => "{PropertyName} should not be blank")
               .When(c => c.IsManual);

            RuleFor(c => c.PunchInOrOutTime)
               .NotNull()
               .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.PunchInOrOutTime)
               .LessThanOrEqualTo(DateTime.Now)
               .WithMessage(command => "{PropertyName} should be today date")
               .When(c => c.IsManual);

            RuleFor(c => c.PunchType)
               .NotNull()
               .IsInEnum()
               .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.PunchType)
               .NotNull()
                .MustAsync(async (command, punchType, _) => !await unitOfWork.TimeAndAttendanceRepository.IsEmployeeAlreadyInOrOutByDate(command.EmployeeCode, punchType.ToString(), command.PunchInOrOutTime.StartOfDay(), command.PunchInOrOutTime.EndOfDay()))
               .WithMessage(command => "{PropertyName} - The employee not yet punch IN. So there is no record for found punch {PropertyValue}.")
               .When(c => c.PunchType == PunchTypes.OUT);

            RuleFor(c => c.PunchType)
               .NotNull()
                .MustAsync(async (command, punchType, _) => !await unitOfWork.TimeAndAttendanceRepository.IsEmployeeAlreadyInOrOutByDate(command.EmployeeCode, punchType.ToString(), command.PunchInOrOutTime.StartOfDay(), command.PunchInOrOutTime.EndOfDay()))
               .WithMessage(command => "{PropertyName} - Already employee done punch {PropertyValue}. So the system won't be allow punch {PropertyValue} again.")
               .When(c => c.PunchType == PunchTypes.IN);
        }
    }
}
