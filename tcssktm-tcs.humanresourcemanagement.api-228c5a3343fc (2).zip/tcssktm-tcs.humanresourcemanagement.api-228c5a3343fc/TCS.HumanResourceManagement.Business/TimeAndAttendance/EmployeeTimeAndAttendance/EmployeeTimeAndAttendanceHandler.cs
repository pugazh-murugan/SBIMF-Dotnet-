﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.EmployeeTimeAndAttendance
{
    public class EmployeeTimeAndAttendanceHandler : IRequestHandler<EmployeeTimeAndAttendanceCommand>
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly ICurrentUser currentUser;

        public EmployeeTimeAndAttendanceHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<Unit> Handle(EmployeeTimeAndAttendanceCommand request, CancellationToken cancellationToken)
        {
            var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);

            var employeeAttendance = new EmployeeAttendance()
            {
                Id = Guid.NewGuid(),
                EmployeeId = employee.Id,
                InTime = (int)request.PunchType == 0 ? request.PunchInOrOutTime : (DateTime?)null,
                OutTime = (int)request.PunchType == 1 ? request.PunchInOrOutTime : (DateTime?)null,
                BioMetricIP = request.BioMetricIP,
                DeviceSerialNumber = request.BioMetricSerialNumber,
                PunchType = Convert.ToString(request.PunchType),
                IsManual = request.IsManual,
                Remarks = request.Remarks,
                LocationId = request.LocationId,
                CreatedBy = request.IsManual ? currentUser.UserId : employee.Id,
                Created = DateTime.Now,
                LastUpdatedBy = request.IsManual ? currentUser.UserId : employee.Id,
                LastUpdated = DateTime.Now
            };

            await unitOfWork.TimeAndAttendanceRepository.InsertOrUpdateTimeAndAttendance(employeeAttendance);

            if ((int)request.PunchType == 0)
            {
                var employeeOnDuty = await unitOfWork.TimeAndAttendanceRepository.EmployeeOnDuty(
                   employeeId: employee.Id,
                   fromDate: request.PunchInOrOutTime.StartOfDay(),
                   toDate: request.PunchInOrOutTime.EndOfDay());

                if (employeeOnDuty != null)
                    await unitOfWork.TimeAndAttendanceRepository.UpdateOnDutyPresent(isPresent: true, onDutyId: employeeOnDuty.Id);
            }

            unitOfWork.Commit();
            return Unit.Value;
        }
    }
}
