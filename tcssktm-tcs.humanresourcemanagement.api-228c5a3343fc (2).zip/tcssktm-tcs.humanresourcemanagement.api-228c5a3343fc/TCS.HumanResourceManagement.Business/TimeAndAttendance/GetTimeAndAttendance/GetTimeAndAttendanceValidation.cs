﻿using FluentValidation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.GetTimeAndAttendance
{
    public class GetTimeAndAttendanceValidation : AbstractValidator<GetTimeAndAttendanceQuery>
    {
        public GetTimeAndAttendanceValidation(IUnitOfWork unitOfWork)
        {
            RuleFor(c => c.EmployeeCode)
               .MustAsync(async (employeeCode, _) => await unitOfWork.EmployeeRepository.IsExist(employeeCode))
               .WithMessage(command => "{PropertyName} does not exist")
               .When(c => !string.IsNullOrEmpty(c.EmployeeCode));

            RuleFor(c => c.FromDate)
               .NotNull()
               .WithMessage(command => "{PropertyName} should not be blank.")
               .When(c => c.ToDate.HasValue);

            RuleFor(c => c.ToDate)
               .NotNull()
               .WithMessage(command => "{PropertyName} should not be blank.")
               .GreaterThanOrEqualTo(m => m.FromDate)
               .WithMessage(command => "{PropertyName} must after From date")
               .When(c => c.FromDate.HasValue);
        }
    }
}
