﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.ApiClients.PointOfSales;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.GetTimeAndAttendance
{
    public class GetTimeAndAttendanceHandler : IRequestHandler<GetTimeAndAttendanceQuery, List<ViewTimeAndAttendance>>
    {
        private readonly IUnitOfWork unitOfWork;

        public readonly IPointOfSalesApiClient pointOfSalesApiClient;

        public GetTimeAndAttendanceHandler(
            IUnitOfWork unitOfWork,
            IPointOfSalesApiClient pointOfSalesApiClient)
        {
            this.unitOfWork = unitOfWork;
            this.pointOfSalesApiClient = pointOfSalesApiClient;
        }

        public async Task<List<ViewTimeAndAttendance>> Handle(GetTimeAndAttendanceQuery request, CancellationToken cancellationToken)
        {
            var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);
            var salesAssociates = await pointOfSalesApiClient.GetAllAssociates();

            var result = await unitOfWork.TimeAndAttendanceRepository.ViewTimeAndAttendance
                (
                employeeId: employee != null ? employee.Id : (Guid?)null,
                fromDate: request.FromDate.Value.StartOfDay(),
                toDate: request.ToDate.Value.EndOfDay(),
                location: request.Location
                );

            foreach (var salesAssociate in salesAssociates)
            {
                foreach (var emp in result.Where(c => c.EmployeeCode == salesAssociate.AssociateCode))
                {
                    emp.Section = salesAssociate.Description;
                }
            }

            if (request.IsSectionWise)
            {
                return result.OrderBy(c => c.Section).ThenBy(c => c.EmployeeCode).ToList();
            }

            return result;
        }
    }
}
