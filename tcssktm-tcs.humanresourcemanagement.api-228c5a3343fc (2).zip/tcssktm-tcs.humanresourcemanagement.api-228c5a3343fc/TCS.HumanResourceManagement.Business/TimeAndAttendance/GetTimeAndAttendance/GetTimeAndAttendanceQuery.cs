﻿using System;
using System.Collections.Generic;
using System.Text;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.GetTimeAndAttendance
{
    public class GetTimeAndAttendanceQuery : IRequest<List<ViewTimeAndAttendance>>, IEmployeeCode
    {
        public string EmployeeCode { get; set; }

        public DateTime? FromDate { get; set; }

        public DateTime? ToDate { get; set; }

        public Guid? Location { get; set; }

        public bool IsSectionWise { get; set; }

    }
}
