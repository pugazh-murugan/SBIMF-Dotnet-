﻿using System;
using System.Collections.Generic;
using System.Text;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.OnDuty
{
    public class OnDutyCommand :IRequest, IEmployeeCode
    {
        public string EmployeeCode { get; set; }

        public Guid Branch { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public string Reason { get; set; }
    }
}
