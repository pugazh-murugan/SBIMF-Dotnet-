﻿using System;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.OnDuty
{
    public class OnDutyHandler : IRequestHandler<OnDutyCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        public OnDutyHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser
            )
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<Unit> Handle(OnDutyCommand request, CancellationToken cancellationToken)
        {
            var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);

            var onDuties = new OnDuties()
            {
                Id = Guid.NewGuid(),
                EmployeeId = employee.Id,
                FromDate = request.FromDate.StartOfDay(),
                ToDate = request.ToDate.EndOfDay(),
                Branch = request.Branch,
                Reason = request.Reason,
                CreatedBy = currentUser.UserId,
                Created = DateTime.Now,
                LastUpdated = DateTime.Now,
                LastUpdatedBy = currentUser.UserId
            };

            await unitOfWork.TimeAndAttendanceRepository.InsertOndutyEntry(onDuties);
            unitOfWork.Commit();
            return Unit.Value;
        }
    }
}
