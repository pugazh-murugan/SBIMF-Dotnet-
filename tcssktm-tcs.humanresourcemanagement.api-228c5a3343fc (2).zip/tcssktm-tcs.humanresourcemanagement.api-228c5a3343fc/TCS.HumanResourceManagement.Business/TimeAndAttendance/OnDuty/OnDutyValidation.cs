﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.OnDuty
{
    public class OnDutyValidation : AbstractValidator<OnDutyCommand>
    {
        public OnDutyValidation(IUnitOfWork unitOfWork)
        {
            this.IsEmployeeCodeNotExist(unitOfWork);
        }
    }
}
