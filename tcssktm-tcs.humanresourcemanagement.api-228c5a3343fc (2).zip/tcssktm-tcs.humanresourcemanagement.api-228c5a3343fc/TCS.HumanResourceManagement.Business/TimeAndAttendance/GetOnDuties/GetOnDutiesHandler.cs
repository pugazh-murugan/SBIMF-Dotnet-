﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.GetOnDuties
{
    public class GetOnDutiesHandler : IRequestHandler<GetOnDutiesQuery, List<OnDutiesViewModel>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetOnDutiesHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<List<OnDutiesViewModel>> Handle(GetOnDutiesQuery request, CancellationToken cancellationToken)
        {
            var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);
            var result = await unitOfWork.TimeAndAttendanceRepository.GetOnDuties(request.Branch, request.FromDate.StartOfDay(), request.ToDate.EndOfDay(), employee != null ? employee.Id : (Guid?)null);
            return result;

        }
    }
}
