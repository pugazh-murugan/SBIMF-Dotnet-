﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.TimeAndAttendance.GetOnDuties
{
    public class GetOnDutiesValidation : AbstractValidator<GetOnDutiesQuery>
    {
        public GetOnDutiesValidation(IUnitOfWork unitOfWork)
        {
            When(c => !string.IsNullOrEmpty(c.EmployeeCode), () =>
            {
                this.IsEmployeeCodeNotExist(unitOfWork);
            });
            
        }
    }
}
