﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Departments.GetAllDepartments
{
    public class GetAllDepartmentsValidation : AbstractValidator<GetAllDepartmentsQuery>
    {
        public GetAllDepartmentsValidation()
        {

        }
    }
}
