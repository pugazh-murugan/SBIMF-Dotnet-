﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Departments;

namespace TCS.HumanResourceManagement.Business.Departments.GetAllDepartments
{
    public class GetAllDepartmentsQuery : IRequest<pagenationResponse>
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
