﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Departments;

namespace TCS.HumanResourceManagement.Business.Departments.GetAllDepartments
{
    public class GetAllDepartmentsHandler : IRequestHandler<GetAllDepartmentsQuery, pagenationResponse>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetAllDepartmentsHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<pagenationResponse> Handle(GetAllDepartmentsQuery request, CancellationToken cancellationToken)
        {
            var data = new  pagenationResquest()
            {
                PageSize = request.PageSize,
                PageNumber= request.PageNumber,
            };
            var result = await unitOfWork.DepartmentRepository.GetAll(data);
            return result;
        }
    }
}
