﻿using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Departments.AddNewDepartment
{
    public class AddNewDepartmentCommand : IRequest, IDepartmentCode
    {
        public string Code { get; set; }

        public string Description { get; set; }

        public bool Status { get; set; }
    }
}
