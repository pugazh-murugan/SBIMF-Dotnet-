﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Departments.AddNewDepartment
{
    public class AddNewDepartmentValidation : AbstractValidator<AddNewDepartmentCommand>
    {
        public AddNewDepartmentValidation(IUnitOfWork unitOfWork)
        {
            this.IsDepartmentCodeExist(unitOfWork);

            this.IsDepartmentNameExist(unitOfWork);
        }
    }
}
