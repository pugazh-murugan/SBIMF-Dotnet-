﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Departments;

namespace TCS.HumanResourceManagement.Business.Departments.AddNewDepartment
{
    public class AddNewDepartmentHandler : IRequestHandler<AddNewDepartmentCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        public AddNewDepartmentHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<Unit> Handle(AddNewDepartmentCommand request, CancellationToken cancellationToken)
        {
            var department = new Department()
            {
                Id = Guid.NewGuid(),
                Code = request.Code,
                Description = request.Description,
                Status = request.Status,
                CreatedBy = currentUser.UserId,
                Created = DateTime.Now,
                LastUpdatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now
            };

            await unitOfWork.DepartmentRepository.CreateNewDepartment(department);
            unitOfWork.Commit();
            return Unit.Value;
        }
    }
}
