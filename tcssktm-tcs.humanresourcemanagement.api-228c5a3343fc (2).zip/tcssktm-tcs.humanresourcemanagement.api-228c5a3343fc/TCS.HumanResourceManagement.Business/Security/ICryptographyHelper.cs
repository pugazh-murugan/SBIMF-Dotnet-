﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Security
{
    public interface ICryptographyHelper
    {
        string Encrypt(string unencrypted);

        string Decrypt(string encrypted);
    }
}
