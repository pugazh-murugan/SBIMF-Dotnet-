﻿namespace TCS.HumanResourceManagement.Business
{
    public class AssemblyMaker
    {
    }
}
