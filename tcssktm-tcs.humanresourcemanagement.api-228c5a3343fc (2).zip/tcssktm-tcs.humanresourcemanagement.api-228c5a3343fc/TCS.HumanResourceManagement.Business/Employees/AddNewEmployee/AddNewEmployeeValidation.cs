﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataContext.Interfaces;

namespace TCS.HumanResourceManagement.Business.Employees.AddNewEmployee
{
    public class AddNewEmployeeValidation:AbstractValidator<AddNewEmployeeCommand>
    {

        public AddNewEmployeeValidation(IUnitOfWork unitOfWork)
        {
            RuleFor(c => c.FirstName)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.LastName)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.EmployeeCode)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.")
                .When(c => (c.IsEmployeeCodeGenerated));

            RuleFor(c => c.EmployeeCode)
                     .NotEmpty()
                     .MustAsync(async (employeeCode, _) => !await unitOfWork.EmployeeRepository.IsExist(employeeCode))
                     .WithMessage(command => "{PropertyName} already exist")
                     .When(c => (c.IsEmployeeCodeGenerated));

            RuleFor(c => c.Gender)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.PersonalEmail)
                .EmailAddress()
                .WithMessage(command => "{PropertyName} is not valid")
                .When(c => !(string.IsNullOrEmpty(c.PersonalEmail)));

            RuleFor(c => c.OfficialEmail)
               .EmailAddress()
               .WithMessage(command => "{PropertyName} is not valid")
               .When(c => !(string.IsNullOrEmpty(c.OfficialEmail)));

            this.IsOfficialEmailExist(unitOfWork);

            this.IsPersonalEmailExist(unitOfWork);

            RuleFor(c => c.MobileNumber)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.DateOfBirth)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.DateOfJoin)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

           // this.IsDepartmentIdExist(this.unitOfWork);

            RuleFor(c => c.EmployeeDetails)
                .IsValidEmployeeDetails();

            RuleFor(c => c.BankAccountDetails)
                .IsValidBankAccount();

            RuleFor(c => c.ResidenceAddress)
                .AdddressValidation();

            RuleFor(c => c.PermanentAddress)
                .AdddressValidation();

            RuleForEach(x => x.EmployeeExperiences).SetValidator(new ExperienceDetailsValidator());

            //RuleFor(c => c.EmployeeExperiences)
            //    .SetCollectionValidator(new ExperienceDetailsValidator());
        }
    }
}
