﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Text;
using MediatR;
using TCS.HumanResourceManagement.Business.Model;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Employees.AddNewEmployee
{
    public class AddNewEmployeeCommand :IRequest<string>, IEmployeeCode, IOfficialEmail, IPersonalEmail
    {
        public bool IsEmployeeCodeGenerated { get; set; }

        public string EmployeeCode { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Gender { get; set; }

        [DataType(DataType.EmailAddress)]
        public string PersonalEmail { get; set; }

        [DataType(DataType.EmailAddress)]
        public string OfficialEmail { get; set; }

        public string PANNumber { get; set; }

        public string AadharNumber { get; set; }

        public string MobileNumber { get; set; }

        public bool IsMobileNumberVerified { get; set; }

        public string AlternateNumber { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateOfJoin { get; set; }

        public Guid? ReportingManageId { get; set; }

        public bool IsMarried { get; set; } = false;

        public string SpouseName { get; set; } = string.Empty;

        public bool HaveChild { get; set; } = false;

        public int NumberOfChild { get; set; } = 0;

        public bool IsActive { get; set; } = true;

        public bool IsExitInitiated { get; set; } = false;

        public Addresses ResidenceAddress { get; set; }

        public Addresses PermanentAddress { get; set; }

        public EmployeeDetails EmployeeDetails { get; set; }

        public BankAccountDetails BankAccountDetails { get; set; }

        public List<EmployeeExperiences> EmployeeExperiences { get; set; }

        public List<EmployeeQualifications> EmployeeQualifications { get; set; }
    }
}
