﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.ApiClients;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.AddNewEmployee
{
    public class AddNewEmployeeHandler : IRequestHandler<AddNewEmployeeCommand, string>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        private readonly IAdminApiClient adminApiClient;

        private readonly ICryptographyHelper cryptographyHelper;

        public AddNewEmployeeHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser,
            IAdminApiClient adminApiClient,
            ICryptographyHelper cryptographyHelper)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
            this.adminApiClient = adminApiClient;
            this.cryptographyHelper = cryptographyHelper;
        }

        public async Task<string> Handle(AddNewEmployeeCommand request, CancellationToken cancellationToken)
        {
            var employeeId = Guid.NewGuid();

            var employeeDetails = new EmployeeDetails()
            {
                Id = Guid.NewGuid(),
                EmployeeId = employeeId,
                Designation = request.EmployeeDetails.Designation,
                BasicSalary = request.EmployeeDetails.BasicSalary,
                HRA = request.EmployeeDetails.HRA,
                PF = request.EmployeeDetails.PF,
                DA = request.EmployeeDetails.DA,
                SpecialAllowance = request.EmployeeDetails.SpecialAllowance,
                FoodAllowance = request.EmployeeDetails.FoodAllowance,
                CarAllowance = request.EmployeeDetails.CarAllowance,
                MedicalAllowance = request.EmployeeDetails.MedicalAllowance,
                MobileAllowance = request.EmployeeDetails.MobileAllowance,
                DepartmentId = request.EmployeeDetails.DepartmentId,
                CreatedBy = currentUser.UserId,
                Created = DateTime.Now,
                LastUpdatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now
            };

            var employeeBankAccount = new EmployeeBankAccounts()
            {
                Id = Guid.NewGuid(),
                EmployeeId = employeeId,
                AccountantName = request.BankAccountDetails.AccountantName,
                AccountNumber = cryptographyHelper.Encrypt(request.BankAccountDetails.AccountNumber),
                BankName = cryptographyHelper.Encrypt(request.BankAccountDetails.BankName),
                IfscCode = cryptographyHelper.Encrypt(request.BankAccountDetails.IfscCode),
                CreatedBy = currentUser.UserId,
                Created = DateTime.Now,
                LastUpdatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now
            };

            var permanentAddress = new Addresses()
            {
                AddressLine1 = request.PermanentAddress.AddressLine1,
                AddressLine2 = request.PermanentAddress.AddressLine2,
                City = request.PermanentAddress.City,
                State = request.PermanentAddress.State,
                Country = request.PermanentAddress.Country,
                PostalCode = request.PermanentAddress.PostalCode
            };
            var residenceAddress = new Addresses()
            {
                AddressLine1 = request.ResidenceAddress.AddressLine1,
                AddressLine2 = request.ResidenceAddress.AddressLine2,
                City = request.ResidenceAddress.City,
                State = request.ResidenceAddress.State,
                Country = request.ResidenceAddress.Country,
                PostalCode = request.ResidenceAddress.PostalCode
            };

            var employeeAddress = new EmployeeAddresses()
            {
                Id = Guid.NewGuid(),
                EmployeeId = employeeId,
                PermanentAddress = permanentAddress,
                ResidenceAddress = residenceAddress,
                CreatedBy = currentUser.UserId,
                Created = DateTime.Now,
                LastUpdatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now
            };

            List<EmployeeExperiences> employeeExperiences = new List<EmployeeExperiences>();

            if (request.EmployeeExperiences.Any())
            {
                foreach (var item in request.EmployeeExperiences)
                {
                    var employeeExperience = new EmployeeExperiences()
                    {
                        Id = Guid.NewGuid(),
                        EmployeeId = employeeId,
                        From = item.From,
                        To = item.To,
                        CompanyName = item.CompanyName,
                        Designation = item.Designation,
                        CreatedBy = currentUser.UserId,
                        Created = DateTime.Now,
                        LastUpdatedBy = currentUser.UserId,
                        LastUpdated = DateTime.Now
                    };
                    employeeExperiences.Add(employeeExperience);
                }
            }

            var employee = new DataModel.Model.Employees.Employee()
            {
                Id = employeeId,
                EmployeeCode = request.IsEmployeeCodeGenerated ? request.EmployeeCode : await unitOfWork.EmployeeRepository.CreateNewEmployeeCode(),
                FirstName = request.FirstName,
                LastName = request.LastName,
                Gender = request.Gender,
                PersonalEmail = request.PersonalEmail,
                OfficialEmail = request.OfficialEmail,
                PANNumber = cryptographyHelper.Encrypt(request.PANNumber),
                AadharNumber = cryptographyHelper.Encrypt(request.AadharNumber),
                MobileNumber = request.MobileNumber,
                IsMobileNumberVerified = request.IsMobileNumberVerified,
                AlternateNumber = request.AlternateNumber,
                DateOfBirth = request.DateOfBirth,
                DateOfJoin = request.DateOfJoin,
                ReportingManageId = request.ReportingManageId,
                IsMarried = request.IsMarried,
                SpouseName = request.SpouseName,
                HaveChild = request.HaveChild,
                NumberOfChild = request.NumberOfChild,
                IsActive = request.IsActive,
                IsExitInitiated = request.IsExitInitiated,
                CreatedBy = currentUser.UserId,
                Created = DateTime.Now,
                LastUpdatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now,
                EmployeeAddresses = employeeAddress,
                EmployeeDetails = employeeDetails,
                EmployeeBankAccount = employeeBankAccount,
                EmployeeExperiences = employeeExperiences
            };

            await unitOfWork.EmployeeRepository.CreateNewEmployee(employee);
            await unitOfWork.LeaveRepository.InitLeaves(employeeId, currentUser.UserId, CalculateCasualLeave.InitCasualLeave(request.DateOfJoin));

            await adminApiClient.PostUser(new Model.PostUserRequest()
            {
                DisplayName = request.FirstName,
                UserName = employee.EmployeeCode,
                Password = employee.EmployeeCode,
                Avatar = string.Empty,
                IsActive = true,
                UserId = currentUser.UserId
            });

            unitOfWork.Commit();
            return employee.EmployeeCode;
        }
    }
}
