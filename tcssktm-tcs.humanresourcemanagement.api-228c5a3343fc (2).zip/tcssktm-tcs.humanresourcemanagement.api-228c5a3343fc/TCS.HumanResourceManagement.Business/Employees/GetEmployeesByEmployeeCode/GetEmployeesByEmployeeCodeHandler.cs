﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeesByEmployeeCode
{
    public class GetEmployeesByEmployeeCodeHandler : IRequestHandler<GetEmployeesByEmployeeCodeQuery, Employee>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICryptographyHelper cryptographyHelper;

        public GetEmployeesByEmployeeCodeHandler(
            IUnitOfWork unitOfWork,
            ICryptographyHelper cryptographyHelper)
        {
            this.unitOfWork = unitOfWork;
            this.cryptographyHelper = cryptographyHelper;
        }

        public async Task<Employee> Handle(GetEmployeesByEmployeeCodeQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);

            result.PANNumber = cryptographyHelper.Decrypt(result.PANNumber);
            result.AadharNumber = cryptographyHelper.Decrypt(result.AadharNumber);
            return result;
        }
    }
}
