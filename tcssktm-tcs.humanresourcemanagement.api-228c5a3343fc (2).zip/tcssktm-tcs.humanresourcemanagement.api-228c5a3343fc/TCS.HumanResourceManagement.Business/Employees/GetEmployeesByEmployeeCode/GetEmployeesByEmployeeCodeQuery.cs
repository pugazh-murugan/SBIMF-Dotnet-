﻿using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeesByEmployeeCode
{
    public class GetEmployeesByEmployeeCodeQuery : IRequest<Employee>, IEmployeeCode
    {
        public string EmployeeCode { get; set; }
    }
}
