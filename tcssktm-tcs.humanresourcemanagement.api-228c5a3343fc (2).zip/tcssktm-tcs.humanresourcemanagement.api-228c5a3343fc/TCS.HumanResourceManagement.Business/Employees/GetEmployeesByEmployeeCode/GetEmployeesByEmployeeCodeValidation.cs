﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeesByEmployeeCode
{
    public class GetEmployeesByEmployeeCodeValidation : AbstractValidator<GetEmployeesByEmployeeCodeQuery>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetEmployeesByEmployeeCodeValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            this.IsEmployeeCodeNotExist(unitOfWork);
        }
    }
}
