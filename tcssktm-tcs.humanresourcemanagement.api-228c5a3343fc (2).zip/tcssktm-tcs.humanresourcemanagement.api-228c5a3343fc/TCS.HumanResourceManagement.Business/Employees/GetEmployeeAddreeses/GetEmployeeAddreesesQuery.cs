﻿using System;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeAddreeses
{
    public class GetEmployeeAddreesesQuery : IRequest<ViewEmployeeAddress>, IEmployeeId
    {
        public Guid EmployeeId { get; set; }
    }
}
