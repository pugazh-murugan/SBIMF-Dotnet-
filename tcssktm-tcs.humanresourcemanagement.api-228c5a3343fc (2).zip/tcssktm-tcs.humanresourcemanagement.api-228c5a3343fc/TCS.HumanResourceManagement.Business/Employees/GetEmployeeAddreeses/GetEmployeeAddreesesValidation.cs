﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeAddreeses
{
    public class GetEmployeeAddreesesValidation : AbstractValidator<GetEmployeeAddreesesQuery>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetEmployeeAddreesesValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            this.IsEmployeeIdExist(unitOfWork);
        }
    }
}
