﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeAddreeses
{
    public class GetEmployeeAddreesesHandler : IRequestHandler<GetEmployeeAddreesesQuery, ViewEmployeeAddress>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetEmployeeAddreesesHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<ViewEmployeeAddress> Handle(GetEmployeeAddreesesQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.EmployeeRepository.GetEmployeeAddreeses(request.EmployeeId);
            return result;
        }
    }
}
