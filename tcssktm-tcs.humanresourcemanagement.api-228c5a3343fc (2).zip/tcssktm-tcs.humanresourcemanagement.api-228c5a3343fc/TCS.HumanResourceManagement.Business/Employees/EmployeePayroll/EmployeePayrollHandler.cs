﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.ApiClients.PointOfSales;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Payroll;

namespace TCS.HumanResourceManagement.Business.Employees.EmployeePayroll
{
    public class EmployeePayrollHandler : IRequestHandler<EmployeePayrollQuery, List<PayrollProcessingViewModel>>
    {
        private readonly IUnitOfWork unitOfWork;

        public readonly IPointOfSalesApiClient pointOfSalesApiClient;

        private readonly ICryptographyHelper cryptographyHelper;

        public EmployeePayrollHandler(
            IUnitOfWork unitOfWork,
            IPointOfSalesApiClient pointOfSalesApiClient,
            ICryptographyHelper cryptographyHelper
            )
        {
            this.unitOfWork = unitOfWork;
            this.pointOfSalesApiClient = pointOfSalesApiClient;
            this.cryptographyHelper = cryptographyHelper;
        }

        public async Task<List<PayrollProcessingViewModel>> Handle(EmployeePayrollQuery request, CancellationToken cancellationToken)
        {
            var salesIncentives = await pointOfSalesApiClient.GetAssociateSalesForPayroll(DateTime.Now.ToString("MMM-yyyy"), string.Empty);
            var attendances = await unitOfWork.TimeAndAttendanceRepository.ViewTimeAndAttendance(null, DateTime.Now.PayrollFrom(), DateTime.Now.PayrollTo(), null);
            var employeePresentDays = attendances.GroupBy(c => c.EmployeeId).Select(c => new { EmployeeId = c.First().EmployeeId, PresentDays = c.Count() }).ToList();
            var employeeBasics = await unitOfWork.PayrollRepository.PayrollProcess();
            var numberOfWorkingDays = DateTime.Now.NumberOfWorkingDays();

            foreach(var employeeBasic in employeeBasics)
            {
                var employeePresent = employeePresentDays.FirstOrDefault(c => c.EmployeeId == employeeBasic.EmployeeId);
                var incentives = salesIncentives.FirstOrDefault(c => c.AssociateCode == employeeBasic.EmployeeCode);

                employeeBasic.WorkingDays = numberOfWorkingDays;
                employeeBasic.PresentDays = employeePresent != null ? employeePresent.PresentDays : 0;
                employeeBasic.AbsentDays = employeeBasic.WorkingDays - employeeBasic.PresentDays;
                employeeBasic.Incentives = incentives != null ? incentives.Incentives : 0;
                employeeBasic.BankName = cryptographyHelper.Decrypt(employeeBasic.BankName);
                employeeBasic.AccountNumber = cryptographyHelper.Decrypt(employeeBasic.AccountNumber);
                employeeBasic.IfscCode = cryptographyHelper.Decrypt(employeeBasic.IfscCode);
                employeeBasic.GrossAmount = (employeeBasic.BasicSalary + employeeBasic.Incentives) - employeeBasic.LossOfPay;
            }

            return employeeBasics.OrderBy(c => c.EmployeeCode).ToList();
        }
    }
}
