﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Employees.EmployeePayroll
{
    public class EmployeePayrollValidation : AbstractValidator<EmployeePayrollQuery>
    {
        public EmployeePayrollValidation()
        {

        }
    }
}
