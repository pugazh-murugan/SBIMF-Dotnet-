﻿using System;
using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Payroll;

namespace TCS.HumanResourceManagement.Business.Employees.EmployeePayroll
{
    public class EmployeePayrollQuery : IRequest<List<PayrollProcessingViewModel>>
    {
        public int Year { get; set; } = DateTime.Now.Year;

        public string Month { get; set; } = DateTime.Now.ToString("MMM");
    }
}
