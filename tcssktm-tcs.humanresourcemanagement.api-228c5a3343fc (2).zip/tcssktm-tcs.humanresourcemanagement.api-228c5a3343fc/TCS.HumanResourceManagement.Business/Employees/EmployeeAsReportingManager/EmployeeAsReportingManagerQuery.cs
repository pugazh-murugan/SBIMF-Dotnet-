﻿using MediatR;

namespace TCS.HumanResourceManagement.Business.Employees.EmployeeAsReportingManager
{
    public class EmployeeAsReportingManagerQuery : IRequest<bool>

    {
    }
}
