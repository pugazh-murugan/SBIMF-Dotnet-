﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.EmployeeAsReportingManager
{
    public class EmployeeAsReportingManagerHandler : IRequestHandler<EmployeeAsReportingManagerQuery, bool>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        public EmployeeAsReportingManagerHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<bool> Handle(EmployeeAsReportingManagerQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.EmployeeRepository.IsUserAsReportingManager(currentUser.UserId);
            return result;
        }
    }
}
