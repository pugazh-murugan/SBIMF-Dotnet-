﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Employees.EmployeeAsReportingManager
{
    public class EmployeeAsReportingManagerValidation : AbstractValidator<EmployeeAsReportingManagerQuery>
    {
    }
}
