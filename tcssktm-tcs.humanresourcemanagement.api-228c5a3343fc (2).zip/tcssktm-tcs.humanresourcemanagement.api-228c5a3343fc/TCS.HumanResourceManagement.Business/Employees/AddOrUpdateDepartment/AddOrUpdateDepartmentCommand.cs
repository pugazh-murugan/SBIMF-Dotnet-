﻿using System;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Employees.AddOrUpdateDepartment
{
    public class AddOrUpdateDepartmentCommand : IRequest, IEmployeeId, IDepartmentId
    {
        public Guid EmployeeId { get; set; }

        public Guid? DepartmentId { get; set; }
    }
}
