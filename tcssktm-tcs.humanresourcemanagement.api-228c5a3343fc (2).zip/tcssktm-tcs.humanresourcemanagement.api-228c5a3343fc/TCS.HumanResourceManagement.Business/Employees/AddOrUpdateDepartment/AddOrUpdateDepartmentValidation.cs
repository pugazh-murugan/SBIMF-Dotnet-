﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.AddOrUpdateDepartment
{
    public class AddOrUpdateDepartmentValidation : AbstractValidator<AddOrUpdateDepartmentCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        public AddOrUpdateDepartmentValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            this.IsDepartmentIdExist(unitOfWork);

            this.IsEmployeeIdExist(unitOfWork);
        }
    }
}
