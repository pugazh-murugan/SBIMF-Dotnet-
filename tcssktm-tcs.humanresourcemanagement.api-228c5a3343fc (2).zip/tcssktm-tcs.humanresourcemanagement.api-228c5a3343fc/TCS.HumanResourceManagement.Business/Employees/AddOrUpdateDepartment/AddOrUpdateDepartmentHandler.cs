﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.AddOrUpdateDepartment
{
    public class AddOrUpdateDepartmentHandler : IRequestHandler<AddOrUpdateDepartmentCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        public AddOrUpdateDepartmentHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<Unit> Handle(AddOrUpdateDepartmentCommand request, CancellationToken cancellationToken)
        {
            var exitingEmployeeDetails = await unitOfWork.EmployeeRepository.GetLast(request.EmployeeId);

            var employeeDetails = new EmployeeDetails()
            {
                Id = Guid.NewGuid(),
                EmployeeId = request.EmployeeId,
                Designation = exitingEmployeeDetails.Designation,
                BasicSalary = exitingEmployeeDetails.BasicSalary,
                HRA = exitingEmployeeDetails.HRA,
                PF = exitingEmployeeDetails.PF,
                DA = exitingEmployeeDetails.DA,
                SpecialAllowance = exitingEmployeeDetails.SpecialAllowance,
                FoodAllowance = exitingEmployeeDetails.FoodAllowance,
                CarAllowance = exitingEmployeeDetails.CarAllowance,
                MedicalAllowance = exitingEmployeeDetails.MedicalAllowance,
                MobileAllowance = exitingEmployeeDetails.MobileAllowance,
                DepartmentId = request.DepartmentId,
                CreatedBy = currentUser.UserId,
                Created = DateTime.Now,
                LastUpdatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now
            };

            await unitOfWork.EmployeeRepository.CreateNewEmployeeDetails(employeeDetails);
            unitOfWork.Commit();
            return Unit.Value;
        }
    }
}
