﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetAllEmployees
{
    public class GetAllEmployeeHandler : IRequestHandler<GetAllEmployeeQuery, List<Employee>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetAllEmployeeHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<List<Employee>> Handle(GetAllEmployeeQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.EmployeeRepository.GetAllEmployees();
            return result;
        }
    }
}
