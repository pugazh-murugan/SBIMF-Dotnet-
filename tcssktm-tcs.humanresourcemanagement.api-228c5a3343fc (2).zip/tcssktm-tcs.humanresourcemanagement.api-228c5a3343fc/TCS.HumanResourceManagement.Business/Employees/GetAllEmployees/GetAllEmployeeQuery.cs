﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetAllEmployees
{
    public class GetAllEmployeeQuery : IRequest<List<Employee>>
    {
    }
}
