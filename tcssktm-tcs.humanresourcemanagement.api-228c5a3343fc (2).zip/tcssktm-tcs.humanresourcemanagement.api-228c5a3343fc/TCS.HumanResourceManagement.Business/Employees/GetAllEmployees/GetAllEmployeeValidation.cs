﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Employees.GetAllEmployees
{
    public class GetAllEmployeeValidation : AbstractValidator<GetAllEmployeeQuery>
    {
        public GetAllEmployeeValidation()
        {

        }
    }
}
