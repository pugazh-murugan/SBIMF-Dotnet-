﻿using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Employees.AssignReportingManagerByEmployee
{
    public class AssignReportingManagerByEmployeeCommand : IRequest, IEmployeeCode, IReportingManagerCode
    {
        public string EmployeeCode { get; set; }

        public string ReportingManagerCode { get; set; }
    }
}
