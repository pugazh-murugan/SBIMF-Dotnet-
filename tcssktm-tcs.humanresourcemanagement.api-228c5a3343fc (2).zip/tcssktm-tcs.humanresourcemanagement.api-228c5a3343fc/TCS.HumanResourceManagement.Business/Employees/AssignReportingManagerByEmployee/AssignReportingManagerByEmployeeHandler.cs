﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.AssignReportingManagerByEmployee
{
    public class AssignReportingManagerByEmployeeHandler : IRequestHandler<AssignReportingManagerByEmployeeCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;


        public AssignReportingManagerByEmployeeHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }
        public async Task<Unit> Handle(AssignReportingManagerByEmployeeCommand request, CancellationToken cancellationToken)
        {
            var reportingManager = await unitOfWork.EmployeeRepository.GetEmployee(request.ReportingManagerCode);
            var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);

            await unitOfWork.EmployeeRepository.AssignReportingManagerToEmployee(employee.Id, reportingManager.Id, currentUser.UserId);
            unitOfWork.Commit();
            return Unit.Value;
        }
    }
}
