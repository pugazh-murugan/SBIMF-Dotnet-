﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.AssignReportingManagerByEmployee
{
    public class AssignReportingManagerByEmployeeValidation : AbstractValidator<AssignReportingManagerByEmployeeCommand>
    {
        public AssignReportingManagerByEmployeeValidation(IUnitOfWork unitOfWork)
        {
            RuleFor(c => c.EmployeeCode)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.ReportingManagerCode)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.EmployeeCode)
                .NotEqual(c => c.ReportingManagerCode)
                .WithMessage("Employee code and reporting manager code should not be same.");

            this.IsReportingManagerCodeNotExist(unitOfWork);

        }
    }
}
