﻿using System;
using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeExperience
{
    public class GetEmployeeExperienceQuery : IRequest<List<EmployeeExperiences>>, IEmployeeId
    {
        public Guid EmployeeId { get; set; }
    }
}
