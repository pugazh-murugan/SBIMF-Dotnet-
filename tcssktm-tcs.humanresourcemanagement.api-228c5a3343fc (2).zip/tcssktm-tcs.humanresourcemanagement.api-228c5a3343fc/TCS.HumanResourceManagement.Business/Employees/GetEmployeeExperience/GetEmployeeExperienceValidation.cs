﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeExperience
{
    public class GetEmployeeExperienceValidation : AbstractValidator<GetEmployeeExperienceQuery>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetEmployeeExperienceValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            this.IsEmployeeIdExist(unitOfWork);
        }
    }
}
