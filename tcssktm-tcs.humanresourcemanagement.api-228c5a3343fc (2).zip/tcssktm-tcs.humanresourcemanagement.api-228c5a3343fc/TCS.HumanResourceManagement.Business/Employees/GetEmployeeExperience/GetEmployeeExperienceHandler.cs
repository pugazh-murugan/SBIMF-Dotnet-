﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeExperience
{
    public class GetEmployeeExperienceHandler : IRequestHandler<GetEmployeeExperienceQuery, List<EmployeeExperiences>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetEmployeeExperienceHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<List<EmployeeExperiences>> Handle(GetEmployeeExperienceQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.EmployeeRepository.GetEmployeeExperience(request.EmployeeId);
            return result;
        }
    }
}
