﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeSalaryDetails
{
    public class GetEmployeeSalaryDetailsHandler : IRequestHandler<GetEmployeeSalaryDetailsQuery, ViewEmployeeSalaryDetails>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICryptographyHelper cryptographyHelper;

        public GetEmployeeSalaryDetailsHandler(
            IUnitOfWork unitOfWork,
            ICryptographyHelper cryptographyHelper)
        {
            this.unitOfWork = unitOfWork;
            this.cryptographyHelper = cryptographyHelper;
        }

        public async Task<ViewEmployeeSalaryDetails> Handle(GetEmployeeSalaryDetailsQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.EmployeeRepository.GetEmployeeSalaryDetails(request.EmployeeId);
            result.EmployeeBankAccounts.IfscCode = cryptographyHelper.Decrypt(result.EmployeeBankAccounts.IfscCode);
            result.EmployeeBankAccounts.BankName = string.IsNullOrEmpty(result.EmployeeBankAccounts.BankName) ? string.Empty : cryptographyHelper.Decrypt(result.EmployeeBankAccounts.BankName);
            result.EmployeeBankAccounts.AccountNumber = cryptographyHelper.Decrypt(result.EmployeeBankAccounts.AccountNumber);
            return result;
        }
    }
}
