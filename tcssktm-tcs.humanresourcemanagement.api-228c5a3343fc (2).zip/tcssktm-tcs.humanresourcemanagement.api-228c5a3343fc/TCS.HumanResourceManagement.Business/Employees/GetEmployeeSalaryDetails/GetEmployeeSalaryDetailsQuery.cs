﻿using System;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeSalaryDetails
{
    public class GetEmployeeSalaryDetailsQuery : IRequest<ViewEmployeeSalaryDetails>, IEmployeeId
    {
        public Guid EmployeeId { get; set; }
    }
}
