﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeSalaryDetails
{
    public class GetEmployeeSalaryDetailsValidation : AbstractValidator<GetEmployeeSalaryDetailsQuery>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetEmployeeSalaryDetailsValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            this.IsEmployeeIdExist(unitOfWork);
        }
    }
}
