﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeById
{
    public class GetEmployeeByIdValidation : AbstractValidator<GetEmployeeByIdQuery>
    {
        public GetEmployeeByIdValidation(IUnitOfWork unitOfWork)
        {
            this.IsEmployeeIdExist(unitOfWork);
        }
    }
}
