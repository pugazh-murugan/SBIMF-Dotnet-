﻿using System;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.Employees.GetEmployeeById
{
    public class GetEmployeeByIdQuery : IRequest<Employee>, IEmployeeId
    {
        public Guid EmployeeId { get; set; }
    }
}
