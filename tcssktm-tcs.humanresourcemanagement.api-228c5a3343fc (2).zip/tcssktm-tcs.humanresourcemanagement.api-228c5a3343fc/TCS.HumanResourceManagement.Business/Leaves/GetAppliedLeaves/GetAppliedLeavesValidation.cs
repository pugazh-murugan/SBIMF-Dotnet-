﻿using FluentValidation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Leaves.GetAppliedLeaves
{
    public class GetAppliedLeavesValidation : AbstractValidator<GetAppliedLeavesQuery>
    {
        public GetAppliedLeavesValidation(IUnitOfWork unitOfWork)
        {
            RuleFor(c => c.EmployeeCode)
                .MustAsync(async (employeeCode, _) => await unitOfWork.EmployeeRepository.IsExist(employeeCode))
                .WithMessage(command => "{PropertyName} does not exist")
                .When(c => !string.IsNullOrEmpty(c.EmployeeCode));

            RuleFor(c => c.FromDate)
               .NotNull()
               .WithMessage(command => "{PropertyName} should not be blank.");


            RuleFor(c => c.ToDate)
               .NotNull()
               .WithMessage(command => "{PropertyName} should not be blank.")
               .GreaterThanOrEqualTo(m => m.FromDate)
               .WithMessage(command => "{PropertyName} is greater than From date");
               

            RuleFor(c => c.ApproverId)
                .MustAsync(async (approver, _) => await unitOfWork.EmployeeRepository.IsExist(approver.Value))
                .WithMessage(command => "{PropertyName} does not exist")
                .When(c => c.ApproverId.HasValue);

        }
    }
}
