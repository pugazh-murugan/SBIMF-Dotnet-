﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.GetAppliedLeaves
{
    public class GetAppliedLeavesHandler : IRequestHandler<GetAppliedLeavesQuery, List<ViewAppliedLeaves>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetAppliedLeavesHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }
        public async Task<List<ViewAppliedLeaves>> Handle(GetAppliedLeavesQuery request, CancellationToken cancellationToken)
        {
            var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);

            var result = await unitOfWork.LeaveRepository.ViewAppliedLeaves(employee == null ? (Guid?)null : employee.Id, request.FromDate.StartOfDay(), request.ToDate.EndOfDay(), request.ApproverId, request.IsApproved);
            return result;
        }
    }
}
