﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.GetAppliedLeaves
{
    public class GetAppliedLeavesQuery : IRequest<List<ViewAppliedLeaves>>, IEmployeeCode
    {
        public string EmployeeCode { get; set; }

        [DataType(DataType.Date)]
        public DateTime FromDate { get; set; }

        [DataType(DataType.Date)]
        public DateTime ToDate { get; set; }

        public bool? IsApproved { get; set; }

        public Guid? ApproverId { get; set; }
    }
}
