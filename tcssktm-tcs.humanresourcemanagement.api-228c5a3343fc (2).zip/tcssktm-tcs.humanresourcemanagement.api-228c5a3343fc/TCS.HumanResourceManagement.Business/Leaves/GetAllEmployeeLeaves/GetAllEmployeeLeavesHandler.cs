﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.GetAllEmployeeLeaves
{
    public class GetAllEmployeeLeavesHandler : IRequestHandler<GetAllEmployeeLeavesQuery, List<ViewEmployeeLeaves>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetAllEmployeeLeavesHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<List<ViewEmployeeLeaves>> Handle(GetAllEmployeeLeavesQuery request, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
    }
}
