﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Leaves.GetAllEmployeeLeaves
{
    public class GetAllEmployeeLeavesValidation : AbstractValidator<GetAllEmployeeLeavesQuery>
    {
        public GetAllEmployeeLeavesValidation()
        {

        }
    }
}
