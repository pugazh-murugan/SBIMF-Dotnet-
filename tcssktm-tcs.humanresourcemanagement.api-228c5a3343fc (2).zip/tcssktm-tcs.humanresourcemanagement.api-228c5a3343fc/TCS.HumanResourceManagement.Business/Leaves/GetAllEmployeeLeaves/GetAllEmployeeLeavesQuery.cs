﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.GetAllEmployeeLeaves
{
    public class GetAllEmployeeLeavesQuery : IRequest<List<ViewEmployeeLeaves>>
    {
    }
}
