﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Leaves.GetLeaveTypes
{
    public class GetLeaveTypesValidation : AbstractValidator<GetLeaveTypesQuery>
    {
    }
}
