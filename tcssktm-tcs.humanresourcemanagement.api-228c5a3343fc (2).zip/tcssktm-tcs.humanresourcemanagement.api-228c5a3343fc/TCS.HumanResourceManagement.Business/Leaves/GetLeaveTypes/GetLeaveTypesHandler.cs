﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.GetLeaveTypes
{
    public class GetLeaveTypesHandler : IRequestHandler<GetLeaveTypesQuery, List<LeaveTypes>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetLeaveTypesHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<List<LeaveTypes>> Handle(GetLeaveTypesQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.LeaveRepository.GetAllLeaveTypes();
            return result;
        }
    }
}
