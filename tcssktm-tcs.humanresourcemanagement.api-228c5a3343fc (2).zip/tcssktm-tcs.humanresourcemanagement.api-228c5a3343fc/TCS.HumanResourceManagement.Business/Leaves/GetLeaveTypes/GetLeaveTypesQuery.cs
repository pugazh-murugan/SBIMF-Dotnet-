﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.GetLeaveTypes
{
    public class GetLeaveTypesQuery : IRequest<List<LeaveTypes>>
    {
    }
}
