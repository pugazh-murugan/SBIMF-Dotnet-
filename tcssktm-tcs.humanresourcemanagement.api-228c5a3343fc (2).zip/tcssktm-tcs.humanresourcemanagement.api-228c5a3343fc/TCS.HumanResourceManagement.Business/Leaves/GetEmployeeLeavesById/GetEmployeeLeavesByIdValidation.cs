﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Leaves.GetEmployeeLeavesById
{
    public class GetEmployeeLeavesByIdValidation : AbstractValidator<GetEmployeeLeavesByIdQuery>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetEmployeeLeavesByIdValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            this.IsEmployeeCodeNotExist(unitOfWork);
        }
    }
}
