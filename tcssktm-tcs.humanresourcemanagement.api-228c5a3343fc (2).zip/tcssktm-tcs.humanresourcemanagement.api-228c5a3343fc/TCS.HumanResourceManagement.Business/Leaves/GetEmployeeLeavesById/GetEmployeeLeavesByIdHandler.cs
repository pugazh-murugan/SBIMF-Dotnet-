﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.GetEmployeeLeavesById
{
    public class GetEmployeeLeavesByIdHandler : IRequestHandler<GetEmployeeLeavesByIdQuery, List<ViewEmployeeLeaves>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetEmployeeLeavesByIdHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }
        public async Task<List<ViewEmployeeLeaves>> Handle(GetEmployeeLeavesByIdQuery request, CancellationToken cancellationToken)
        {
            var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);

            var result = await unitOfWork.LeaveRepository.ViewEmployeeLeaves(employee.Id);
            return result;
        }
    }
}
