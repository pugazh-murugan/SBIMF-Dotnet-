﻿using System;
using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.GetEmployeeLeavesById
{
    public class GetEmployeeLeavesByIdQuery : IRequest<List<ViewEmployeeLeaves>>, IEmployeeCode
    {
        public string EmployeeCode { get; set; }
    }
}
