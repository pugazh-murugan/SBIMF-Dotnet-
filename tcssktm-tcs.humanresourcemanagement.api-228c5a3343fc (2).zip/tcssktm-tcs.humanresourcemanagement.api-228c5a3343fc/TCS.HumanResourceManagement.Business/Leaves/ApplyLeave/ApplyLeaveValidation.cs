﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Leaves.ApplyLeave
{
    public class ApplyLeaveValidation : AbstractValidator<ApplyLeaveCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        public ApplyLeaveValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            this.IsEmployeeIdExist(unitOfWork);

            RuleFor(c => c.FromDate)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.ToDate)
               .NotNull()
               .WithMessage(command => "{PropertyName} should not be blank.")
               .GreaterThanOrEqualTo(m => m.FromDate)
               .WithMessage(command=> "{PropertyName} must after From date");

            this.IsLeaveTypeIdExist(unitOfWork);

            this.IsAssignedReportingManagerToEmployee(unitOfWork);

            this.IsEmployeeCodeNotExist(unitOfWork);

            RuleFor(c => c.LeaveTypeId)
                     .NotEmpty()
                     .MustAsync(async (command, leaveType, _) => await unitOfWork.LeaveRepository.IsLeaveBalanceAvailable(leaveType, command.EmployeeId))
                     .WithMessage(command => "There is no leave balance available for this leave type.");

            RuleFor(c => c.FromDate)
                    .NotEmpty()
                    .MustAsync(async (command, fromDate, _) => !await unitOfWork.LeaveRepository.IsAlreadyAppliedLeaveByDate(fromDate, command.ToDate, command.EmployeeId))
                    .WithMessage(command => "You already applied leave with specific date");

        }
    }
}
