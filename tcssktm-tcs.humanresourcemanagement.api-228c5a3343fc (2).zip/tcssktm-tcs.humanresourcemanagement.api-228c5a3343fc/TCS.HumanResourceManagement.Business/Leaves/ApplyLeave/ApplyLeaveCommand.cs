﻿using System;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Leaves.ApplyLeave
{
    public class ApplyLeaveCommand : IRequest, IEmployeeId, ILeaveTypeId, IEmployeeCode
    {
        public Guid EmployeeId { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public Guid LeaveTypeId { get; set; }

        public string Reason { get; set; }

        public string EmployeeCode { get; set; }

        public string EmergencyContact { get; set; }
    }
}
