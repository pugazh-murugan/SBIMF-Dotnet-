﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.Business.Utilities;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.Business.Leaves.ApplyLeave
{
    public class ApplyLeaveHandler : IRequestHandler<ApplyLeaveCommand>
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly ICurrentUser currentUser;

        public ApplyLeaveHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<Unit> Handle(ApplyLeaveCommand request, CancellationToken cancellationToken)
        {
            var reportingManager = await unitOfWork.EmployeeRepository.ReportingMangerByEmployee(request.EmployeeId);
            var employee = await unitOfWork.EmployeeRepository.GetEmployee(request.EmployeeCode);

            var applyLeave = new EmployeeLeaves()
            {
                Id = Guid.NewGuid(),
                EmployeeId = request.EmployeeId,
                FromDate = request.FromDate,
                ToDate = request.ToDate,
                TotalDays = request.FromDate.TotalDays(request.ToDate),
                LeaveTypeId = request.LeaveTypeId,
                IsApproved = null,
                Approver = reportingManager.Id,
                Reason = request.Reason,
                WorkAssignTo= employee.Id,
                EmergencyContact=request.EmergencyContact,
                CreatedBy = currentUser.UserId,
                Created = DateTime.Now,
                LastUpdatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now
            };

            await unitOfWork.LeaveRepository.ApplyLeave(applyLeave);
            unitOfWork.Commit();

            return Unit.Value;
        }
    }
}
