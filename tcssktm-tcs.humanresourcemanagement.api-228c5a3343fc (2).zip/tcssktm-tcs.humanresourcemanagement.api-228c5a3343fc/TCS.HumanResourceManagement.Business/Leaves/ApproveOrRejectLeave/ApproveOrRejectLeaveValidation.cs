﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Leaves.ApproveOrRejectLeave
{
    public class ApproveOrRejectLeaveValidation :AbstractValidator<ApproveOrRejectLeaveCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        public ApproveOrRejectLeaveValidation(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;

            this.IsEmployeeLeaveIdExist(unitOfWork);

            RuleFor(c => c.Remarks)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank")
                .When(c => !c.IsApproved);
        }
    }
}
