﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Leaves.ApproveOrRejectLeave
{
    public class ApproveOrRejectLeaveHandler : IRequestHandler<ApproveOrRejectLeaveCommand>
    {
        private readonly IUnitOfWork unitOfWork;
        private readonly ICurrentUser currentUser;

        public ApproveOrRejectLeaveHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<Unit> Handle(ApproveOrRejectLeaveCommand request, CancellationToken cancellationToken)
        {
            await unitOfWork.LeaveRepository.ApproveOrRejectLeave(request.EmployeeLeaveId, currentUser.UserId, request.IsApproved, request.Remarks);
            unitOfWork.Commit();
            return Unit.Value;
        }
    }
}
