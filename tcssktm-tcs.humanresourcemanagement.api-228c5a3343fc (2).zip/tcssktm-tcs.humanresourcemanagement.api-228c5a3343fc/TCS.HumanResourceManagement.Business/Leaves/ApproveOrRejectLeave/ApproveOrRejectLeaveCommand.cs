﻿using System;
using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Leaves.ApproveOrRejectLeave
{
    public class ApproveOrRejectLeaveCommand : IRequest, IEmployeeLeaveId
    {
        public Guid EmployeeLeaveId { get; set; }

        public string Remarks { get; set; }

        public bool IsApproved { get; set; }
    }
}
