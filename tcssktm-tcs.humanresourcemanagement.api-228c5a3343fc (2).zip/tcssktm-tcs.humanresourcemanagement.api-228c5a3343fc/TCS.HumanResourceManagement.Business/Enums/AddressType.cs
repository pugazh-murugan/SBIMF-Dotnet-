﻿namespace TCS.HumanResourceManagement.Business.Enums
{
    public enum AddressType : int
    {
        OWN = 1,
        Rented = 0
    }
}
