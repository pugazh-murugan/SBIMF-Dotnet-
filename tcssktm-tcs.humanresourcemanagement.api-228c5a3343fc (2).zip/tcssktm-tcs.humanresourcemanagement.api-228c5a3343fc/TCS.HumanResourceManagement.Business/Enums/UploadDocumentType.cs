﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Enums
{
    public enum UploadDocumentType : int
    {
        SSLC = 1,
        HSC = 2,
        UG = 3,
        PG = 4,
        MPHIL = 5,
        PHD = 6,
        OfferLetter = 7,
        RelievingLetter = 8
    }
}
