﻿namespace TCS.HumanResourceManagement.Business.Enums
{
    public enum PunchTypes : int
    {
        IN = 0,
        OUT = 1
    }
}
