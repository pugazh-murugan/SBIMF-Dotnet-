﻿namespace TCS.HumanResourceManagement.Business.Constants
{
    public class Policy
    {
        public const string TerritoryTokenHolderOnly = "TerritoryAuthorizeAttribute";
        public const string BearerOnly = "BearerTokenAttribute";
    }
}
