﻿namespace TCS.HumanResourceManagement.Business.Constants
{
    public class AuthorizationHeaders
    {
        public const string TerritoryHeaderName = "x-territory-key";
        public const string HeaderName = "Authorization";
    }
}
