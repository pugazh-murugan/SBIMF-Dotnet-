﻿namespace TCS.HumanResourceManagement.Business.Constants
{
    public class AuthenticationConstants
    {
        public const string ClaimsTerritoryId = "TerritoryId";
        public const string ClaimsRoleType = "Role";
        public const string ClaimsIdentityBearer = "Bearer";
    }
}
