﻿namespace TCS.HumanResourceManagement.Business.Utilities
{
    public class AppSettings
    {
        public string UploadedDocumentLocation { get; set; }

        public bool IsIncentive { get; set; }
    }
}
