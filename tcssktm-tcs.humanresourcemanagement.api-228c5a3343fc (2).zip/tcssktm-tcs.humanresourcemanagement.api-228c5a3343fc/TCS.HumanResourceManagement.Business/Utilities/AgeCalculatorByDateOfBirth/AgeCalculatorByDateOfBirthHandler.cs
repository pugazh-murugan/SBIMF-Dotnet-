﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;

namespace TCS.HumanResourceManagement.Business.Utilities.AgeCalculatorByDateOfBirth
{
    public class AgeCalculatorByDateOfBirthHandler : IRequestHandler<AgeCalculatorByDateOfBirthCommand, int>
    {
        private int age = 0;

        public async Task<int> Handle(AgeCalculatorByDateOfBirthCommand request, CancellationToken cancellationToken)
        {
            age = DateTime.Now.Year - request.DateOfBirth.Year;
            if (DateTime.Now.DayOfYear < request.DateOfBirth.DayOfYear)
                age = age - 1;

            return age;
        }
    }
}
