﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Utilities.AgeCalculatorByDateOfBirth
{
    public class AgeCalculatorByDateOfBirthValidation : AbstractValidator<AgeCalculatorByDateOfBirthCommand>
    {
        public AgeCalculatorByDateOfBirthValidation()
        {
            RuleFor(c => c.DateOfBirth)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank");
        }
    }
}
