﻿using System;
using System.ComponentModel.DataAnnotations;
using MediatR;

namespace TCS.HumanResourceManagement.Business.Utilities.AgeCalculatorByDateOfBirth
{
    public class AgeCalculatorByDateOfBirthCommand : IRequest<int>
    {
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }
    }
}
