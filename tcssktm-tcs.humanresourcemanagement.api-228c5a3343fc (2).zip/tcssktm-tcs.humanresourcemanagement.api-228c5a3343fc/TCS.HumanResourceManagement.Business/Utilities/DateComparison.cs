﻿using System;

namespace TCS.HumanResourceManagement.Business.Utilities
{
    public static class DateComparison
    {
        public static double TotalDays(this DateTime fromDate, DateTime toDate)
        {
            var days = (toDate.Date - fromDate.Date).TotalDays;
            return (days + 1);
        }
    }
}
