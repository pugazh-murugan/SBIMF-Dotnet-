﻿using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;

namespace TCS.HumanResourceManagement.Business.Jobs.GetCandidateByApplicationNumber
{
    public class GetCandidateByApplicationNumberCommand : IRequest<Candidates>, IApplicationNumber
    {
        public int ApplicationNumber { get; set; }
    }
}
