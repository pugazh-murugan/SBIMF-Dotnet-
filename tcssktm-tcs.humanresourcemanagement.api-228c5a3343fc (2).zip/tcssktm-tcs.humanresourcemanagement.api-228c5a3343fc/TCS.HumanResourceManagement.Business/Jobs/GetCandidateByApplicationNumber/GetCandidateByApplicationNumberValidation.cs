﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Jobs.GetCandidateByApplicationNumber
{
    public class GetCandidateByApplicationNumberValidation : AbstractValidator<GetCandidateByApplicationNumberCommand>
    {
        public GetCandidateByApplicationNumberValidation(IUnitOfWork unitOfWork)
        {

        }
    }
}
