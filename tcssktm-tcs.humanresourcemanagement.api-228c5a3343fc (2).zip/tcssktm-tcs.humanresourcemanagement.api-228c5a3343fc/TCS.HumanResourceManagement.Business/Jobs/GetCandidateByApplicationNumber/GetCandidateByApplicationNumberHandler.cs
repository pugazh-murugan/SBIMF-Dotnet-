﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;

namespace TCS.HumanResourceManagement.Business.Jobs.GetCandidateByApplicationNumber
{
    public class GetCandidateByApplicationNumberHandler : IRequestHandler<GetCandidateByApplicationNumberCommand,Candidates>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICryptographyHelper cryptographyHelper;

        public GetCandidateByApplicationNumberHandler(
            IUnitOfWork unitOfWork,
            ICryptographyHelper cryptographyHelper)
        {
            this.unitOfWork = unitOfWork;
            this.cryptographyHelper = cryptographyHelper;
        }

        public async Task<Candidates> Handle(GetCandidateByApplicationNumberCommand request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.JobsRepository.CandidateByApplicationNumber(request.ApplicationNumber);
            return result;
        }
    }
}
