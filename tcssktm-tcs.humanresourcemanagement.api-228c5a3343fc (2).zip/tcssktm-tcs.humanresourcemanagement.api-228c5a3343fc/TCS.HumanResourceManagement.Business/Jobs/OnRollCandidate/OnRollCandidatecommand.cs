﻿using System;
using System.Collections.Generic;
using System.Text;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Interfaces;

namespace TCS.HumanResourceManagement.Business.Jobs.OnRollCandidate
{
   public class OnRollCandidatecommand : IRequest<string>, IId
    {
        public Guid Id { get; set; }
    }
}
