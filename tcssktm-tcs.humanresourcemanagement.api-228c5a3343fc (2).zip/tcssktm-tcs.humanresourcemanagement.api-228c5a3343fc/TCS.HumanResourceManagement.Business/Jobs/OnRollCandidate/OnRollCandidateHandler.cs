﻿using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.ApiClients;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Jobs.OnRollCandidate
{
    public class OnRollCandidateHandler : IRequestHandler<OnRollCandidatecommand,string>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        private readonly IAdminApiClient adminApiClient;

        public OnRollCandidateHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser,
            IAdminApiClient adminApiClient)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
            this.adminApiClient = adminApiClient;
        }

        public async Task<string> Handle(OnRollCandidatecommand request, CancellationToken cancellationToken)
        {
            var employee = await unitOfWork.JobsRepository.OnRollCandidate(request.Id, currentUser.UserId);
            await unitOfWork.LeaveRepository.InitLeaves(employee.Id, currentUser.UserId, CalculateCasualLeave.InitCasualLeave(employee.DateOfJoin));

            await adminApiClient.PostUser(new Model.PostUserRequest()
            {
                DisplayName = employee.FirstName,
                UserName = employee.EmployeeCode,
                Password = employee.EmployeeCode,
                Avatar = employee.Avatar,
                IsActive = true,
                UserId = currentUser.UserId
            });

            unitOfWork.Commit();
            return employee.EmployeeCode;
        }
    }
}
