﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Jobs.OnRollCandidate
{
    public class OnRollCandidateValidation : AbstractValidator<OnRollCandidatecommand>
    {
        public OnRollCandidateValidation()
        {

        }
    }
}
