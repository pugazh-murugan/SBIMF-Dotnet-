﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;

namespace TCS.HumanResourceManagement.Business.Jobs.CandidateSearch
{
    public class CandidateSearchHandler : IRequestHandler<CandidateSearchQuery, List<ViewSearchCandidates>>
    {
        private readonly IUnitOfWork unitOfWork;

        public CandidateSearchHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<List<ViewSearchCandidates>> Handle(CandidateSearchQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.JobsRepository.SearchCandidates(request.SearchText);
            return result;
        }
    }
}
