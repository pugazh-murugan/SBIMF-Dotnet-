﻿using System;
using System.Collections.Generic;
using System.Text;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;

namespace TCS.HumanResourceManagement.Business.Jobs.CandidateSearch
{
   public class CandidateSearchQuery : IRequest<List<ViewSearchCandidates>>
    {
        public string SearchText { get; set; }
    }
}
