﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Jobs.CandidateSearch
{
    public class CandidateSearchValidation : AbstractValidator<CandidateSearchQuery>
    {
        public CandidateSearchValidation()
        {

        }
    }
}
