﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Jobs.AddNewCandidate
{
    public class AddNewCandidateValidation:AbstractValidator<AddNewCandidateCommand>
    {
        public AddNewCandidateValidation(
            IUnitOfWork unitOfWork,
            ICryptographyHelper cryptographyHelper)
        {

            RuleFor(c => c.Location)
            .NotEmpty()
            .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.FirstName)
              .NotEmpty()
              .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.LastName)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.Gender)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.Email)
                .EmailAddress()
                .WithMessage(command => "{PropertyName} is not valid")
                .When(c => !(string.IsNullOrEmpty(c.Email)));

            RuleFor(c => c.MobileNumber)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.DateOfBirthInCertificate)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.InterviewDate)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

            this.IsCandidateAadharNumberExisit(unitOfWork, cryptographyHelper);

            this.IsCandidateMobileNumberExisit(unitOfWork);

            this.IsCandidatePANNumberExisit(unitOfWork, cryptographyHelper);

            RuleFor(c => c.DateOfBirthOriginal)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.ResidenceAddress)
                .AdddressValidation();

            RuleFor(c => c.PermanentAddress)
                .AdddressValidation();

            RuleFor(c => c.EmployeeExperiences)
                .SetCollectionValidator(new ExperienceDetailsValidator());
        }
    }
}
