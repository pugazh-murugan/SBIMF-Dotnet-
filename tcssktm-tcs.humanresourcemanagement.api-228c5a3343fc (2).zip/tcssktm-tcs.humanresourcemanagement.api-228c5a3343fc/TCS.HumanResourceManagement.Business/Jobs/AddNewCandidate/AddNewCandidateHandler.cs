﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using Microsoft.Extensions.Options;
using TCS.HumanResourceManagement.Business.Helper;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.Business.Utilities;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;

namespace TCS.HumanResourceManagement.Business.Jobs.AddNewCandidate
{
    public class AddNewCandidateHandler : IRequestHandler<AddNewCandidateCommand, int>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        private readonly ICryptographyHelper cryptographyHelper;

        private readonly IOptions<AppSettings> appSettings;

        public AddNewCandidateHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser,
            ICryptographyHelper cryptographyHelper,
            IOptions<AppSettings> appSettings)
        {
            this.currentUser = currentUser;
            this.unitOfWork = unitOfWork;
            this.cryptographyHelper = cryptographyHelper;
            this.appSettings = appSettings;
        }

        public async Task<int> Handle(AddNewCandidateCommand request, CancellationToken cancellationToken)
        {
            var employeeId = Guid.NewGuid();
            int applicationNumber = RandomNumber.GenerateRandomNumber();
            string filePath = string.Empty, fileName = "profile";

            if (request.Avatar.Contains("user_profile"))
            {
                request.Avatar = string.Empty;
            }

            if (!string.IsNullOrEmpty(request.Avatar))
            {
                filePath = string.Format("{0}\\{1}_{2}_{3}", appSettings.Value.UploadedDocumentLocation, applicationNumber, request.FirstName.Trim(), request.LastName.Trim());
            }

            var residenceAddress = new Addresses()
            {
                AddressLine1 = request.ResidenceAddress.AddressLine1,
                AddressLine2 = request.ResidenceAddress.AddressLine2,
                State = request.ResidenceAddress.State,
                City = request.ResidenceAddress.City,
                Country = request.ResidenceAddress.Country,
                PostalCode = request.ResidenceAddress.PostalCode,
                AddressType = (int)request.ResidenceAddress.AddressType
            };
            var permanentAddress = new Addresses()
            {
                AddressLine1 = request.PermanentAddress.AddressLine1,
                AddressLine2 = request.PermanentAddress.AddressLine2,
                State = request.PermanentAddress.State,
                City = request.PermanentAddress.City,
                Country = request.PermanentAddress.Country,
                PostalCode = request.PermanentAddress.PostalCode,
                AddressType = (int)request.PermanentAddress.AddressType
            };
            var employeeAddresses = new EmployeeAddresses()
            {
                Id = Guid.NewGuid(),
                EmployeeId = employeeId,
                ResidenceAddress = residenceAddress,
                PermanentAddress = permanentAddress,
                Created = DateTime.Now,
                CreatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now,
                LastUpdatedBy = currentUser.UserId
            };

            List<EmployeeExperiences> employeeExperiences = new List<EmployeeExperiences>();
            foreach (var experience in request.EmployeeExperiences)
            {
                employeeExperiences.Add(new EmployeeExperiences()
                {
                    Id = Guid.NewGuid(),
                    EmployeeId = employeeId,
                    From = experience.From,
                    To = experience.To,
                    CompanyName = experience.CompanyName,
                    Designation = experience.Designation,
                    ReasonForLeaving = experience.ReasonForLeaving,
                    Created = DateTime.Now,
                    CreatedBy = currentUser.UserId,
                    LastUpdated = DateTime.Now,
                    LastUpdatedBy = currentUser.UserId
                });
            }

            var employeeQualification = new EmployeeQualifications()
            {
                Id=Guid.NewGuid(),
                EmployeeId=employeeId,
                Qualification=request.EmployeeQualifications.Qualification,
                University=request.EmployeeQualifications.University,
                Institution=request.EmployeeQualifications.Institution,
                YearOfPassedOut=request.EmployeeQualifications.YearOfPassedOut,
                Percentage=request.EmployeeQualifications.Percentage,
                Created = DateTime.Now,
                CreatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now,
                LastUpdatedBy = currentUser.UserId
            };

            List<DependentDetails> dependentDetails = new List<DependentDetails>();
            foreach(var item in request.DependentDetails)
            {
                dependentDetails.Add(new DependentDetails()
                {
                    Id = Guid.NewGuid(),
                    EmployeeId = employeeId,
                    Name = item.Name,
                    DateOfBirth = item.DateOfBirth,
                    Gender = item.Gender,
                    Occupation = item.Occupation,
                    Relationship = item.Relationship,
                    Created = DateTime.Now,
                    CreatedBy = currentUser.UserId,
                    LastUpdated = DateTime.Now,
                    LastUpdatedBy = currentUser.UserId
                });
            }

            var candidates = new Candidates()
            {
                Id = employeeId,
                Location = request.Location,
                Avatar = !string.IsNullOrEmpty(request.Avatar) ? string.Format("{0}\\{1}.png", filePath, fileName) : string.Empty,
                ApplicationId = applicationNumber,
                FirstName = request.FirstName,
                LastName = request.LastName,
                DateOfBirthInCertificate = request.DateOfBirthInCertificate,
                DateOfBirthOriginal = request.DateOfBirthOriginal,
                Age = request.Age,
                Gender = request.Gender,
                Email = request.Email,
                MobileNumber = request.MobileNumber,
                AlternateNumber = request.AlternateNumber,
                EmergencyContactNo = request.EmergencyContactNo,
                PANNumber = cryptographyHelper.Encrypt(request.PANNumber),
                AadharNumber = cryptographyHelper.Encrypt(request.AadharNumber),
                BloodGroup = request.BloodGroup,
                TotalYearOfExperience = request.TotalYearOfExperience,
                CurrentSalary = request.CurrentSalary,
                ExpectedSalary = request.ExpectedSalary,
                IsHostelRequired = request.IsHostelRequired,
                InterviewDate = request.InterviewDate,
                WeddingDay = request.WeddingDay,
                DateOfJoin = request.DateOfJoin,
                Comments = request.Comments,
                EmployeeAddresses = employeeAddresses,
                EmployeeExperiences = employeeExperiences,
                EmployeeQualifications = employeeQualification,
                DependentDetails = dependentDetails,
                Created = DateTime.Now,
                CreatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now,
                LastUpdatedBy = currentUser.UserId
            };

            await unitOfWork.JobsRepository.CreateNewCandidate(candidates);
            unitOfWork.Commit();

            if (!string.IsNullOrEmpty(request.Avatar))
            {
                ConvertImageDataAsFile.ConvertAsFile(request.Avatar, filePath, fileName);
            }

            return candidates.ApplicationId;
        }
    }
}
