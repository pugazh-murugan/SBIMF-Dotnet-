﻿using MediatR;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.Jobs.AddNewCandidate
{
    public class AddNewCandidateCommand : Candidate, IRequest<int>
    {
    }
}