﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;

namespace TCS.HumanResourceManagement.Business.Jobs.GetCandidates
{
    public class GetCandidatesHandler : IRequestHandler<GetCandidatesQuery, List<Candidates>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetCandidatesHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<List<Candidates>> Handle(GetCandidatesQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.JobsRepository.GetCandidates(request.InterviewDate, request.Location, request.ApplicationNumber);
            return result;
        }
    }
}
