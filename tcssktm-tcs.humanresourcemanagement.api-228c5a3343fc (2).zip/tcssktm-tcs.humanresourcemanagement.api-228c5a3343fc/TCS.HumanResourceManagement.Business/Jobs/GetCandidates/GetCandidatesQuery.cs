﻿using System;
using System.Collections.Generic;
using System.Text;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;

namespace TCS.HumanResourceManagement.Business.Jobs.GetCandidates
{
    public class GetCandidatesQuery : IRequest<List<Candidates>>
    {
        public DateTime? InterviewDate { get; set; }

        public Guid? Location { get; set; }

        public int? ApplicationNumber { get; set; }
    }
}
