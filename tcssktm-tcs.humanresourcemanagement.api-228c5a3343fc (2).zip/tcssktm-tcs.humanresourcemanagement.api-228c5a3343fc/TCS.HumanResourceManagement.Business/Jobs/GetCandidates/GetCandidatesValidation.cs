﻿using System;
using System.Collections.Generic;
using System.Text;
using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Jobs.GetCandidates
{
    public class GetCandidatesValidation : AbstractValidator<GetCandidatesQuery>
    {
        public GetCandidatesValidation()
        {

        }
    }
}
