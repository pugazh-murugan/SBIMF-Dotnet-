﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Model;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public  class EmployeeDetailsValidator<T> : AbstractValidator<T> where T : EmployeeDetails
    {
        public EmployeeDetailsValidator()
        {
            RuleFor(c => c.Designation)
                .NotNull()
                .WithMessage(command => "{PropertyName} should not be blank.");

            RuleFor(c => c.BasicSalary)
                .GreaterThanOrEqualTo(0)
                .WithMessage(command => "{PropertyName} shoule be positive value");

            RuleFor(c => c.HRA)
               .GreaterThanOrEqualTo(0)
               .WithMessage(command => "{PropertyName} shoule be positive value");

            RuleFor(c => c.PF)
               .GreaterThanOrEqualTo(0)
               .WithMessage(command => "{PropertyName} shoule be positive value");

            RuleFor(c => c.DA)
               .GreaterThanOrEqualTo(0)
               .WithMessage(command => "{PropertyName} shoule be positive value");

            RuleFor(c => c.SpecialAllowance)
               .GreaterThanOrEqualTo(0)
               .WithMessage(command => "{PropertyName} shoule be positive value");

            RuleFor(c => c.FoodAllowance)
               .GreaterThanOrEqualTo(0)
               .WithMessage(command => "{PropertyName} shoule be positive value");

            RuleFor(c => c.CarAllowance)
               .GreaterThanOrEqualTo(0)
               .WithMessage(command => "{PropertyName} shoule be positive value");

            RuleFor(c => c.MedicalAllowance)
               .GreaterThanOrEqualTo(0)
               .WithMessage(command => "{PropertyName} shoule be positive value");

            RuleFor(c => c.MobileAllowance)
               .GreaterThanOrEqualTo(0)
               .WithMessage(command => "{PropertyName} shoule be positive value");
           
        }
    }
}
