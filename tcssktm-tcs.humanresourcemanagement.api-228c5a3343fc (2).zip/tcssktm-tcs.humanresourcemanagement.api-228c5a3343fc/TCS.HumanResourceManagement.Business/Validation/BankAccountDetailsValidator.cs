﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public class BankAccountDetailsValidator<T> : AbstractValidator<T> where T : BankAccountDetails
    {

        public BankAccountDetailsValidator()
        {

            RuleFor(c => c.AccountantName)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.BankName)
               .NotEmpty()
               .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.AccountNumber)
               .NotEmpty()
               .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.IfscCode)
               .NotEmpty()
               .WithMessage(command => "{PropertyName} should not be blank");
        }

    }
}
