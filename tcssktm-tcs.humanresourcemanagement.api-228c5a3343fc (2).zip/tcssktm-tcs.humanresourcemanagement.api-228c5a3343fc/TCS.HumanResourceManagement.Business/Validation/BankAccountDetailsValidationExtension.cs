﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class BankAccountDetailsValidationExtension
    {
        public static IRuleBuilderOptions<T, BankAccountDetails> IsValidBankAccount<T>(this IRuleBuilder<T, BankAccountDetails> ruleBuilder)
           => ruleBuilder.SetValidator(new BankAccountDetailsValidator<BankAccountDetails>());
    }
}
