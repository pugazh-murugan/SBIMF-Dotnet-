﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class EmailAccountValidationExtensions
    {
        public static void IsOfficialEmailExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IOfficialEmail
        {
            validator.RuleFor(c => c.OfficialEmail)
                     .NotEmpty()
                     .MustAsync(async (officialEmail, _) => !await unitOfWork.EmployeeRepository.IsExisitOfficialEmail(officialEmail))
                     .WithMessage(command => "{PropertyName} already exist")
                     .When(c => !(string.IsNullOrEmpty(c.OfficialEmail)));
        }

        public static void IsPersonalEmailExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IPersonalEmail
        {
            validator.RuleFor(c => c.PersonalEmail)
                     .NotEmpty()
                     .MustAsync(async (personalEmail, _) => !await unitOfWork.EmployeeRepository.IsExisitPersonalEmail(personalEmail))
                     .WithMessage(command => "{PropertyName} already exist")
                     .When(c => !(string.IsNullOrEmpty(c.PersonalEmail)));
        }
    }
}
