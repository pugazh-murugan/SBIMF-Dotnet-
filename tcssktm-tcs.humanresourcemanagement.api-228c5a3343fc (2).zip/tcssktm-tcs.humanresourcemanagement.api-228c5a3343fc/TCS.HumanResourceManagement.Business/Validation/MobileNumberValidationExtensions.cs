﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static  class MobileNumberValidationExtensions
    {
        public static void IsCandidateMobileNumberExisit<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IMobileNumber
        {
            validator.RuleFor(c => c.MobileNumber)
                     .NotEmpty()
                     .MustAsync(async (mobileNumber, _) => !await unitOfWork.JobsRepository.IsMobileNumberExisit(mobileNumber))
                     .WithMessage(command => "{PropertyName} already exist");
        }

        public static void IsEmployeeMobileNumberExisit<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IMobileNumber
        {
            validator.RuleFor(c => c.MobileNumber)
                     .NotEmpty()
                     .MustAsync(async (mobileNumber, _) => !await unitOfWork.JobsRepository.IsMobileNumberExisit(mobileNumber))
                     .WithMessage(command => "{PropertyName} already exist");
        }

        
    }
}
