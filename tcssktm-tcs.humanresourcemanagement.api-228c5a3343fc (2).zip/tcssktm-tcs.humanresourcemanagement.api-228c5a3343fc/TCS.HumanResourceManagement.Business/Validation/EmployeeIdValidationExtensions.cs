﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class EmployeeIdValidationExtensions
    {
        public static void IsEmployeeIdExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IEmployeeId
        {
            validator.RuleFor(c => c.EmployeeId)
                     .NotEmpty()
                     .MustAsync(async (employeeId, _) => await unitOfWork.EmployeeRepository.IsExist(employeeId))
                     .WithMessage(command => "{PropertyName} does not exisit");
        }

        public static void IsAssignedReportingManagerToEmployee<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IEmployeeId
        {
            validator.RuleFor(c => c.EmployeeId)
                     .NotEmpty()
                     .MustAsync(async (employeeId, _) => await unitOfWork.EmployeeRepository.IsAssignedReportingManagerToEmployee(employeeId))
                     .WithMessage(command => "Not yet assign reporting manager. Kindly assign reporting manager and try again.");
        }
    }
}
