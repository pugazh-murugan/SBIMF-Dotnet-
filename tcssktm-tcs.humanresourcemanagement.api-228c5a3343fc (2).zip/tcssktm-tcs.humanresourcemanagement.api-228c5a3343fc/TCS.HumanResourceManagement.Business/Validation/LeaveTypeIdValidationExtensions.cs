﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class LeaveTypeIdValidationExtensions
    {
        public static void IsLeaveTypeIdExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : ILeaveTypeId
        {
            validator.RuleFor(c => c.LeaveTypeId)
                     .NotEmpty()
                     .MustAsync(async (leaveType, _) => await unitOfWork.LeaveRepository.IsExist(leaveType))
                     .WithMessage(command => "{PropertyName} does not exisit");
        }
    }
}
