﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Model;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class EmployeeDetailsValidationExtension
    {
        public static IRuleBuilderOptions<T, EmployeeDetails> IsValidEmployeeDetails<T>(this IRuleBuilder<T, EmployeeDetails> ruleBuilder)
            => ruleBuilder.SetValidator(new EmployeeDetailsValidator<EmployeeDetails>());
    }
}
