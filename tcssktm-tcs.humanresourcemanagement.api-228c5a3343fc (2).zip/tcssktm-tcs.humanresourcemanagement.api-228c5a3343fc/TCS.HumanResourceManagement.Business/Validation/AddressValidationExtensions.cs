﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class AddressValidationExtensions
    {
        public static IRuleBuilderOptions<T, Addresses> AdddressValidation<T>(this IRuleBuilder<T, Addresses> ruleBuilder)
          => ruleBuilder.SetValidator(new AddressValidator<Addresses>());
    }
}
