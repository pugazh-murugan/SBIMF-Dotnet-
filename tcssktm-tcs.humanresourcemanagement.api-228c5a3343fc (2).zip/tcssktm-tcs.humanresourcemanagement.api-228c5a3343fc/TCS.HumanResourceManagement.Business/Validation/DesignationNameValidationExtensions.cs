﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class DesignationNameValidationExtensions
    {
        public static void IsDesignationNameExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IDescription
        {
            validator.RuleFor(c => c.Description)
                     .NotEmpty()
                     .WithMessage(command => "Designation name should not be blank.")
                     .MustAsync(async (description, _) => !await unitOfWork.DesignationRepository.IsNameExist(description))
                     .WithMessage(command => "Designation name : {PropertyValue} already exist");
        }
    }
}
