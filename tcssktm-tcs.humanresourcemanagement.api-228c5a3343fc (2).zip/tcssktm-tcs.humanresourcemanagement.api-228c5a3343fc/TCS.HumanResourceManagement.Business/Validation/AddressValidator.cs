﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public class AddressValidator<T> : AbstractValidator<T> where T : Addresses
    {
        public AddressValidator()
        {
            RuleFor(c => c.AddressLine1)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.PostalCode)
                .Length(6)
                .WithMessage(command => "{PropertyName} length should be 6")
                .When(c => !string.IsNullOrEmpty(c.PostalCode));
        }
    }
}
