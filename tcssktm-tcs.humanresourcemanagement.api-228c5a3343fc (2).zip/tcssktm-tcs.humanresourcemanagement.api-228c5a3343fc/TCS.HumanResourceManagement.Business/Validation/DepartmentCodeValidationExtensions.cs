﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class DepartmentCodeValidationExtensions
    {
        public static void IsDepartmentCodeExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IDepartmentCode
        {
            validator.RuleFor(c => c.Code)
                     .NotEmpty()
                     .WithMessage(command=> "Department code should not be blank.")
                     .MustAsync(async (code, _) => !await unitOfWork.DepartmentRepository.IsExist(code))
                     .WithMessage(command => "Department code: {PropertyValue} already exist");
        }
    }
}
