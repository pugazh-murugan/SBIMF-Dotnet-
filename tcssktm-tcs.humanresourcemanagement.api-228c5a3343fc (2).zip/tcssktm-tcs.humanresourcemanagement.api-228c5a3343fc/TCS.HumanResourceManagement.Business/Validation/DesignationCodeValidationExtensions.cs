﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class DesignationCodeValidationExtensions
    {
        public static void IsDesignationCodeExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : ICode
        {
            validator.RuleFor(c => c.Code)
                     .NotEmpty()
                     .WithMessage(command => "Designation code should not be blank.")
                     .MustAsync(async (code, _) => !await unitOfWork.DesignationRepository.IsExist(code))
                     .WithMessage(command => "Designation code: {PropertyValue} already exist");
        }
    }
}
