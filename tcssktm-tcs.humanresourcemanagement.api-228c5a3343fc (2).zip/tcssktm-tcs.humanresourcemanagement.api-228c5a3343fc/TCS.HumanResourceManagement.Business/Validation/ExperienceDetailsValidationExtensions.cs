﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class ExperienceDetailsValidationExtensions
    {
        //public static IRuleBuilderOptions<T, EmployeeExperiences> IsValidEmployeeExperience<T>(this IRuleBuilder<T, EmployeeExperiences> ruleBuilder)
        //   => ruleBuilder.SetValidator(new ExperienceDetailsValidator<EmployeeExperiences>());
    }
}
