﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class AadharNumberValidationExtensions
    {
        public static void IsCandidateAadharNumberExisit<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork, ICryptographyHelper cryptographyHelper) where T : IAadharNumber
        {
            validator.RuleFor(c => c.AadharNumber)
                     .NotEmpty()
                     .MustAsync(async (aadharNumber, _) => !await unitOfWork.JobsRepository.IsAadharExisit(cryptographyHelper.Encrypt(aadharNumber)))
                     .WithMessage(command => "{PropertyName} already exist");
        }

        public static void IsAadharNumberExisit<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork, ICryptographyHelper cryptographyHelper) where T : IAadharNumber
        {
            validator.RuleFor(c => c.AadharNumber)
                     .NotEmpty()
                     .MustAsync(async (aadharNumber, _) => !await unitOfWork.EmployeeRepository.IsAadharExisit(cryptographyHelper.Encrypt(aadharNumber)))
                     .WithMessage(command => "{PropertyName} already exist");
        }
    }
}
