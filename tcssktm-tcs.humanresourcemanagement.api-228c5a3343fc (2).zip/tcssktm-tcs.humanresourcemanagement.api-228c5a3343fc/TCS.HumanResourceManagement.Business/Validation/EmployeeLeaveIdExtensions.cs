﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class EmployeeLeaveIdExtensions
    {
        public static void IsEmployeeLeaveIdExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IEmployeeLeaveId
        {
            validator.RuleFor(c => c.EmployeeLeaveId)
                     .NotEmpty()
                     .MustAsync(async (employeeLeaveId, _) => await unitOfWork.LeaveRepository.IsEmployeeLeaveIdExist(employeeLeaveId))
                     .WithMessage(command => "{PropertyName} does not exisit");
        }
    }
}
