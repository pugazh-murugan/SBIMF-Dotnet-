﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Model;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public class ExperienceDetailsValidator : AbstractValidator<EmployeeExperiences>
    {
        public ExperienceDetailsValidator()
        {
            RuleFor(c => c.From)
                .NotEmpty()
                .WithMessage(command => "Joining should not be blank");

            RuleFor(c => c.To)
                .NotEmpty()
                .WithMessage(command => "Relieving date should not be blank");

            RuleFor(c => c.To)
                .GreaterThan(c => c.From)
                .WithMessage(command => "Relieving should be greater than Joining date");

            RuleFor(c => c.CompanyName)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.Designation)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");

            RuleFor(c => c.ReasonForLeaving)
                .NotEmpty()
                .WithMessage(command => "{PropertyName} should not be blank");
        }
    }
}
