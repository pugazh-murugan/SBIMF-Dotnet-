﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class EmployeeCodeValidationExtensions
    {
        public static void IsEmployeeCodeExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IEmployeeCode
        {
            validator.RuleFor(c => c.EmployeeCode)
                     .NotEmpty()
                     .MustAsync(async  (employeeCode, _) => !await unitOfWork.EmployeeRepository.IsExist(employeeCode))
                     .WithMessage(command => "{PropertyName} already exist");
        }

        public static void IsEmployeeCodeNotExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IEmployeeCode
        {
            validator.RuleFor(c => c.EmployeeCode)
                     .NotEmpty()
                     .MustAsync(async (employeeCode, _) => await unitOfWork.EmployeeRepository.IsExist(employeeCode))
                     .WithMessage(command => "{PropertyName} does not exist");
        }

        public static void IsReportingManagerCodeNotExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IReportingManagerCode
        {
            validator.RuleFor(c => c.ReportingManagerCode)
                     .NotEmpty()
                     .MustAsync(async (employeeCode, _) => await unitOfWork.EmployeeRepository.IsExist(employeeCode))
                     .WithMessage(command => "{PropertyName} does not exist");
        }
    }
}
