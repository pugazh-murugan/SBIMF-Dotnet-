﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class DepartmentIdValidationExtensions
    {
        public static void IsDepartmentIdExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IDepartmentId
        {
            validator.RuleFor(c => c.DepartmentId)
                     .NotEmpty()
                     .WithMessage(command => "{PropertyName} should not be blank.")
                     .MustAsync(async (departmentId, _) => await unitOfWork.DepartmentRepository.IsExist(departmentId.Value))
                     .When(c=>c.DepartmentId.HasValue)
                     .WithMessage(command => "{PropertyName} does not exist");
        }
    }
}
