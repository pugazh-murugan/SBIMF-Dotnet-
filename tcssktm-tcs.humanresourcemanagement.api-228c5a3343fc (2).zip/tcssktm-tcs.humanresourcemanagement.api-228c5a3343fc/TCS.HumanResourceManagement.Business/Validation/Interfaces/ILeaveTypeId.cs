﻿using System;

namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface ILeaveTypeId
    {
        Guid LeaveTypeId { get; set; }
    }
}
