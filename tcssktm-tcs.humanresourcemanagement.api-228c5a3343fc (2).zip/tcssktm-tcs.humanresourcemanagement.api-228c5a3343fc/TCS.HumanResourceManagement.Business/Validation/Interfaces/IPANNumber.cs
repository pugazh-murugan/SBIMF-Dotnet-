﻿namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IPANNumber
    {
        string PANNumber { get; set; }
    }
}
