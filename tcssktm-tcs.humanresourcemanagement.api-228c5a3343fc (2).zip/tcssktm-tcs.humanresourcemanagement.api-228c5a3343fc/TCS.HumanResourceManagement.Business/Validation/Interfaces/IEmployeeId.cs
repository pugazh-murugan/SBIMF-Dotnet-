﻿using System;

namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IEmployeeId
    {
        Guid EmployeeId { get; set; }
    }
}
