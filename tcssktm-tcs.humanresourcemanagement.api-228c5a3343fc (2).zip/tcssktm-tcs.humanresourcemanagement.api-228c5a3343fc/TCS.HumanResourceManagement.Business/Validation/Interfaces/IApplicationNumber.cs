﻿namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IApplicationNumber
    {
        int ApplicationNumber { get; set; }
    }
}
