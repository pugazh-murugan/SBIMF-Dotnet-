﻿using System;

namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IEmployeeLeaveId
    {
        Guid EmployeeLeaveId { get; set; }
    }
}
