﻿namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IMobileNumber
    {
        string MobileNumber { get; set; }
    }
}
