﻿using System;

namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IDepartmentId
    {
        Guid? DepartmentId { get; set; }
    }
}
