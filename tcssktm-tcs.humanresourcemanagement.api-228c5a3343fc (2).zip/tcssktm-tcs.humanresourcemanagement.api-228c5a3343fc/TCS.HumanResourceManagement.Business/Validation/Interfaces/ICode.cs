﻿namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface ICode
    {
        string Code { get; set; }
    }
}
