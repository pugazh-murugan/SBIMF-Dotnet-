﻿namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IReportingManagerCode 
    {
        string ReportingManagerCode { get; set; }
    }
}
