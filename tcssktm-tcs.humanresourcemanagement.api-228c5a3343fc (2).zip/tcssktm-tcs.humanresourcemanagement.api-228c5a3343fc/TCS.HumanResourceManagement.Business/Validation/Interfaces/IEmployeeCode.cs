﻿namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IEmployeeCode
    {
        string EmployeeCode { get; set; }
    }
}
