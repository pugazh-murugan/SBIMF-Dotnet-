﻿namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IDescription
    {
        string Description { get; set; }
    }
}
