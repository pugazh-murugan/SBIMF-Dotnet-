﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IDepartmentCode
    {
        string Code { get; set; }

        string Description { get; set; }
    }
}
