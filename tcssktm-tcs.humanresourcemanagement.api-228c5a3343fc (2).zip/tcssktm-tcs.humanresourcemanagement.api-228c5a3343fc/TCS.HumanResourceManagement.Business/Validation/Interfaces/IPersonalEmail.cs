﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IPersonalEmail
    {
        string PersonalEmail { get; set; }
    }
}
