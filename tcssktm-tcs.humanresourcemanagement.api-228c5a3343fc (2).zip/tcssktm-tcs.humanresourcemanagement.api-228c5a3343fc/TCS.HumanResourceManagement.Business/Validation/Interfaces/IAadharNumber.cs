﻿namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IAadharNumber
    {
        string AadharNumber { get; set; }
    }
}
