﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Validation.Interfaces
{
    public interface IOfficialEmail
    {
        string OfficialEmail { get; set; }
    }
}
