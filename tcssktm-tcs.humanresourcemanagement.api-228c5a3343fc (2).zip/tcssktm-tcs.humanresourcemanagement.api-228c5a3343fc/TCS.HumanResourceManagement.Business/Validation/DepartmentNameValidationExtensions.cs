﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class DepartmentNameValidationExtensions
    {
        public static void IsDepartmentNameExist<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork) where T : IDepartmentCode
        {
            validator.RuleFor(c => c.Description)
                     .NotEmpty()
                     .WithMessage(command => "Department name should not be blank.")
                     .MustAsync(async (description, _) => !await unitOfWork.DepartmentRepository.IsNameExist(description))
                     .WithMessage(command => "Department name : {PropertyValue} already exist");
        }
    }
}
