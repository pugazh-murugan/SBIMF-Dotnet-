﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Security;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Validation
{
    public static class PanNumberValidationExtensions
    {
        public static void IsCandidatePANNumberExisit<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork, ICryptographyHelper cryptographyHelper) where T : IPANNumber
        {
            validator.RuleFor(c => c.PANNumber)
                     .NotEmpty()
                     .MustAsync(async (panNumber, _) => !await unitOfWork.JobsRepository.IsPANNumberExisit(cryptographyHelper.Encrypt(panNumber)))
                     .WithMessage(command => "{PropertyName} already exist");
        }

        public static void IsPANNumberExisit<T>(this AbstractValidator<T> validator, IUnitOfWork unitOfWork, ICryptographyHelper cryptographyHelper) where T : IPANNumber
        {
            validator.RuleFor(c => c.PANNumber)
                     .NotEmpty()
                     .MustAsync(async (panNumber, _) => !await unitOfWork.EmployeeRepository.IsPANNumberExisit(cryptographyHelper.Encrypt(panNumber)))
                     .WithMessage(command => "{PropertyName} already exist");
        }
    }
}
