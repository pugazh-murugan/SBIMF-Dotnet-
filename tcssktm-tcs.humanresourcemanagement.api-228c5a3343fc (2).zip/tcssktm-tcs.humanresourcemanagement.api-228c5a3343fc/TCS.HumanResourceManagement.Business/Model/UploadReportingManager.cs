﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class UploadReportingManager
    {
        public string EmployeeCode { get; set; }

        public string SupervisorCode { get; set; }

        public string FloorHeadCode { get; set; }
    }
}
