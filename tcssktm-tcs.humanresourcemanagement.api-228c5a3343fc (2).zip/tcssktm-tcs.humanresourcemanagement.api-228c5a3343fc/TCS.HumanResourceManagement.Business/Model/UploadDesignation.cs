﻿using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class UploadDesignation : ICode, IDescription
    {
        public string Code { get; set; }

        public string Description { get ; set ; }
    }
}
