﻿namespace TCS.HumanResourceManagement.Business.Model
{
    public class AssociatePayrollModel
    {
        public string AssociateCode { get; set; }

        public string MonthOfPayroll { get; set; }

        public decimal Incentives { get; set; }
    }
}
