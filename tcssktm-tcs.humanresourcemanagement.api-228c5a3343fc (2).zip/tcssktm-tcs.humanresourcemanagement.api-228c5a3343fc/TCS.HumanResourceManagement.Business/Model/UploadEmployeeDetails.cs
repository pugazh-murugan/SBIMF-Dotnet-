﻿using System;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class UploadEmployeeDetails
    {
        public string Branch { get; set; }

        public string EmployeeCode { get; set; }

        public string EmployeeName { get; set; }

        public string Section { get; set; }

        public string Designation { get; set; }

        public DateTime DateOfBirth { get; set; }

        public DateTime DateOfJoin { get; set; }

        public string FatherName { get; set; }

        public string Qualification { get; set; }

        public string BloodGroup { get; set; }

        public string Mobile { get; set; }

        public string MaritalStatus { get; set; }
    }
}
