﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class EmployeeExperiences
    {
        private DateTime from;

        private DateTime to;

        [DataType(DataType.Date)]
        public DateTime From
        {
            get { return from; }
            set { from = value.Date; }
        }

        [DataType(DataType.Date)]
        public DateTime To
        {
            get { return to; }
            set { to = value.Date; }
        }

        public string CompanyName { get; set; }

        public string Designation { get; set; }

        public string ReasonForLeaving { get; set; }
    }
}
