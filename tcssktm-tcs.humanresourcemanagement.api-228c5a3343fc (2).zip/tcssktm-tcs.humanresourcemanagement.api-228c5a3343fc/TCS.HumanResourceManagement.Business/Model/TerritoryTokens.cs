﻿using System;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class TerritoryTokens
    {
        public Guid TerritoryId { get; set; }

        public string Token { get; set; }

        public string Name { get; set; }
    }
}
