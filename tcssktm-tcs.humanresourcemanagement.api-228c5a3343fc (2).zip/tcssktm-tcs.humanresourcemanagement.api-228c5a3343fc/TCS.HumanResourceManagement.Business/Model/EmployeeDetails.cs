﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class EmployeeDetails : IDepartmentId
    {
        [JsonIgnore]
        public Guid EmployeeId { get; set; }

        public Guid Designation { get; set; }

        public decimal BasicSalary { get; set; } = 0;

        public decimal HRA { get; set; } = 0;

        public decimal PF { get; set; } = 0;

        public decimal DA { get; set; } = 0;

        public decimal SpecialAllowance { get; set; } = 0;

        public decimal FoodAllowance { get; set; } = 0;

        public decimal CarAllowance { get; set; } = 0;

        public decimal MedicalAllowance { get; set; } = 0;

        public decimal MobileAllowance { get; set; } = 0;

        public Guid? DepartmentId { get; set; }
    }
}
