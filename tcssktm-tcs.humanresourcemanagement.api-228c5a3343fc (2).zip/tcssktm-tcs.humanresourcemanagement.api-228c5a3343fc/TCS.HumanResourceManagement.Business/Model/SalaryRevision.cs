﻿using System;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class SalaryRevision : IEmployeeCode
    {
        public string EmployeeCode { get; set; }

        public string Department { get; set; }

        public string Designation { get; set; }

        public decimal BasicSalary { get; set; } = 0;

        public decimal HRA { get; set; } = 0;

        public decimal PF { get; set; } = 0;

        public decimal DA { get; set; } = 0;

        public decimal SpecialAllowance { get; set; } = 0;

        public decimal FoodAllowance { get; set; } = 0;

        public decimal CarAllowance { get; set; } = 0;

        public decimal MedicalAllowance { get; set; } = 0;

        public decimal MobileAllowance { get; set; } = 0;
    }
}
