﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class UploadEmployeeBankAccountDetails : BankAccountDetails
    {
        public string EmployeeCode { get; set; }

        public string UanNumber { get; set; }
    }
}
