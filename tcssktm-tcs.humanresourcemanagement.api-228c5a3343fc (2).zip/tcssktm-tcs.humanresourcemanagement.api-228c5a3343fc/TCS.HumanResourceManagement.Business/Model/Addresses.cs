﻿using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.Business.Enums;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class Addresses
    {
        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string State { get; set; }

        public string City { get; set; }

        public string Country { get; set; }

        public string PostalCode { get; set; }

        public AddressType AddressType { get; set; }
    }
}
