﻿using System;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class SalesAssociates
    {
        public Guid Id { get; set; }

        public string AssociateCode { get; set; }

        public string AssociateName { get; set; }

        public Guid Branch { get; set; }

        public string Gender { get; set; }

        public Guid ProductSectionId { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }
    }
}
