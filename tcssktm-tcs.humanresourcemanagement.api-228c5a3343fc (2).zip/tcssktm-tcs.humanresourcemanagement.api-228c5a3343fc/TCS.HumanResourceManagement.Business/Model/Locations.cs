﻿using System.Collections.Generic;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class Locations
    {
        public List<TerritoryTokens> TerritoryTokens { get; set; }
    }

}
