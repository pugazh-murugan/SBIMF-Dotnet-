﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class Candidate : IMobileNumber, IPANNumber, IAadharNumber
    {
        public Candidate()
        {
            EmployeeExperiences = new List<EmployeeExperiences>();
            EmployeeQualifications = new EmployeeQualifications();
            DependentDetails = new List<DependentDetails>();
        }

        private DateTime dateOfBirthInCertificate;
        private DateTime dateOfBirthOriginal;
        private DateTime interviewDate;
        private DateTime dateOfJoin;

        public Guid Location { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        [DataType(DataType.Date)]
        public DateTime DateOfBirthInCertificate
        {
            get { return dateOfBirthInCertificate; }
            set { dateOfBirthInCertificate = value.Date; }
        }

        [DataType(DataType.Date)]
        public DateTime DateOfBirthOriginal
        {
            get { return dateOfBirthOriginal; }
            set { dateOfBirthOriginal = value.Date; }
        }

        public int Age { get; set; }

        public string Gender { get; set; }

        public string Email { get; set; } = null;

        public string MobileNumber { get; set; }

        public string AlternateNumber { get; set; } = null;

        public string EmergencyContactNo { get; set; }

        public string PANNumber { get; set; }

        public string AadharNumber { get; set; }

        public string Avatar { get; set; } = null;

        public string BloodGroup { get; set; }

        public int TotalYearOfExperience { get; set; }

        public decimal? CurrentSalary { get; set; }

        public decimal ExpectedSalary { get; set; }

        public bool IsHostelRequired { get; set; }

        [DataType(DataType.Date)]
        public DateTime InterviewDate
        {
            get { return interviewDate; }
            set { interviewDate = value.Date; }
        }

        [DataType(DataType.Date)]
        public DateTime DateOfJoin
        {
            get { return dateOfJoin; }
            set { dateOfJoin = value.Date; }
        }

        [DataType(DataType.Date)]
        public DateTime? WeddingDay { get; set; }

        public string Comments { get; set; }

        public Addresses ResidenceAddress { get; set; }

        public Addresses PermanentAddress { get; set; }

        public List<EmployeeExperiences> EmployeeExperiences { get; set; }

        public EmployeeQualifications EmployeeQualifications { get; set; }

        public List<DependentDetails> DependentDetails { get; set; }
    }
}
