﻿namespace TCS.HumanResourceManagement.Business.Model
{
    public class EmployeeQualifications
    {
        public string Qualification { get; set; }

        public string University { get; set; }

        public int YearOfPassedOut { get; set; }

        public double Percentage { get; set; }

        public string Institution { get; set; }
    }
}
