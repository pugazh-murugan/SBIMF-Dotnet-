﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class PostUserRequest
    {
        public string DisplayName { get; set; }

        public string UserName { get; set; }

        public string Password { get; set; }

        public string Avatar { get; set; }

        public bool IsActive { get; set; }

        public Guid UserId { get; set; }
    }
}
