﻿using System;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class Branches
    {
        public Guid Id { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }
    }
}
