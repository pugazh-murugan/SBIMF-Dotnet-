﻿using System;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class BankAccountDetails 
    {
        public string AccountNumber { get; set; }

        public string AccountantName { get; set; }

        public string BankName { get; set; }

        public string IfscCode { get; set; }

    }
}