﻿using System;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class DependentDetails
    {

        public string Name { get; set; }

        public string Gender { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public string Occupation { get; set; }

        public string Relationship { get; set; }
    }
}
