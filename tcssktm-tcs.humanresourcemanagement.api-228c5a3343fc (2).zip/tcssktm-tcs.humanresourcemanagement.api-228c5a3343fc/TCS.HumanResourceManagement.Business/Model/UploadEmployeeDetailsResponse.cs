﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.Business.Model
{
    public class UploadEmployeeDetailsResponse
    {
        public string EmployeeCode { get; set; }

        public string EmployeeName { get; set; }

        public int Status { get; set; }

        public string ErrorMessage { get; set; }
    }
}
