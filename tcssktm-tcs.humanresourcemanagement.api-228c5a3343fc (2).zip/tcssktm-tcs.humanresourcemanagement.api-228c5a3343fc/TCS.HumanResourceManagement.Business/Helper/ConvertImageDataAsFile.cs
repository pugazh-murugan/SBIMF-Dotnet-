﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;

namespace TCS.HumanResourceManagement.Business.Helper
{
    public static class ConvertImageDataAsFile
    {
        public static void ConvertAsFile(string imageData, string fileLocation, string fileName)
        {
            byte[] imageByteArray = Convert.FromBase64String(imageData.Split(',').ToArray()[1]);
            using (MemoryStream ms = new MemoryStream(imageByteArray, 0, imageByteArray.Length))
            {
                ms.Write(imageByteArray, 0, imageByteArray.Length);
                using (Bitmap bitMap = new Bitmap(ms))
                {
                    if (!Directory.Exists(fileLocation)) { Directory.CreateDirectory(fileLocation); }
                    bitMap.Save(string.Format("{0}\\{1}.png", fileLocation, fileName));
                }
            }
        }
    }
}
