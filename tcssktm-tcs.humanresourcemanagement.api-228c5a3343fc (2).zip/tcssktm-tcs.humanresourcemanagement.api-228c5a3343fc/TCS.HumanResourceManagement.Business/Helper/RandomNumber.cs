﻿using System;

namespace TCS.HumanResourceManagement.Business.Helper
{
    public static class RandomNumber
    {
        public static int GenerateRandomNumber()
        {
            Random generator = new Random();
            int number = Convert.ToInt32(generator.Next(0, 999999).ToString("D6"));
            return number;
        }
    }
}
