﻿using System;

namespace TCS.HumanResourceManagement.Business.Helper
{
    public static class CalculateCasualLeave
    {
        public static int InitCasualLeave(DateTime dateOfJoin)
        {
            var monthEnd = DateTime.Now.AddMonths(1).AddDays((DateTime.Now.Day) * -1);
            int count = 0;

            for (DateTime dt = DateTime.Now.Date; dt < monthEnd; dt = dt.AddDays(1.0))
            {
                if (dt.DayOfWeek == DayOfWeek.Tuesday)
                {
                    count++;
                }
            }
            return count;
        }
    }
}
