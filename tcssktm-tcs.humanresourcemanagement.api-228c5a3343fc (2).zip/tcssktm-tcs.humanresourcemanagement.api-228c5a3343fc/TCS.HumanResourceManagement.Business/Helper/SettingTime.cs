﻿using System;

namespace TCS.HumanResourceManagement.Business.Helper
{
    public static class SettingTime
    {
        public static DateTime StartOfDay(this DateTime date)
        {
            return DateTime.Parse(date.ToShortDateString().Trim() + " 00:00:00");
        }

        public static DateTime EndOfDay(this DateTime date)
        {
            return DateTime.Parse(date.ToShortDateString().Trim() + " 23:59:59");
        }

        public static DateTime MonthStart(this DateTime date)
        {
            return new DateTime(date.Year, date.Month, 1);
        }

        public static DateTime EndOfMonth(this DateTime date)
        {
            var monthStart = DateTime.Now.MonthStart();
            return monthStart.AddMonths(1).AddDays(-1);
        }

        public static DateTime PayrollFrom(this DateTime date)
        {
            var monthStart = DateTime.Now.MonthStart();
            return monthStart.StartOfDay();
        }

        public static DateTime PayrollTo(this DateTime date)
        {
            var monthStart = DateTime.Now.EndOfMonth();
            return monthStart.EndOfDay();
        }

        public static int NumberOfWorkingDays(this DateTime date)
        {
            var weekOff = CalculateCasualLeave.InitCasualLeave(date.MonthStart());
            int numDays = DateTime.DaysInMonth(date.Year, date.Month);

            return numDays - weekOff;
        }
    }
}
