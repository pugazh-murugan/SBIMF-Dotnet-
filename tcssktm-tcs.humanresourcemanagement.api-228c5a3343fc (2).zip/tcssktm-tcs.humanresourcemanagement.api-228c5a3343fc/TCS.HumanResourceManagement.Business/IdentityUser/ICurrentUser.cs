﻿using System;

namespace TCS.HumanResourceManagement.Business.IdentityUser
{
    public interface ICurrentUser
    {
        Guid UserId { get; }
    }
}
