﻿using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.Business.IdentityUser
{
    public class CurrentUser : ICurrentUser
    {
        private readonly Guid UserId;
        private IUnitOfWork unitOfWork;

        public CurrentUser(
            IHttpContextAccessor httpContextAccessor,
            IUnitOfWork unitOfWork)
        {
            if (httpContextAccessor.HttpContext.User.HasClaim(c => c.Type.Equals("UserId", StringComparison.OrdinalIgnoreCase)))
            {
                UserId = Guid.Parse(httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type.Equals("UserId", StringComparison.OrdinalIgnoreCase)).Value);
            }

            this.unitOfWork = unitOfWork;
        }

        Guid ICurrentUser.UserId { get { return UserId; } }
    }
}
