﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Designations;

namespace TCS.HumanResourceManagement.Business.Designations.GetAllDesignations
{
    public class GetAllDesignationsHandler : IRequestHandler<GetAllDesignationsQuery, List<Designation>>
    {
        private readonly IUnitOfWork unitOfWork;

        public GetAllDesignationsHandler(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

        public async Task<List<Designation>> Handle(GetAllDesignationsQuery request, CancellationToken cancellationToken)
        {
            var result = await unitOfWork.DesignationRepository.GetAll();
            return result;
        }
    }
}
