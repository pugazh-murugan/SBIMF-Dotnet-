﻿using FluentValidation;

namespace TCS.HumanResourceManagement.Business.Designations.GetAllDesignations
{
    public class GetAllDesignationsValidation : AbstractValidator<GetAllDesignationsQuery>
    {
    }
}
