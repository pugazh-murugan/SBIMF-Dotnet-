﻿using System.Collections.Generic;
using MediatR;
using TCS.HumanResourceManagement.DataModel.Model.Designations;

namespace TCS.HumanResourceManagement.Business.Designations.GetAllDesignations
{
    public class GetAllDesignationsQuery : IRequest<List<Designation>>
    {
        public GetAllDesignationsQuery()
        {
        }
    }
}
