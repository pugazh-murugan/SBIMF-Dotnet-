﻿using System;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using TCS.HumanResourceManagement.Business.IdentityUser;
using TCS.HumanResourceManagement.DataContext;
using TCS.HumanResourceManagement.DataModel.Model.Designations;

namespace TCS.HumanResourceManagement.Business.Designations.AddNewDesignation
{
    public class AddNewDesignationHandler : IRequestHandler<AddNewDesignationCommand>
    {
        private readonly IUnitOfWork unitOfWork;

        private readonly ICurrentUser currentUser;

        public AddNewDesignationHandler(
            IUnitOfWork unitOfWork,
            ICurrentUser currentUser)
        {
            this.unitOfWork = unitOfWork;
            this.currentUser = currentUser;
        }

        public async Task<Unit> Handle(AddNewDesignationCommand request, CancellationToken cancellationToken)
        {
            var designation = new Designation()
            {
                Id = Guid.NewGuid(),
                Code = request.Code,
                Description = request.Description,
                Status = request.Status,
                Created = DateTime.Now,
                CreatedBy = currentUser.UserId,
                LastUpdated = DateTime.Now,
                LastUpdatedBy = currentUser.UserId
            };

            await unitOfWork.DesignationRepository.CreateNewDesignation(designation);
            unitOfWork.Commit();

            return Unit.Value;
        }
    }
}
