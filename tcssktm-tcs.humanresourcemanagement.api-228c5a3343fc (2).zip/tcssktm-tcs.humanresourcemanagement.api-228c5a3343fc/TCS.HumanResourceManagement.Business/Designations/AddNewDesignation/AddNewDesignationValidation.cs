﻿using FluentValidation;
using TCS.HumanResourceManagement.Business.Validation;
using TCS.HumanResourceManagement.DataContext;

namespace TCS.HumanResourceManagement.Business.Designations.AddNewDesignation
{
    public class AddNewDesignationValidation : AbstractValidator<AddNewDesignationCommand>
    {
        public AddNewDesignationValidation(IUnitOfWork unitOfWork)
        {
            this.IsDesignationCodeExist(unitOfWork);

            this.IsDesignationNameExist(unitOfWork);
        }
    }
}
