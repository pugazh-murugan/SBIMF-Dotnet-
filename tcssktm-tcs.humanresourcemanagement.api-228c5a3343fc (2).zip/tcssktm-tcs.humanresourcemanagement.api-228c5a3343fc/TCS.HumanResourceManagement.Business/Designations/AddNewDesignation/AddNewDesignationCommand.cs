﻿using MediatR;
using TCS.HumanResourceManagement.Business.Validation.Interfaces;

namespace TCS.HumanResourceManagement.Business.Designations.AddNewDesignation
{
    public class AddNewDesignationCommand : IRequest, ICode, IDescription
    {
        public string Code { get; set; }

        public string Description { get; set; }

        public bool Status { get; set; }
    }
}
