﻿using System;
using TCS.HumanResourceManagement.DataContext.Interfaces;

namespace TCS.HumanResourceManagement.DataContext
{
    public interface IUnitOfWork : IDisposable
    {
        IEmployeeRepository EmployeeRepository { get; }

        ILeaveRepository LeaveRepository { get; }

        IDepartmentRepository DepartmentRepository { get; }

        ITimeAndAttendanceRepository TimeAndAttendanceRepository { get; }

        IDesignationRepository DesignationRepository { get; }

        IJobsRepository JobsRepository { get; }

        IPayrollRepository PayrollRepository { get; }

        void Commit();
    }
}
