﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.DataContext.Interfaces
{
    public interface ITimeAndAttendanceRepository
    {
        Task<bool> IsEmployeeOnPresent(Guid employeeId);

        Task InsertOrUpdateTimeAndAttendance(EmployeeAttendance employeeAttendance);

        Task<List<ViewTimeAndAttendance>> ViewTimeAndAttendance(Guid? employeeId, DateTime? fromDate, DateTime? toDate, Guid? location);

        Task<bool> IsEmployeeAlreadyInOrOutByDate(string employeeCode, string punchType, DateTime startDate, DateTime endDate);

        Task InsertOndutyEntry(OnDuties onDuties);

        Task<List<OnDutiesViewModel>> GetOnDuties(Guid? branch, DateTime fromDate, DateTime toDate, Guid? employeeId);

        Task<OnDuties> EmployeeOnDuty(Guid employeeId, DateTime fromDate, DateTime toDate);

        Task UpdateOnDutyPresent(bool isPresent, Guid onDutyId);
    }
}
