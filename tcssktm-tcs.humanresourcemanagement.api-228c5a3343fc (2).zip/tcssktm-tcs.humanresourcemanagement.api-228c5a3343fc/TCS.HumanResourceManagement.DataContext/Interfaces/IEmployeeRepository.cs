﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.DataContext.Interfaces
{
    public interface IEmployeeRepository
    {
        Task<string> CreateNewEmployeeCode();

        Task<bool> IsExist(string employeeCode);

        Task<bool> IsExist(Guid employeeId);

        Task<bool> IsExisitPersonalEmail(string emailAccount);

        Task<bool> IsExisitOfficialEmail(string emailAccount);

        Task<bool> IsPANNumberExisit(string panNumber);

        Task<bool> IsAadharExisit(string aadharNumber);

        Task<bool> IsMobileNumberExisit(string mobileNumber);


        Task CreateNewEmployee(Employee incomingEmployeeInformations);

        Task CreateNewEmployeeDetails(EmployeeDetails incomingEmployeeDetails);

        Task InserEmployeeBankAccount(EmployeeBankAccounts incomingEmployeeBankAccount);

        Task<Employee> GetEmployee(Guid employeeId);

        Task<Employee> GetEmployee(string employeeCode);

        Task<List<Employee>> GetAllEmployees();

        Task<ReportingManger> ReportingMangerByEmployee(Guid employeeId);

        Task<EmployeeDetails> GetLast(Guid employeeId);

        Task<bool> IsUserAsReportingManager(Guid employeeId);

        Task<ViewEmployeeAddress> GetEmployeeAddreeses(Guid employeeId);

        Task<List<EmployeeExperiences>> GetEmployeeExperience(Guid employeeId);

        Task<ViewEmployeeSalaryDetails> GetEmployeeSalaryDetails(Guid employeeId);

        Task<bool> IsAssignedReportingManagerToEmployee(Guid employeeId);

        Task AssignReportingManagerToEmployee(Guid employeeId, Guid reportingManagerId, Guid userId);

        Task<List<Employee>> GetEmployeeByBranch(Guid locationId);

        Task<List<Employee>> GetEmployees();
    }
}
