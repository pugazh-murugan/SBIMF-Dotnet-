﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataModel.Model.Departments;

namespace TCS.HumanResourceManagement.DataContext.Interfaces
{
    public interface IDepartmentRepository
    {
        Task<bool> IsExist(string departmentCode);

        Task<bool> IsExist(Guid departmentId);

        Task<bool> IsNameExist(string departmentName);

        Task CreateNewDepartment(Department department);

        Task<pagenationResponse> GetAll(pagenationResquest resquest);
    }
}
