﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataModel.Model.Employees;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;

namespace TCS.HumanResourceManagement.DataContext.Interfaces
{
    public interface IJobsRepository
    {
        Task<bool> IsExisitPersonalEmail(string emailAccount);

        Task<bool> IsPANNumberExisit(string panNumber);

        Task<bool> IsAadharExisit(string aadharNumber);

        Task<bool> IsMobileNumberExisit(string mobileNumber);


        Task CreateNewCandidate(Candidates candidate);


        Task<List<Candidates>> GetCandidates(DateTime? interviewDate, Guid? location, int? applicationNumber);

        Task<List<ViewSearchCandidates>> SearchCandidates(string searchText);

        Task<Candidates> CandidateByApplicationNumber(int applicationNuber);

        Task<Employee> OnRollCandidate(Guid candidateId, Guid userId);
    }
}
