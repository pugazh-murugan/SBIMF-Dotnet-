﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.DataContext.Interfaces
{
    public interface ILeaveRepository
    {
        Task<bool> IsExist(Guid leaveTypeId);

        Task ApplyLeave(EmployeeLeaves employeeLeave);

        Task<bool> IsLeaveBalanceAvailable(Guid leaveTypeId, Guid employeeId);

        Task<bool> IsEmployeeLeaveIdExist(Guid employeeLeaveId);

        Task ApproveOrRejectLeave(Guid employeeLeaveId, Guid approver, bool isApprove, string remarks);

        Task<List<ViewEmployeeLeaves>> ViewEmployeeLeaves(Guid employeeId);

        Task<List<LeaveTypes>> GetAllLeaveTypes();

        Task InitLeaves(Guid employeeId, Guid userId, int casualLeave);

        Task<List<ViewAppliedLeaves>> ViewAppliedLeaves(Guid? employeeId, DateTime? fromDate, DateTime? todate, Guid? approverId, bool? isApproved);

        Task<bool> IsAlreadyAppliedLeaveByDate(DateTime fromDate, DateTime toDate, Guid employeeId);
    }
}
