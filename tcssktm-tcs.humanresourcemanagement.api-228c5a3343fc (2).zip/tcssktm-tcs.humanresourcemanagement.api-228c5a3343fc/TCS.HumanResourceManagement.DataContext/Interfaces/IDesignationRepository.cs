﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataModel.Model.Designations;

namespace TCS.HumanResourceManagement.DataContext.Interfaces
{
    public interface IDesignationRepository
    {
        Task<bool> IsExist(string designationCode);

        Task<bool> IsExist(Guid designationId);

        Task<bool> IsNameExist(string designationName);

        Task CreateNewDesignation(Designation designation);

        Task<List<Designation>> GetAll();

        Task<Designation> GetDesignationById(Guid id);
    }
}
