﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataModel.Model.Payroll;

namespace TCS.HumanResourceManagement.DataContext.Interfaces
{
    public interface IPayrollRepository
    {
        Task<List<PayrollProcessingViewModel>> PayrollProcess();
    }
}
