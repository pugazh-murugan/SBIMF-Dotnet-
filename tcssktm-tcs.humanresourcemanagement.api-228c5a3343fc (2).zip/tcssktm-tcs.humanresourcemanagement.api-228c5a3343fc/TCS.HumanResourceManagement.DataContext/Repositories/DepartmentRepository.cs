﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataContext.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Departments;

namespace TCS.HumanResourceManagement.DataContext.Repositories
{
    public class DepartmentRepository : RepositoryBase, IDepartmentRepository
    {
        public DepartmentRepository(IDbTransaction transaction) : base(transaction)
        {

        }

        public async Task<bool> IsExist(string departmentCode)
        {
            string query = $"SELECT COUNT(1) FROM Departments WHERE Code='{departmentCode}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsExist(Guid departmentId)
        {
            string query = $"SELECT COUNT(1) FROM Departments WHERE Id='{departmentId}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsNameExist(string departmentName)
        {
            string query = $"SELECT COUNT(1) FROM Departments WHERE Description='{departmentName}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task CreateNewDepartment(Department department)
        {
            string query = $"INSERT INTO Departments(Id,Code,Description,Status,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@Code,@Description,@Status,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.ExecuteAsync(query, new
            {
                Id = department.Id,
                Code = department.Code,
                Description = department.Description,
                Status = department.Status,
                CreatedBy = department.CreatedBy,
                Created = department.Created,
                LastUpdatedBy = department.LastUpdatedBy,
                LastUpdated = department.LastUpdated
            }, transaction: Transaction);
        }

        public async Task<pagenationResponse> GetAll(pagenationResquest resquest)
        {
            string query = $"SELECT * FROM Department";
            var result = await Connection.QueryAsync<Departments>(query, transaction: Transaction);
            var data = this.GetPagenation(result.AsList(), resquest);
            return data;
        }
        public pagenationResponse GetPagenation(List<Departments> response, pagenationResquest command)
        {
            //List<pagenationResponse> data = new List<pagenationResponse>();
            var CurrentPage = command.PageNumber;
            var TotalNoofRecords = response.Count();
            var PageSize = command.PageSize;
            var TotalPages = (int)Math.Ceiling(TotalNoofRecords / (double)PageSize);
            var Results = response.Skip((command.PageNumber - 1) * (command.PageSize))
                .Take(command.PageSize).ToList();
            var Iteams1 = (List<Departments>)(Results.ToList());
        var pagenation = new pagenationResponse(CurrentPage, TotalNoofRecords, PageSize, TotalPages
                , Iteams1);
           // data.Add(pagenation);
            return pagenation;
        }
       
    }
}
