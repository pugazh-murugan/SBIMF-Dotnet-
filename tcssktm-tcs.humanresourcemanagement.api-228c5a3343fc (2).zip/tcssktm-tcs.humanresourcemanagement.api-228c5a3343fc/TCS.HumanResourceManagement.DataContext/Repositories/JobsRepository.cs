﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using TCS.HumanResourceManagement.DataContext.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Jobs;
using Dapper;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataModel.Model.Employees;
using System.Linq;

namespace TCS.HumanResourceManagement.DataContext.Repositories
{
    public class JobsRepository : RepositoryBase, IJobsRepository
    {
        private IEmployeeRepository employeeRepository;

        public JobsRepository(IDbTransaction transaction, IEmployeeRepository employeeRepository) : base(transaction)
        {
            this.employeeRepository = employeeRepository;
        }

        public async Task<bool> IsExisitPersonalEmail(string emailAccount)
        {
            string query = $"SELECT COUNT(1) FROM Candidates WHERE Email='{emailAccount}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsPANNumberExisit(string panNumber)
        {
            string query = $"SELECT COUNT(1) FROM Candidates WHERE PANNumber='{panNumber}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsAadharExisit(string aadharNumber)
        {
            string query = $"SELECT COUNT(1) FROM Candidates WHERE AadharNumber='{aadharNumber}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsMobileNumberExisit(string mobileNumber)
        {
            string query = $"SELECT COUNT(1) FROM Candidates WHERE MobileNumber='{mobileNumber}' OR AlternateNumber='{mobileNumber}' OR EmergencyContactNo='{mobileNumber}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task CreateNewCandidate(Candidates candidate)
        {
            string query = $"INSERT INTO Candidates" +
                $"(Id,Location,Avatar,ApplicationId,FirstName,LastName,DateOfBirthInCertificate,DateOfBirthOriginal,Age,Gender,Email,MobileNumber,AlternateNumber,EmergencyContactNo," +
                $"PANNumber,AadharNumber,BloodGroup,TotalYearOfExperience,CurrentSalary,ExpectedSalary,IsHostelRequired,InterviewDate,DateOfJoin,WeddingDay,Comments,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@Location,@Avatar,@ApplicationId,@FirstName,@LastName,@DateOfBirthInCertificate,@DateOfBirthOriginal,@Age,@Gender,@Email,@MobileNumber,@AlternateNumber,@EmergencyContactNo," +
                $"@PANNumber,@AadharNumber,@BloodGroup,@TotalYearOfExperience,@CurrentSalary,@ExpectedSalary,@IsHostelRequired,@InterviewDate,@DateOfJoin,@WeddingDay,@Comments,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.ExecuteAsync(query, new
            {
                Id = candidate.Id,
                Location = candidate.Location,
                Avatar = candidate.Avatar,
                ApplicationId = candidate.ApplicationId,
                FirstName = candidate.FirstName,
                LastName = candidate.LastName,
                DateOfBirthInCertificate = candidate.DateOfBirthInCertificate,
                DateOfBirthOriginal = candidate.DateOfBirthOriginal,
                Age = candidate.Age,
                Gender = candidate.Gender,
                Email = candidate.Email,
                MobileNumber = candidate.MobileNumber,
                AlternateNumber = candidate.AlternateNumber,
                EmergencyContactNo = candidate.EmergencyContactNo,
                PANNumber = candidate.PANNumber,
                AadharNumber = candidate.AadharNumber,
                BloodGroup = candidate.BloodGroup,
                TotalYearOfExperience = candidate.TotalYearOfExperience,
                CurrentSalary = candidate.CurrentSalary,
                ExpectedSalary = candidate.ExpectedSalary,
                IsHostelRequired = candidate.IsHostelRequired,
                InterviewDate = candidate.InterviewDate,
                DateOfJoin = candidate.DateOfJoin,
                WeddingDay = candidate.WeddingDay,
                Comments = candidate.Comments,
                CreatedBy = candidate.CreatedBy,
                Created = candidate.Created,
                LastUpdatedBy = candidate.LastUpdatedBy,
                LastUpdated = candidate.LastUpdated
            }, transaction: Transaction);

            if (candidate.EmployeeAddresses != null)
            {
                await CandidateAddress(candidate.EmployeeAddresses);
            }

            if (candidate.EmployeeQualifications != null)
            {
                await CandidateQualification(candidate.EmployeeQualifications);
            }

            if (candidate.EmployeeExperiences.Any())
            {
                await CandidateExperience(candidate.EmployeeExperiences);
            }

            if(candidate.DependentDetails.Any())
            {
                await CandidateFamily(candidate.DependentDetails);
            }
        }

        public async Task CandidateAddress(EmployeeAddresses candidateAddresses)
        {
            string query = $"INSERT INTO CandidateAddresses" +
                $"(Id,EmployeeId,ResidenceAddressLine1,ResidenceAddressLine2,ResidenceCity,ResidenceState,ResidenceCountry,ResidencePostalCode,ResidenceAddressType," +
                $"PermanentAddressLine1,PermanentAddressLine2,PermanentCity,PermanentState,PermanentCountry,PermanentPostalCode,PermanentAddressType," +
                $"CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@ResidenceAddressLine1,@ResidenceAddressLine2,@ResidenceCity,@ResidenceState,@ResidenceCountry,@ResidencePostalCode,@ResidenceAddressType," +
                $"@PermanentAddressLine1,@PermanentAddressLine2,@PermanentCity,@PermanentState,@PermanentCountry,@PermanentPostalCode,@PermanentAddressType," +
                $"@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.ExecuteAsync(query, new
            {
                Id = candidateAddresses.Id,
                EmployeeId = candidateAddresses.EmployeeId,
                ResidenceAddressLine1 = candidateAddresses.ResidenceAddress.AddressLine1,
                ResidenceAddressLine2 = candidateAddresses.ResidenceAddress.AddressLine2,
                ResidenceCity = candidateAddresses.ResidenceAddress.City,
                ResidenceState = candidateAddresses.ResidenceAddress.State,
                ResidenceCountry = candidateAddresses.ResidenceAddress.Country,
                ResidencePostalCode = candidateAddresses.ResidenceAddress.PostalCode,
                ResidenceAddressType = candidateAddresses.ResidenceAddress.AddressType,
                PermanentAddressLine1 = candidateAddresses.PermanentAddress.AddressLine1,
                PermanentAddressLine2 = candidateAddresses.PermanentAddress.AddressLine1,
                PermanentCity = candidateAddresses.PermanentAddress.AddressLine1,
                PermanentState = candidateAddresses.PermanentAddress.AddressLine1,
                PermanentCountry = candidateAddresses.PermanentAddress.AddressLine1,
                PermanentPostalCode = candidateAddresses.PermanentAddress.AddressLine1,
                PermanentAddressType = candidateAddresses.PermanentAddress.AddressType,
                CreatedBy = candidateAddresses.CreatedBy,
                Created = candidateAddresses.Created,
                LastUpdatedBy = candidateAddresses.LastUpdatedBy,
                LastUpdated = candidateAddresses.LastUpdated
            }, transaction: Transaction);
        }

        public async Task CandidateQualification(EmployeeQualifications employeeQualifications)
        {
            string query = $"INSERT INTO CandidateQualifications" +
                $"(Id,EmployeeId,Qualification,University,Institution,YearOfPassedOut,Percentage,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@Qualification,@University,@Institution,@YearOfPassedOut,@Percentage,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.ExecuteAsync(query, new
            {
                Id = employeeQualifications.Id,
                EmployeeId = employeeQualifications.EmployeeId,
                Qualification = employeeQualifications.Qualification,
                University = employeeQualifications.University,
                Institution = employeeQualifications.Institution,
                YearOfPassedOut = employeeQualifications.YearOfPassedOut,
                Percentage = employeeQualifications.Percentage,
                CreatedBy = employeeQualifications.CreatedBy,
                Created = employeeQualifications.Created,
                LastUpdatedBy = employeeQualifications.LastUpdatedBy,
                LastUpdated = employeeQualifications.LastUpdated

            }, transaction: Transaction);
        }

        public async Task CandidateExperience(List<EmployeeExperiences> employeeExperiences)
        {
            string query = $"INSERT INTO CandidateExperiences" +
                $"(Id,EmployeeId,[From],[To],CompanyName,Designation,ReasonForLeaving,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@From,@To,@CompanyName,@Designation,@ReasonForLeaving,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            foreach(var item in employeeExperiences)
            {
                await Connection.ExecuteAsync(query, new
                {
                    Id=item.Id,
                    EmployeeId = item.EmployeeId,
                    From = item.From,
                    To = item.To,
                    CompanyName = item.CompanyName,
                    Designation = item.Designation,
                    ReasonForLeaving = item.ReasonForLeaving,
                    CreatedBy = item.CreatedBy,
                    Created = item.Created,
                    LastUpdatedBy = item.LastUpdatedBy,
                    LastUpdated = item.LastUpdated

                }, transaction: Transaction);
            }
        }

        public async Task CandidateFamily(List<DependentDetails> dependentDetails)
        {
            string query = $"INSERT INTO CandidateFamilyDetails" +
                $"(Id,EmployeeId,Name,Gender,DateOfBirth,Occupation,Relationship,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@Name,@Gender,@DateOfBirth,@Occupation,@Relationship,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            foreach(var item in dependentDetails)
            {
                await Connection.ExecuteAsync(query, new
                {
                    Id=item.Id,
                    EmployeeId = item.EmployeeId,
                    Name = item.Name,
                    Gender = item.Gender,
                    DateOfBirth = item.DateOfBirth,
                    Occupation = item.Occupation,
                    Relationship = item.Relationship,
                    CreatedBy = item.CreatedBy,
                    Created = item.Created,
                    LastUpdatedBy = item.LastUpdatedBy,
                    LastUpdated = item.LastUpdated

                }, transaction: Transaction);
            }
        }

        public async Task<List<Candidates>> GetCandidates(DateTime? interviewDate, Guid? location, int? applicationNumber)
        {
            var queryBuilder = new SqlBuilder();
            string query = $"SELECT * FROM Candidates";
            var sql = queryBuilder.AddTemplate($"{query} /**where**/ ");

            if (interviewDate.HasValue)
                queryBuilder.OrWhere("InterviewDate >= @fromDate AND InterviewDate.InTime <= @todate", new { fromDate = interviewDate.Value, todate = interviewDate.Value });

            if (location.HasValue)
                queryBuilder.OrWhere("Location = @location", new { location = location.Value });

            if (applicationNumber.HasValue)
                queryBuilder.OrWhere("ApplicationId = @applicationNumber", new { applicationNumber = applicationNumber.Value });

            queryBuilder.Where("IsOnRoll = @isOnRoll", new { isOnRoll = false });

            var result = await Connection.QueryAsync<Candidates>(sql.RawSql, sql.Parameters, transaction: Transaction);
            return result.AsList();
        }

        public async Task<List<ViewSearchCandidates>> SearchCandidates(string searchText)
        {
            var queryBuilder = new SqlBuilder();
            string query = $"SELECT ApplicationId,CONCAT(FirstName,' ',LastName) AS Name,FirstName,LastName,DateOfJoin,InterviewDate,MobileNumber FROM Candidates";
            var sql = queryBuilder.AddTemplate($"{query} /**where**/ ");

            if(!string.IsNullOrEmpty(searchText))
            {
                queryBuilder.OrWhere("MobileNumber LIKE @mobileNumner", new { mobileNumner = string.Format("%{0}%", searchText) });
                queryBuilder.OrWhere("FirstName LIKE @firtName", new { firtName = string.Format("%{0}%", searchText) });
                queryBuilder.OrWhere("LastName LIKE @lastName", new { lastName = string.Format("%{0}%", searchText) });
            }

            var result = await Connection.QueryAsync<ViewSearchCandidates>(sql.RawSql, sql.Parameters, transaction: Transaction);
            return result.AsList();
        }

        public async Task<Candidates> CandidateByApplicationNumber(int applicationNuber)
        {
            string query = $"SELECT * FROM Candidates where ApplicationId = @applicationNuber";

            var candidate = await Connection.QueryFirstAsync<Candidates>(query, new { applicationNuber = applicationNuber }, transaction: Transaction);
            candidate.EmployeeQualifications = await CandidateQualificationById(candidate.Id);
            candidate.EmployeeExperiences = await CandidateExperienceByemployeeId(candidate.Id);
            candidate.DependentDetails = await CandidateFamilyDetailsByemployeeId(candidate.Id);
            candidate.EmployeeAddresses=await CandidateAddressDetailsById(candidate.Id);

            return candidate;
        }

        public async Task<EmployeeQualifications> CandidateQualificationById(Guid candidateId)
        {
            string query = $"SELECT * FROM CandidateQualifications where EmployeeId = @candidateId";
            var candidateQualification = await Connection.QueryFirstAsync<EmployeeQualifications>(query, new { candidateId = candidateId }, transaction: Transaction);
            return candidateQualification;
        }

        public async Task<List<EmployeeExperiences>> CandidateExperienceByemployeeId(Guid candidateId)
        {
            string query = $"SELECT * FROM CandidateExperiences where EmployeeId = @candidateId";
            var candidateExperience = await Connection.QueryAsync<EmployeeExperiences>(query, new { candidateId = candidateId }, transaction: Transaction);
            return candidateExperience.AsList();
        }

        public async Task<List<DependentDetails>> CandidateFamilyDetailsByemployeeId(Guid candidateId)
        {
            string query = $"SELECT * FROM CandidateFamilyDetails where EmployeeId = @candidateId";
            var candidateFamilyDetails = await Connection.QueryAsync<DependentDetails>(query, new { candidateId = candidateId }, transaction: Transaction);
            return candidateFamilyDetails.AsList();
        }

        public async Task<EmployeeAddresses> CandidateAddressDetailsById(Guid candidateId)
        {

            var permanentAddressQuery = $"SELECT Id,EmployeeId, PermanentAddressLine1 AS AddressLine1, PermanentAddressLine2 AS AddressLine2,PermanentCity AS City,PermanentState As State" +
                $",PermanentCountry AS Country,PermanentPostalCode AS PostalCode,PermanentAddressType AS AddressType FROM CandidateAddresses WHERE EmployeeId = @candidateId";

            var residenceAddressQuery = $"SELECT ResidenceAddressLine1 AS AddressLine1, ResidenceAddressLine2 AS AddressLine2,ResidenceCity AS City,ResidenceState As State" +
                $",ResidenceCountry AS Country,ResidencePostalCode AS PostalCode,ResidenceAddressType AS AddressType FROM CandidateAddresses WHERE EmployeeId = @candidateId";

            var permanentAddress = await Connection.QueryFirstAsync<Addresses>(permanentAddressQuery, new { candidateId = candidateId }, transaction: Transaction);
            var residenceAddress = await Connection.QueryFirstAsync<Addresses>(residenceAddressQuery, new { candidateId = candidateId }, transaction: Transaction);

            var employeeAddress = new EmployeeAddresses()
            {
                EmployeeId = candidateId,
                PermanentAddress = permanentAddress,
                ResidenceAddress = residenceAddress
            };

            return employeeAddress;
        }


        public async Task<Employee> OnRollCandidate(Guid candidateId, Guid userId)
        {
            var employeeId = Guid.NewGuid();
            var employeeCode = await employeeRepository.CreateNewEmployeeCode();

            string query = $"SELECT * FROM Candidates where Id = @id";

            var candidate = await Connection.QueryFirstAsync<Candidates>(query, new { id = candidateId }, transaction: Transaction);

            List<EmployeeQualifications> employeeQualifications = new List<EmployeeQualifications>();

            var employeeQualification = await CandidateQualificationById(candidate.Id);
            employeeQualification.EmployeeId = employeeId;
            employeeQualification.Created = DateTime.Now;
            employeeQualification.CreatedBy = userId;
            employeeQualification.LastUpdated = DateTime.Now;
            employeeQualification.LastUpdatedBy = userId;
            employeeQualifications.Add(employeeQualification);

            var employeeExperiences = await CandidateExperienceByemployeeId(candidate.Id);
            employeeExperiences.ForEach(c =>
            {
                c.EmployeeId = employeeId;
                c.Created = DateTime.Now;
                c.CreatedBy = userId;
                c.LastUpdated = DateTime.Now;
                c.LastUpdatedBy = userId;
            });

            var dependentDetails = await CandidateFamilyDetailsByemployeeId(candidate.Id);
            dependentDetails.ForEach(c =>
            {
                c.EmployeeId = employeeId;
                c.Created = DateTime.Now;
                c.CreatedBy = userId;
                c.LastUpdated = DateTime.Now;
                c.LastUpdatedBy = userId;
            });

            var employeeAddresses = await CandidateAddressDetailsById(candidate.Id);
            employeeAddresses.Id = Guid.NewGuid();
            employeeAddresses.EmployeeId = employeeId;
            employeeAddresses.LastUpdated = DateTime.Now;
            employeeAddresses.LastUpdatedBy = userId;
            employeeAddresses.Created = DateTime.Now;
            employeeAddresses.CreatedBy = userId;

            var employee = new Employee()
            {
                Id = employeeId,
                EmployeeCode = employeeCode,
                FirstName = candidate.FirstName,
                LastName = candidate.LastName,
                Gender = candidate.Gender,
                PANNumber = candidate.PANNumber,
                AadharNumber = candidate.AadharNumber,
                PersonalEmail = candidate.Email,
                MobileNumber = candidate.MobileNumber,
                AlternateNumber = candidate.AlternateNumber,
                Avatar = candidate.Avatar,
                DateOfBirth = candidate.DateOfBirthOriginal,
                DateOfJoin = candidate.DateOfJoin,
                EmployeeAddresses = employeeAddresses,
                EmployeeQualifications = employeeQualifications,
                EmployeeExperiences = employeeExperiences,
                DependentDetails = dependentDetails,
                EmployeeDetails = null,
                EmployeeBankAccount = null,
                Created = DateTime.Now,
                CreatedBy = userId,
                LastUpdated = DateTime.Now,
                LastUpdatedBy = userId
            };
            await employeeRepository.CreateNewEmployee(employee);
            await UpdateCandiateAsEmployee(candidateId);
            return employee;
        }

        private async Task UpdateCandiateAsEmployee(Guid id)
        {
            string query = $"UPDATE Candidates SET IsOnRoll=@isOnRoll WHERE Id=@id";
            await Connection.ExecuteAsync(query, new { isOnRoll = true, id = id }, transaction: Transaction);
        }
    }
}
