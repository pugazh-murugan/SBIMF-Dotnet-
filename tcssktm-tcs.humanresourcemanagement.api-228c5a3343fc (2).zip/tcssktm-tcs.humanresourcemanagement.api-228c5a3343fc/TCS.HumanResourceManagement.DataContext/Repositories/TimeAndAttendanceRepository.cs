﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataContext.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;

namespace TCS.HumanResourceManagement.DataContext.Repositories
{
    public class TimeAndAttendanceRepository : RepositoryBase, ITimeAndAttendanceRepository
    {
        private readonly IEmployeeRepository employeeRepository;

        public TimeAndAttendanceRepository(IDbTransaction transaction, IEmployeeRepository employeeRepository) : base(transaction)
        {
            this.employeeRepository = employeeRepository;
        }


        public async Task InsertOrUpdateTimeAndAttendance(EmployeeAttendance employeeAttendance)
        {
            if (employeeAttendance.PunchType.Equals("IN", StringComparison.OrdinalIgnoreCase))
            {
                await InsertTimeAndAttendance(employeeAttendance);
            }
            else if (employeeAttendance.PunchType.Equals("OUT", StringComparison.OrdinalIgnoreCase))
            {
                await UpdateTimeAndAttendance(employeeAttendance);
            }
        }

        public async Task<bool> IsEmployeeOnPresent(Guid employeeId)
        {
            string query = $"SELECT COUNT(1) FROM TimeAndAttendance WHERE EmployeeId='{employeeId}' AND InTime >= '{DateTime.Now.Date}' ";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }


        private async Task InsertTimeAndAttendance(EmployeeAttendance employeeAttendance)
        {
            string query = $"INSERT INTO TimeAndAttendance" +
                $"(Id,EmployeeId,InTime,OutTime,BioMetricIP,DeviceSerialNumber,PunchType,IsManual,LocationId,Remarks,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@InTime,@OutTime,@BioMetricIP,@DeviceSerialNumber,@PunchType,@IsManual,@LocationId,@Remarks,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.ExecuteAsync(query, new
            {
                Id = employeeAttendance.Id,
                EmployeeId = employeeAttendance.EmployeeId,
                InTime = employeeAttendance.InTime,
                OutTime = employeeAttendance.OutTime,
                BioMetricIP = employeeAttendance.BioMetricIP,
                DeviceSerialNumber = employeeAttendance.DeviceSerialNumber,
                PunchType = employeeAttendance.PunchType,
                IsManual = employeeAttendance.IsManual,
                LocationId = employeeAttendance.LocationId,
                Remarks = employeeAttendance.Remarks,
                CreatedBy = employeeAttendance.CreatedBy,
                Created = employeeAttendance.Created,
                LastUpdated = employeeAttendance.LastUpdated,
                LastUpdatedBy = employeeAttendance.LastUpdatedBy
            }, transaction: Transaction);
        }

        private async Task UpdateTimeAndAttendance(EmployeeAttendance employeeAttendance)
        {
            var employeeLastInTime = await FetchLastInTimeByEmployeeId(employeeAttendance.EmployeeId);

            if (employeeAttendance != null)
            {
                string query = $"UPDATE TimeAndAttendance SET OutTime=@OutTime,PunchType=@PunchType,IsManual=@IsManual,Remarks=@Remarks,LastUpdated=@LastUpdated,LastUpdatedBy=@LastUpdatedBy WHERE Id=@Id";

                await Connection.ExecuteAsync(query, new
                {
                    Id = employeeLastInTime.Id,
                    OutTime = employeeAttendance.OutTime,
                    PunchType = employeeAttendance.PunchType,
                    IsManual = employeeAttendance.IsManual,
                    Remarks = employeeAttendance.Remarks,
                    LastUpdated = employeeAttendance.LastUpdated,
                    LastUpdatedBy = employeeAttendance.LastUpdatedBy
                }, transaction: Transaction);
            }
        }

        public async Task<List<ViewTimeAndAttendance>> ViewTimeAndAttendance(Guid? employeeId, DateTime? fromDate, DateTime? toDate, Guid? location)
        {
            var queryBuilder = new SqlBuilder();
            string query = $"SELECT employee.Id AS EmployeeId,employee.EmployeeCode,employee.FirstName,employee.LastName,timeAndAttendance.InTime," +
                $"timeAndAttendance.OutTime,timeAndAttendance.PunchType,timeAndAttendance.BioMetricIP,timeAndAttendance.DeviceSerialNumber," +
                $"timeAndAttendance.IsManual,timeAndAttendance.LocationId,timeAndAttendance.Created FROM Employees employee " +
                $"LEFT JOIN TimeAndAttendance timeAndAttendance ON employee.Id = timeAndAttendance.EmployeeId";

            var sql = queryBuilder.AddTemplate($"{query} /**where**/ ");

            if (employeeId.HasValue)
                queryBuilder.Where("employee.Id = @employeeId", new { employeeId = employeeId.Value });

            if (fromDate.HasValue)
                queryBuilder.Where("timeAndAttendance.InTime >= @fromDate AND timeAndAttendance.InTime <= @todate", new { fromDate = fromDate.Value, todate = toDate.Value });

            if (location.HasValue)
                queryBuilder.Where("timeAndAttendance.LocationId = @location", new { location = location.Value });


            var result = await Connection.QueryAsync<ViewTimeAndAttendance>(sql.RawSql, sql.Parameters, transaction: Transaction);
            return result.AsList();
        }

        public async Task<bool> IsEmployeeAlreadyInOrOutByDate(string employeeCode, string punchType, DateTime startDate, DateTime endDate)
        {
            var employee = await employeeRepository.GetEmployee(employeeCode);

            string query = $"SELECT COUNT(1) FROM TimeAndAttendance WHERE EmployeeId=@employeeId AND PunchType=@punchType AND InTime BETWEEN @startDate AND @endDate";
            var result = await Connection.ExecuteScalarAsync<bool>(query,
                new
                {
                    employeeId= employee.Id,
                    punchType= punchType,
                    startDate= startDate,
                    endDate= endDate
                },transaction: Transaction);
            return result;
        }

        public async Task InsertOndutyEntry(OnDuties onDuties)
        {
            string query = $"INSERT INTO OnDuties" +
                $"(Id,EmployeeId,Branch,FromDate,ToDate,Reason,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@Branch,@FromDate,@ToDate,@Reason,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            var totalDays = (onDuties.ToDate - onDuties.FromDate).TotalDays;
            for (int i = 0; i < totalDays; i++)
            {
                await Connection.ExecuteAsync(query, new
                {
                    Id = Guid.NewGuid(),
                    EmployeeId = onDuties.EmployeeId,
                    Branch = onDuties.Branch,
                    FromDate = onDuties.FromDate,
                    ToDate = onDuties.ToDate.AddDays(i),
                    Reason = onDuties.Reason,
                    CreatedBy = onDuties.CreatedBy,
                    Created = onDuties.Created,
                    LastUpdatedBy = onDuties.LastUpdatedBy,
                    LastUpdated = onDuties.LastUpdated

                }, transaction: Transaction);
            }
        }

        public async Task<List<OnDutiesViewModel>> GetOnDuties(Guid? branch,DateTime fromDate,DateTime toDate,Guid? employeeId)
        {
            var queryBuilder = new SqlBuilder();

            string query = $"SELECT onDuty.Id,employee.EmployeeCode,employee.FirstName,employee.LastName,onDuty.Branch," +
                $"onDuty.FromDate,onDuty.ToDate,onDuty.Reason,onDuty.IsPresent,onDuty.Present,onDuty.Created,onDuty.CreatedBy," +
                $"onDuty.LastUpdated,onDuty.LastUpdatedBy FROM Employees employee INNER JOIN OnDuties onDuty ON employee.Id = onDuty.EmployeeId";

           
            var sql = queryBuilder.AddTemplate($"{query} /**where**/ ");
            queryBuilder.Where("onDuty.Created >= @fromDate AND onDuty.Created <= @todate", new { fromDate = fromDate, todate = toDate });

            if (employeeId.HasValue)
                queryBuilder.Where("onDuty.EmployeeId = @employeeId", new { employeeId = employeeId.Value });

            if (branch.HasValue)
                queryBuilder.Where("onDuty.Branch = @branch", new { branch = branch.Value });


            var result = await Connection.QueryAsync<OnDutiesViewModel>(sql.RawSql, sql.Parameters, transaction: Transaction);
            return result.AsList();
        }

        public async Task UpdateOnDutyPresent(bool isPresent, Guid onDutyId)
        {
            string query = "UPDATE OnDuties SET IsPresent=@isPresent,Present=@present WHERE Id=@id";
            await Connection.ExecuteAsync(query, new
            {
                isPresent = isPresent,
                present = DateTime.Now,
                id = onDutyId
            }, transaction: Transaction);
        }

        public async Task<OnDuties> EmployeeOnDuty(Guid employeeId,DateTime fromDate,DateTime toDate)
        {
            string query = $"SELECT * FROM OnDuties WHERE employeeId=@employeeId AND Created >= @fromDate AND Created <= @toDate";
            var result = await Connection.QueryFirstOrDefaultAsync<OnDuties>(query, new
            {
                employeeId = employeeId,
                fromDate = fromDate,
                toDate = toDate
            }, transaction: Transaction);
            return result;
        }
        private async Task<EmployeeAttendance> FetchLastInTimeByEmployeeId(Guid employeeId)
        {
            string query = $"SELECT TOP 1 * FROM TimeAndAttendance WHERE EmployeeId = '{employeeId}' AND PunchType = 'IN' ORDER BY InTime DESC";

            var result = await Connection.QueryFirstOrDefaultAsync<EmployeeAttendance>(query, transaction: Transaction);
            return result;
        }

    }
}
