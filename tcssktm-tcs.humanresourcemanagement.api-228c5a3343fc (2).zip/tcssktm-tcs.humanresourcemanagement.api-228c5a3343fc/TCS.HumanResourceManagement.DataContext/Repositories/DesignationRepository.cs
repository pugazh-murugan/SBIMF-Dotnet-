﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataContext.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Designations;

namespace TCS.HumanResourceManagement.DataContext.Repositories
{
    public class DesignationRepository : RepositoryBase, IDesignationRepository
    {
        public DesignationRepository(IDbTransaction transaction) : base(transaction)
        {

        }

        public async Task<bool> IsExist(string designationCode)
        {
            string query = $"SELECT COUNT(1) FROM Designations WHERE Code='{designationCode}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsExist(Guid designationId)
        {
            string query = $"SELECT COUNT(1) FROM Designations WHERE Id='{designationId}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsNameExist(string designationName)
        {
            string query = $"SELECT COUNT(1) FROM Designations WHERE Description='{designationName}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task CreateNewDesignation(Designation designation)
        {
            string query = $"INSERT INTO Designations(Id,Code,Description,Status,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@Code,@Description,@Status,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.ExecuteAsync(query, new
            {
                Id = designation.Id,
                Code = designation.Code,
                Description = designation.Description,
                Status = designation.Status,
                CreatedBy = designation.CreatedBy,
                Created = designation.Created,
                LastUpdatedBy = designation.LastUpdatedBy,
                LastUpdated = designation.LastUpdated
            }, transaction: Transaction);
        }

        public async Task<List<Designation>> GetAll()
        {
            string query = $"SELECT * FROM Designations";
            var result = await Connection.QueryAsync<Designation>(query, transaction: Transaction);
            return result.AsList();
        }

        public async Task<Designation> GetDesignationById(Guid id)
        {
            string query = $"SELECT * FROM Designations WHERE Id = '{id}'";
            var result = await Connection.QueryFirstOrDefaultAsync<Designation>(query, transaction: Transaction);
            return result;
        }
    }
}
