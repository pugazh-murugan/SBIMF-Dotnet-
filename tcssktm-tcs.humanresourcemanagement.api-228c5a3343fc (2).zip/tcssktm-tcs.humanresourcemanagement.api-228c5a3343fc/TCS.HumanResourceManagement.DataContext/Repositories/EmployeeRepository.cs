﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataContext.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.DataContext.Repositories
{
    public class EmployeeRepository : RepositoryBase, IEmployeeRepository
    {
        private readonly IDesignationRepository designationRepository;

        public EmployeeRepository(
            IDbTransaction transaction,
            IDesignationRepository designationRepository) : base(transaction)
        {
            this.designationRepository = designationRepository;
        }

        public async Task<bool> IsExist(string employeeCode)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE EmployeeCode='{employeeCode}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsExist(Guid employeeId)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE Id='{employeeId}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsExisitPersonalEmail(string emailAccount)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE PersonalEmail='{emailAccount}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsExisitOfficialEmail(string emailAccount)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE OfficialEmail='{emailAccount}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsPANNumberExisit(string panNumber)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE PANNumber='{panNumber}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsAadharExisit(string aadharNumber)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE AadharNumber='{aadharNumber}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsMobileNumberExisit(string mobileNumber)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE MobileNumber='{mobileNumber}' OR AlternateNumber='{mobileNumber}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<string> CreateNewEmployeeCode()
        {
            Random generator = new Random();
            string employeeCode = generator.Next(0, 999999).ToString("D6");

            var isAlreadyExisit = await IsExist(employeeCode);
            if (isAlreadyExisit)
            {
                await CreateNewEmployeeCode();
            }
            return employeeCode;
        }


        public async Task CreateNewEmployee(Employee incomingEmployeeInformations)
        {
            string query = $"INSERT INTO Employees" +
                $"(Id,Branch,EmployeeCode,FirstName,LastName,Gender,PANNumber,AadharNumber,PersonalEmail,OfficialEmail,MobileNumber,IsMobileNumberVerified,AlternateNumber,Avatar,DateOfBirth,DateOfJoin,ReportingManageId,IsMarried,SpouseName,HaveChild,NumberOfChild,IsActive,IsExitInitiated,CreatedBy,Created,LastUpdated,LastUpdatedBy)" +
                $"values(@Id,@Branch,@EmployeeCode,@FirstName,@LastName,@Gender,@PANNumber,@AadharNumber,@PersonalEmail,@OfficialEmail,@MobileNumber,@IsMobileNumberVerified,@AlternateNumber,@Avatar,@DateOfBirth,@DateOfJoin,@ReportingManageId,@IsMarried,@SpouseName,@HaveChild,@NumberOfChild,@IsActive,@IsExitInitiated,@CreatedBy,@Created,@LastUpdated,@LastUpdatedBy)";

            await Connection.ExecuteAsync(query, new
            {
                Id = incomingEmployeeInformations.Id,
                Branch = incomingEmployeeInformations.Branch,
                EmployeeCode = incomingEmployeeInformations.EmployeeCode,
                FirstName = incomingEmployeeInformations.FirstName,
                LastName = incomingEmployeeInformations.LastName,
                Gender = incomingEmployeeInformations.Gender,
                PANNumber = incomingEmployeeInformations.PANNumber,
                AadharNumber = incomingEmployeeInformations.AadharNumber,
                PersonalEmail = incomingEmployeeInformations.PersonalEmail,
                OfficialEmail = incomingEmployeeInformations.OfficialEmail,
                MobileNumber = incomingEmployeeInformations.MobileNumber,
                IsMobileNumberVerified = incomingEmployeeInformations.IsMobileNumberVerified,
                AlternateNumber = incomingEmployeeInformations.AlternateNumber,
                Avatar = incomingEmployeeInformations.Avatar,
                DateOfBirth = incomingEmployeeInformations.DateOfBirth,
                DateOfJoin = incomingEmployeeInformations.DateOfJoin,
                ReportingManageId = incomingEmployeeInformations.ReportingManageId,
                IsMarried = incomingEmployeeInformations.IsMarried,
                SpouseName = incomingEmployeeInformations.SpouseName,
                HaveChild = incomingEmployeeInformations.HaveChild,
                NumberOfChild = incomingEmployeeInformations.NumberOfChild,
                IsActive = incomingEmployeeInformations.IsActive,
                IsExitInitiated = incomingEmployeeInformations.IsExitInitiated,
                CreatedBy = incomingEmployeeInformations.CreatedBy,
                Created = incomingEmployeeInformations.Created,
                LastUpdated = incomingEmployeeInformations.LastUpdated,
                LastUpdatedBy = incomingEmployeeInformations.LastUpdatedBy
            }, transaction: Transaction);

            if (incomingEmployeeInformations.EmployeeAddresses != null)
            {
                await InsertEmployeeAddress(incomingEmployeeInformations.EmployeeAddresses);
            }
           

            if (incomingEmployeeInformations.EmployeeDetails != null)
            {
                await CreateNewEmployeeDetails(incomingEmployeeInformations.EmployeeDetails);
            }
            if (incomingEmployeeInformations.EmployeeBankAccount != null)
            {
                await InserEmployeeBankAccount(incomingEmployeeInformations.EmployeeBankAccount);
            }

            if (incomingEmployeeInformations.EmployeeQualifications.Any())
            {
                await InsertEmployeeQulification(incomingEmployeeInformations.EmployeeQualifications);
            }

            if (incomingEmployeeInformations.EmployeeExperiences.Any())
            {
                await InsertEmployeeExperience(incomingEmployeeInformations.EmployeeExperiences);
            }

            if (incomingEmployeeInformations.DependentDetails.Any())
            {
                await InsertEmployeeFamilyDetails(incomingEmployeeInformations.DependentDetails);
            }
        }

        public async Task InsertEmployeeAddress(EmployeeAddresses employeeAddresses)
        {
            string query = $"INSERT INTO EmployeeAddresses" +
                $"(Id,EmployeeId,ResidenceAddressLine1,ResidenceAddressLine2,ResidenceCity,ResidenceState,ResidenceCountry,ResidencePostalCode," +
                $"PermanentAddressLine1,PermanentAddressLine2,PermanentCity,PermanentState,PermanentCountry,PermanentPostalCode,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@ResidenceAddressLine1,@ResidenceAddressLine2,@ResidenceCity,@ResidenceState,@ResidenceCountry,@ResidencePostalCode," +
                $"@PermanentAddressLine1,@PermanentAddressLine2,@PermanentCity,@PermanentState,@PermanentCountry,@PermanentPostalCode,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.ExecuteAsync(query,new
            {
                Id= employeeAddresses.Id,
                EmployeeId=employeeAddresses.EmployeeId,
                ResidenceAddressLine1=employeeAddresses.ResidenceAddress.AddressLine1,
                ResidenceAddressLine2 = employeeAddresses.ResidenceAddress.AddressLine2,
                ResidenceCity=employeeAddresses.ResidenceAddress.City,
                ResidenceState=employeeAddresses.ResidenceAddress.State,
                ResidenceCountry=employeeAddresses.ResidenceAddress.Country,
                ResidencePostalCode=employeeAddresses.ResidenceAddress.PostalCode,
                PermanentAddressLine1=employeeAddresses.PermanentAddress.AddressLine1,
                PermanentAddressLine2 = employeeAddresses.PermanentAddress.AddressLine2,
                PermanentCity = employeeAddresses.PermanentAddress.City,
                PermanentState = employeeAddresses.PermanentAddress.State,
                PermanentCountry = employeeAddresses.PermanentAddress.Country,
                PermanentPostalCode = employeeAddresses.PermanentAddress.PostalCode,
                CreatedBy = employeeAddresses.CreatedBy,
                Created = employeeAddresses.Created,
                LastUpdated = employeeAddresses.LastUpdated,
                LastUpdatedBy = employeeAddresses.LastUpdatedBy
            }, transaction: Transaction);

        }

        public async Task CreateNewEmployeeDetails(EmployeeDetails incomingEmployeeDetails)
        {
            string query = $"INSERT INTO EmployeeDetails" +
                $"(Id,EmployeeId,DesignationId,BasicSalary,HRA,PF,DA,SpecialAllowance,FoodAllowance,CarAllowance,MedicalAllowance,MobileAllowance,CreatedBy,Created,LastUpdated,LastUpdatedBy,DepartmentId)" +
                $"values(@Id,@EmployeeId,@DesignationId,@BasicSalary,@HRA,@PF,@DA,@SpecialAllowance,@FoodAllowance,@CarAllowance,@MedicalAllowance,@MobileAllowance,@CreatedBy,@Created,@LastUpdated,@LastUpdatedBy,@DepartmentId)";

            await Connection.ExecuteAsync(query, new
            {
                Id = incomingEmployeeDetails.Id,
                EmployeeId = incomingEmployeeDetails.EmployeeId,
                DesignationId = incomingEmployeeDetails.Designation,
                BasicSalary = incomingEmployeeDetails.BasicSalary,
                HRA = incomingEmployeeDetails.HRA,
                PF = incomingEmployeeDetails.PF,
                DA = incomingEmployeeDetails.DA,
                SpecialAllowance = incomingEmployeeDetails.SpecialAllowance,
                FoodAllowance = incomingEmployeeDetails.FoodAllowance,
                CarAllowance = incomingEmployeeDetails.CarAllowance,
                MedicalAllowance = incomingEmployeeDetails.MedicalAllowance,
                MobileAllowance = incomingEmployeeDetails.MobileAllowance,
                CreatedBy = incomingEmployeeDetails.CreatedBy,
                Created = incomingEmployeeDetails.Created,
                LastUpdated = incomingEmployeeDetails.LastUpdated,
                LastUpdatedBy = incomingEmployeeDetails.LastUpdatedBy,
                DepartmentId = incomingEmployeeDetails.DepartmentId
            }, transaction: Transaction);
        }


        public async Task InserEmployeeBankAccount(EmployeeBankAccounts incomingEmployeeBankAccount)
        {
            string query = $"INSERT INTO EmployeeBankAccounts" +
                $"(Id,EmployeeId,AccountantName,BankName,AccountNumber,IfscCode,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@AccountantName,@BankName,@AccountNumber,@IfscCode,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            var isAlreadyAccount = await Connection.ExecuteScalarAsync<bool>($"SELECT COUNT(1) FROM EmployeeBankAccounts WHERE EmployeeId=@employeeId",
                new { employeeId = incomingEmployeeBankAccount.EmployeeId }, transaction: Transaction);

            if (!isAlreadyAccount)
            {
                await Connection.ExecuteAsync(query, new
                {
                    Id = incomingEmployeeBankAccount.Id,
                    EmployeeId = incomingEmployeeBankAccount.EmployeeId,
                    AccountantName = incomingEmployeeBankAccount.AccountantName,
                    BankName = incomingEmployeeBankAccount.BankName,
                    AccountNumber = incomingEmployeeBankAccount.AccountNumber,
                    IfscCode = incomingEmployeeBankAccount.IfscCode,
                    CreatedBy = incomingEmployeeBankAccount.CreatedBy,
                    Created = incomingEmployeeBankAccount.Created,
                    LastUpdated = incomingEmployeeBankAccount.LastUpdated,
                    LastUpdatedBy = incomingEmployeeBankAccount.LastUpdatedBy,
                }, transaction: Transaction);
            }
        }

        public async Task InsertEmployeeQulification(List<EmployeeQualifications> employeeQualifications)
        {
            string query = $"INSERT INTO EmployeeQualifications" +
                $"(Id,EmployeeId,Qualification,University,YearOfPassedOut,Percentage,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@Qualification,@University,@YearOfPassedOut,@Percentage,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            foreach(var item in employeeQualifications)
            {
                await Connection.ExecuteAsync(query, new
                {
                    Id = item.Id,
                    EmployeeId = item.EmployeeId,
                    Qualification = item.Qualification,
                    University = item.University,
                    YearOfPassedOut = item.YearOfPassedOut,
                    Percentage=item.Percentage,
                    CreatedBy = item.CreatedBy,
                    Created = item.Created,
                    LastUpdated = item.LastUpdated,
                    LastUpdatedBy = item.LastUpdatedBy,
                }, transaction: Transaction);
            }
        }

        public async Task InsertEmployeeExperience(List<EmployeeExperiences> employeeExperiences)
        {
            string query = $"INSERT INTO EmployeeExperiences" +
                $"(Id,EmployeeId,[From],[To],CompanyName,Designation,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@From,@To,@CompanyName,@Designation,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            foreach (var item in employeeExperiences)
            {
                await Connection.ExecuteAsync(query, new
                {
                    Id = item.Id,
                    EmployeeId = item.EmployeeId,
                    From = item.From,
                    To = item.To,
                    CompanyName = item.CompanyName,
                    Designation = item.Designation,
                    CreatedBy = item.CreatedBy,
                    Created = item.Created,
                    LastUpdated = item.LastUpdated,
                    LastUpdatedBy = item.LastUpdatedBy,
                }, transaction: Transaction);
            }
        }

        public async Task InsertEmployeeFamilyDetails(List<DependentDetails> dependentDetails)
        {
            string query = $"INSERT INTO DependentDetails" +
                $"(Id,EmployeeId,Name,Gender,DateOfBirth,Occupation,Relationship,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@Name,@Gender,@DateOfBirth,@Occupation,@Relationship,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            foreach (var item in dependentDetails)
            {
                await Connection.ExecuteAsync(query, new
                {
                    Id = item.Id,
                    EmployeeId = item.EmployeeId,
                    Name = item.Name,
                    Gender = item.Gender,
                    DateOfBirth = item.DateOfBirth,
                    Occupation = item.Occupation,
                    Relationship = item.Relationship,
                    CreatedBy = item.CreatedBy,
                    Created = item.Created,
                    LastUpdatedBy = item.LastUpdatedBy,
                    LastUpdated = item.LastUpdated

                }, transaction: Transaction);
            }
        }

        public async Task<Employee> GetEmployee(Guid employeeId)
        {
            string query = $"SELECT * FROM Employees WHERE Id='{employeeId}'";
            var result = await Connection.QueryFirstOrDefaultAsync<Employee>(query, transaction: Transaction);
            return result;
        }

        public async Task<List<Employee>> GetEmployees()
        {
            string query = $"SELECT * FROM Employees WHERE IsActive=1";
            var result = await Connection.QueryAsync<Employee>(query, transaction: Transaction);
            return result.AsList();
        }

        public async Task<List<Employee>> GetEmployeeByBranch(Guid locationId)
        {
            string query = $"SELECT * FROM Employees WHERE Branch='{locationId}' AND IsActive=1";
            var result = await Connection.QueryAsync<Employee>(query, transaction: Transaction);
            return result.AsList();
        }

        public async Task<Employee> GetEmployee(string employeeCode)
        {
            string query = $"SELECT * FROM Employees WHERE EmployeeCode='{employeeCode}'";
            var result = await Connection.QueryFirstOrDefaultAsync<Employee>(query, transaction: Transaction);
            if (result != null)
            {
                result.ReportingManger = await ReportingMangerByEmployee(result.Id);
                result.EmployeeDetails = await GetLast(result.Id);
            }
            return result;
        }

        public async Task<List<Employee>> GetAllEmployees()
        {
            string query = $"SELECT employee.*,'SPLIT' AS Split,employeeDetails.* FROM Employees employee LEFT JOIN EmployeeDetails employeeDetails ON employee.Id = employeeDetails.EmployeeId;";
            var result = await Connection.QueryAsync<Employee, EmployeeDetails, Employee>(query, MapResults, splitOn: "Split", transaction: Transaction);

            var reportingManger = await GetReportingMangers();
            result.AsList().ForEach(c => c.ReportingManger = reportingManger.FirstOrDefault(x => x.Id == c.ReportingManageId));

            return result.AsList();
        }

        public async Task<ReportingManger> ReportingMangerByEmployee(Guid employeeId)
        {
            string query = $"SELECT * FROM Employees WHERE Id= ( SELECT ReportingManageId FROM Employees WHERE Id='{employeeId}')";
            var result = await Connection.QueryFirstOrDefaultAsync<ReportingManger>(query, transaction: Transaction);
            if (result != null)
            {
                var employeeDetails = await GetLast(result.Id);
                if (employeeDetails != null)
                {
                    var designation = await designationRepository.GetDesignationById(employeeDetails.Designation);
                    result.Designation = designation.Description;
                }
            }
            return result;
        }

        public async Task<bool> IsAssignedReportingManagerToEmployee(Guid employeeId)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE Id= ( SELECT ReportingManageId FROM Employees WHERE Id='{employeeId}')";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<EmployeeDetails> GetLast(Guid employeeId)
        {
            string query = $"SELECT * FROM EmployeeDetails WHERE EmployeeId='{employeeId}' ORDER BY Created DESC";
            var result = await Connection.QueryFirstOrDefaultAsync<EmployeeDetails>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsUserAsReportingManager(Guid employeeId)
        {
            string query = $"SELECT COUNT(1) FROM Employees WHERE ReportingManageId='{employeeId}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        
        public async Task<ViewEmployeeAddress> GetEmployeeAddreeses(Guid employeeId)
        {
            string query = $"SELECT * FROM EmployeeAddresses WHERE EmployeeId='{employeeId}'";
            var result = await Connection.QueryFirstOrDefaultAsync<ViewEmployeeAddress>(query, transaction: Transaction);
            return result;
        }

        public async Task<List<EmployeeExperiences>> GetEmployeeExperience(Guid employeeId)
        {
            string query = $"SELECT * FROM EmployeeExperiences WHERE EmployeeId='{employeeId}'";
            var result = await Connection.QueryAsync<EmployeeExperiences>(query, transaction: Transaction);
            return result.AsList();
        }

        public async Task<ViewEmployeeSalaryDetails> GetEmployeeSalaryDetails(Guid employeeId)
        {
            var employeeDetails = await GetLast(employeeId);
            string query = $"SELECT * FROM EmployeeBankAccounts WHERE EmployeeId='{employeeId}'";
            var employeeBankAccounts = await Connection.QueryFirstOrDefaultAsync<EmployeeBankAccounts>(query, transaction: Transaction);

            var result = new ViewEmployeeSalaryDetails()
            {
                EmployeeDetails = employeeDetails,
                EmployeeBankAccounts = employeeBankAccounts
            };
            return result;
        }

        public async Task AssignReportingManagerToEmployee(Guid employeeId, Guid reportingManagerId, Guid userId)
        {
            string query = $"UPDATE Employees SET ReportingManageId='{reportingManagerId}', LastUpdatedBy='{userId}',LastUpdated=GETDATE() WHERE Id='{employeeId}'";
            await Connection.ExecuteAsync(query, transaction: Transaction);
        }

        private Employee MapResults(Employee employee, EmployeeDetails employeeDetails)
        {
            employee.EmployeeDetails = employeeDetails;
            return employee;
        }

        private async Task<List<ReportingManger>> GetReportingMangers()
        {
            var query = "SELECT * FROM Employees";
            var result = await Connection.QueryAsync<ReportingManger>(query, transaction: Transaction);
            return result.AsList();
        }
    }
}
