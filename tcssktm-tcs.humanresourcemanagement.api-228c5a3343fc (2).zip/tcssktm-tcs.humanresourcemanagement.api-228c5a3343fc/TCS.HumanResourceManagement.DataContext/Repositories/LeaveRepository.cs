﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.DataContext.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;

namespace TCS.HumanResourceManagement.DataContext.Repositories
{
    public class LeaveRepository : RepositoryBase, ILeaveRepository
    {
        public LeaveRepository(IDbTransaction transaction) : base(transaction)
        {

        }

        public async Task<bool> IsExist(Guid leaveTypeId)
        {
            string query = $"SELECT COUNT(1) FROM LeaveTypes WHERE Id='{leaveTypeId}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task<bool> IsEmployeeLeaveIdExist(Guid employeeLeaveId)
        {
            string query = $"SELECT COUNT(1) FROM EmployeeLeaves WHERE Id='{employeeLeaveId}'";
            var result = await Connection.ExecuteScalarAsync<bool>(query, transaction: Transaction);
            return result;
        }

        public async Task ApplyLeave(EmployeeLeaves employeeLeave)
        {
            string query = $"INSERT INTO EmployeeLeaves" +
                $"(Id,EmployeeId,FromDate,ToDate,TotalDays,Reason,LeaveTypeId,Approver,WorkAssignTo,EmergencyContact,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@FromDate,@ToDate,@TotalDays,@Reason,@LeaveTypeId,@Approver,@WorkAssignTo,@EmergencyContact,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.QueryAsync(query, new
            {
                Id = employeeLeave.Id,
                EmployeeId = employeeLeave.EmployeeId,
                FromDate = employeeLeave.FromDate,
                ToDate = employeeLeave.ToDate,
                TotalDays = employeeLeave.TotalDays,
                Reason = employeeLeave.Reason,
                LeaveTypeId = employeeLeave.LeaveTypeId,
                Approver = employeeLeave.Approver,
                WorkAssignTo = employeeLeave.WorkAssignTo,
                EmergencyContact = employeeLeave.EmergencyContact,
                CreatedBy = employeeLeave.CreatedBy,
                Created = employeeLeave.Created,
                LastUpdatedBy = employeeLeave.LastUpdatedBy,
                LastUpdated = employeeLeave.LastUpdated
            }, transaction: Transaction);


        }

        public async Task<bool> IsLeaveBalanceAvailable(Guid leaveTypeId, Guid employeeId)
        {
            string query = $"SELECT AvailableDays FROM Leaves WHERE LeaveTypeId='{leaveTypeId}' AND EmployeeId='{employeeId}'";
            var result = await Connection.ExecuteScalarAsync<int>(query, transaction: Transaction);
            return result > 0 ? true : false;
        }

        public async Task ApproveOrRejectLeave(Guid employeeLeaveId, Guid approver, bool isApprove, string approverRemarks)
        {
            string query = $"UPDATE EmployeeLeaves SET IsApproved='{isApprove}',LastUpdatedBy='{approver}',LastUpdated=GETDATE(),ApproverRemarks='{approverRemarks}' WHERE Id='{employeeLeaveId}'";
            await Connection.ExecuteAsync(query, transaction: Transaction);

            if (isApprove)
            {
                var employeeLeave = await EmployeeLeaves(employeeLeaveId);
                await UpdateEmployeeLeaveBalance(employeeLeave.LeaveTypeId, employeeLeave.EmployeeId, employeeLeave.TotalDays);
            }
        }

        public async Task<List<ViewEmployeeLeaves>> ViewEmployeeLeaves(Guid employeeId)
        {
            string query = $"SELECT leaveType.Code,leaveType.Description,leave.TotalDays,leave.AvailableDays " +
                $"FROM Leaves leave INNER JOIN LeaveTypes leaveType ON leave.LeaveTypeId=leaveType.Id " +
                $"WHERE leave.EmployeeId='{employeeId}';";

            var result = await Connection.QueryAsync<ViewEmployeeLeaves>(query, transaction: Transaction);
            return result.AsList();
        }

        public async Task<List<ViewEmployeeLeaves>> ViewEmployeeLeaves()
        {
            string query = $"SELECT leaveType.Code,leaveType.Description,leave.TotalDays,leave.AvailableDays " +
                $"FROM Leaves leave INNER JOIN LeaveTypes leaveType ON leave.LeaveTypeId=leaveType.Id ";

            var result = await Connection.QueryAsync<ViewEmployeeLeaves>(query, transaction: Transaction);
            return result.AsList();
        }

        public async Task<List<LeaveTypes>> GetAllLeaveTypes()
        {
            string query = $"SELECT * FROM LeaveTypes";
            var result = await Connection.QueryAsync<LeaveTypes>(query, transaction: Transaction);
            return result.AsList();
        }

        public async Task<EmployeeLeaves> EmployeeLeaves(Guid employeeLeaveId)
        {
            string query = $"SELECT * FROM EmployeeLeaves WHERE Id='{employeeLeaveId}'";
            var result = await Connection.QueryFirstOrDefaultAsync<EmployeeLeaves>(query, transaction: Transaction);
            return result;
        }

        public async Task InitLeaves(Guid employeeId, Guid userId, int casualLeave)
        {
            string query = $"INSERT INTO Leaves" +
                $"(Id,EmployeeId,LeaveTypeId,TotalDays,AvailableDays,CreatedBy,Created,LastUpdatedBy,LastUpdated)" +
                $"VALUES(@Id,@EmployeeId,@LeaveTypeId,@TotalDays,@AvailableDays,@CreatedBy,@Created,@LastUpdatedBy,@LastUpdated)";

            await Connection.ExecuteAsync(query, new
            {
                Id = Guid.NewGuid(),
                EmployeeId = employeeId,
                LeaveTypeId = Guid.Parse("87264578-5CF3-4419-B5ED-5B0B636B051D"),
                TotalDays = casualLeave,
                AvailableDays = casualLeave,
                CreatedBy = userId,
                Created = DateTime.Now,
                LastUpdatedBy = userId,
                LastUpdated = DateTime.Now
            }, transaction: Transaction);

            var allLeaves = await GetAllLeaveTypes();
            foreach (var leave in allLeaves.Where(c => c.DefaultLeaveDays != null))
            {
                await Connection.ExecuteAsync(query, new
                {
                    Id = Guid.NewGuid(),
                    EmployeeId = employeeId,
                    LeaveTypeId = leave.Id,
                    TotalDays = leave.DefaultLeaveDays.Value,
                    AvailableDays = leave.DefaultLeaveDays.Value,
                    CreatedBy = userId,
                    Created = DateTime.Now,
                    LastUpdatedBy = userId,
                    LastUpdated = DateTime.Now
                }, transaction: Transaction);
            }
        }

        public async Task<List<ViewAppliedLeaves>> ViewAppliedLeaves(Guid? employeeId, DateTime? fromDate, DateTime? todate, Guid? approverId, bool? isApproved)
        {
            var queryBuilder = new SqlBuilder();
            string query = $"SELECT employeeLeave.Id,employee.Id AS EmployeeId,employee.EmployeeCode,employee.FirstName,employee.LastName," +
                            $"employeeLeave.FromDate,employeeLeave.ToDate,employeeLeave.TotalDays,employeeLeave.IsApproved,employeeLeave.Reason," +
                            $"(SELECT CONCAT(EmployeeCode, '-', FirstName, ' ', LastName) FROM Employees WHERE Id = employeeLeave.Approver) AS ApproverName," +
                            $"leaveType.Code AS LeaveCode,leaveType.Description AS LeaveDescription, employeeLeave.Created AS AppliedDate FROM Employees employee " +
                            $"INNER JOIN EmployeeLeaves employeeLeave ON employee.Id = employeeLeave.EmployeeId " +
                            $"INNER JOIN LeaveTypes leaveType ON leaveType.Id = employeeLeave.LeaveTypeId";

            var sql = queryBuilder.AddTemplate($"{query} /**where**/ ");

            if (employeeId.HasValue)
                queryBuilder.Where("employee.Id = @employeeId", new { employeeId = employeeId.Value });

            if (fromDate.HasValue)
                queryBuilder.Where("employeeLeave.Created >= @fromDate", new { fromDate = fromDate.Value });

            if (todate.HasValue)
                queryBuilder.Where("employeeLeave.Created <= @todate", new { todate = todate.Value });

            if (approverId.HasValue)
                queryBuilder.Where("employeeLeave.Approver = @approverId", new { approverId = approverId.Value });

            if (isApproved.HasValue)
                queryBuilder.Where("employeeLeave.IsApproved = @isApproved", new { isApproved = isApproved.Value });

            var result = await Connection.QueryAsync<ViewAppliedLeaves>(sql.RawSql, sql.Parameters, transaction: Transaction);
            return result.OrderByDescending(c => c.AppliedDate).AsList();

        }

        public async Task<bool> IsAlreadyAppliedLeaveByDate(DateTime fromDate,DateTime toDate,Guid employeeId)
        {
            string query = $"SELECT COUNT(1) from EmployeeLeaves where (FromDate >= @fromDate and FromDate <= @fromDate ) OR (todate >= @toDate and todate <= @toDate) " +
                            $" and employeeid = @employeeId";


            var result = await Connection.ExecuteScalarAsync<bool>(query, new
            {
                fromDate = fromDate,
                toDate = toDate,
                employeeId = employeeId
            }, transaction: Transaction);
            return result;

        }


        private async Task UpdateEmployeeLeaveBalance(Guid leaveTypeId, Guid employeeId, double totalDays)
        {
            var availableLeaveBalance = await GetAvailableLeaveBalance(leaveTypeId, employeeId);
            availableLeaveBalance = availableLeaveBalance - totalDays;

            string query = $"UPDATE Leaves SET AvailableDays={availableLeaveBalance} WHERE LeaveTypeId='{leaveTypeId}' AND EmployeeId='{employeeId}'";
            await Connection.ExecuteAsync(query, transaction: Transaction);
        }

        private async Task<double> GetAvailableLeaveBalance(Guid leaveTypeId, Guid employeeId)
        {
            string query = $"SELECT AvailableDays FROM Leaves WHERE LeaveTypeId='{leaveTypeId}' AND EmployeeId='{employeeId}'";
            var result = await Connection.ExecuteScalarAsync<int>(query, transaction: Transaction);
            return result;
        }
    }
}
