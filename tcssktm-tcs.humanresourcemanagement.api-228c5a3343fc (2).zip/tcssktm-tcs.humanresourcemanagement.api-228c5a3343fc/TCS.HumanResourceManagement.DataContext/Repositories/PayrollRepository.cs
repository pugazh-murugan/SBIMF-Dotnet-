﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using TCS.HumanResourceManagement.DataContext.Interfaces;
using TCS.HumanResourceManagement.DataModel.Model.Payroll;

namespace TCS.HumanResourceManagement.DataContext.Repositories
{
    public class PayrollRepository : RepositoryBase, IPayrollRepository
    {
        public PayrollRepository(IDbTransaction transaction) : base(transaction)
        {

        }

        public async Task<List<PayrollProcessingViewModel>> PayrollProcess()
        {
            string query = $"SELECT employee.Id AS EmployeeId,employee.EmployeeCode,employee.FirstName,employee.LastName,employee.DateOfJoin,designations.Description AS Designation," +
                $"employeeDetails.BasicSalary,employeeBankAccount.AccountantName,employeeBankAccount.BankName,employeeBankAccount.AccountNumber,employeeBankAccount.IfscCode " +
                $"FROM Employees employee INNER JOIN EmployeeDetails employeeDetails ON employee.Id=employeeDetails.EmployeeId " +
                $"INNER JOIN EmployeeBankAccounts employeeBankAccount ON employee.Id=employeeBankAccount.EmployeeId " +
                $"INNER JOIN Designations designations ON designations.Id=employeeDetails.DesignationId WHERE employee.IsActive=1";

            var result = await Connection.QueryAsync<PayrollProcessingViewModel>(query, transaction: Transaction);
            return result.AsList();
        }
    }
}
