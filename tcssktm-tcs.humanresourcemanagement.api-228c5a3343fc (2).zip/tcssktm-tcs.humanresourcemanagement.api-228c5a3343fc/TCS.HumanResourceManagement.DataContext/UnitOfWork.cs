﻿using System;
using System.Data;
using System.Data.SqlClient;
using TCS.HumanResourceManagement.DataContext.Interfaces;
using TCS.HumanResourceManagement.DataContext.Repositories;

namespace TCS.HumanResourceManagement.DataContext
{
    public class UnitOfWork : IUnitOfWork
    {
        private IDbConnection connection;
        private IDbTransaction transaction;
        private bool disposed;

        public UnitOfWork(string connectionString)
        {
            connection = new SqlConnection(connectionString);
            connection.Open();
            transaction = connection.BeginTransaction();
        }

        private IEmployeeRepository employeeRepository;
        private ILeaveRepository leaveRepository;
        private IDepartmentRepository departmentRepository;
        private ITimeAndAttendanceRepository timeAndAttendanceRepository;
        private IDesignationRepository designationRepository;
        private IJobsRepository jobsRepository;
        private IPayrollRepository payrollRepository;

        public IEmployeeRepository EmployeeRepository
        {
            get { return employeeRepository ?? (employeeRepository = new EmployeeRepository(transaction, DesignationRepository)); }
        }

        public ILeaveRepository LeaveRepository
        {
            get { return leaveRepository ?? (leaveRepository = new LeaveRepository(transaction)); }
        }

        public IDepartmentRepository DepartmentRepository
        {
            get { return departmentRepository ?? (departmentRepository = new DepartmentRepository(transaction)); }
        }

        public ITimeAndAttendanceRepository TimeAndAttendanceRepository
        {
            get { return timeAndAttendanceRepository ?? (timeAndAttendanceRepository = new TimeAndAttendanceRepository(transaction, EmployeeRepository)); }
        }

        public IDesignationRepository DesignationRepository
        {
            get { return designationRepository ?? (designationRepository = new DesignationRepository(transaction)); }
        }

        public IJobsRepository JobsRepository
        {
            get { return jobsRepository ?? (jobsRepository = new JobsRepository(transaction, EmployeeRepository)); }
        }

        public IPayrollRepository PayrollRepository
        {
            get { return payrollRepository ?? (payrollRepository = new PayrollRepository(transaction)); }
        }

        public void Commit()
        {
            try
            {
                transaction.Commit();
            }
            catch (SqlException ex)
            {
                transaction.Rollback();
                throw ex;
            }
            finally
            {
                transaction.Dispose();
                transaction = connection.BeginTransaction();
                resetRepositories();
            }
        }

        private void resetRepositories()
        {
            employeeRepository = null;
            leaveRepository = null;
            departmentRepository = null;
            timeAndAttendanceRepository = null;
            designationRepository = null;
            jobsRepository = null;
            payrollRepository = null;
        }

        public void Dispose()
        {
            dispose(true);
            GC.SuppressFinalize(this);
        }

        private void dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    if (transaction != null)
                    {
                        transaction.Dispose();
                        transaction = null;
                    }
                    if (connection != null)
                    {
                        connection.Dispose();
                        connection = null;
                    }
                }
                disposed = true;
            }
        }

        ~UnitOfWork()
        {
            dispose(false);
        }
    }
}
