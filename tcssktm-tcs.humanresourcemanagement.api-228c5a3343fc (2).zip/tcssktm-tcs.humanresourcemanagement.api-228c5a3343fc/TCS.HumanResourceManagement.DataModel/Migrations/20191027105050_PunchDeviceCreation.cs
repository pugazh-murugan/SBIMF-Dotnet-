﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace TCS.HumanResourceManagement.DataModel.Migrations
{
    public partial class PunchDeviceCreation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                schema: "dbo",
                name: "PunchingDeviceDetails",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    DeviceName = table.Column<string>(nullable: true, maxLength: 255),
                    DeviceIP = table.Column<string>(nullable: true, maxLength: 25),
                    DeviceBranchId = table.Column<Guid>(nullable: true),
                    DevicePlace = table.Column<string>(nullable: true, maxLength: 255),
                    CreatedBy = table.Column<Guid>(nullable: true),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                {
                    table.PrimaryKey(name: "PK_PunchingDeviceDetails_Id", columns: x => x.Id);
                }
                );
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(name: "PunchingDeviceDetails", schema: "dbo");
        }
    }
}
