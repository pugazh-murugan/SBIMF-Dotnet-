﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace TCS.HumanResourceManagement.DataModel.Migrations
{
    public partial class OnDutyEntries : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable
              (
              schema: "dbo",
              name: "OnDuties",
              columns: table => new
              {
                  Id = table.Column<Guid>(nullable: false),
                  EmployeeId = table.Column<Guid>(nullable: false),
                  Branch = table.Column<Guid>(nullable: false),
                  FromDate = table.Column<DateTime>(nullable: false),
                  ToDate = table.Column<DateTime>(nullable: false),
                  Reason = table.Column<string>(nullable: true,maxLength:1000),
                  IsPresent = table.Column<bool>(nullable:true),
                  Present = table.Column<DateTime>(nullable: true),
                  CreatedBy = table.Column<Guid>(nullable: false),
                  Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                  LastUpdatedBy = table.Column<Guid>(nullable: false),
                  LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
              },
               constraints: table =>
               {
                   table.PrimaryKey(name: "PK_OnDuties_Id", columns: x => x.Id);
                   table.ForeignKey(name: "FK_OnDuties_EmployeeId", column: x => x.EmployeeId,
                       principalSchema: "dbo",
                       principalTable: "Employees",
                       principalColumn: "Id");
               });

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_OnDuties_EmployeeId", table: "OnDuties", schema: "dbo");
            migrationBuilder.DropTable(name: "OnDuties", schema: "dbo");
        }
    }
}
