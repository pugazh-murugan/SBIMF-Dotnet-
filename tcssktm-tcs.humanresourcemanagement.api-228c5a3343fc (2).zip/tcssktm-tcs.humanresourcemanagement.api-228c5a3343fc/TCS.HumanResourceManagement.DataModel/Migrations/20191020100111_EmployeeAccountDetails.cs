﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace TCS.HumanResourceManagement.DataModel.Migrations
{
    public partial class EmployeeAccountDetails : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EmployeeBankAccounts",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    AccountantName = table.Column<string>(maxLength: 1000, nullable: false),
                    BankName = table.Column<string>(maxLength: 1000, nullable: false),
                    AccountNumber = table.Column<string>(maxLength: 1000, nullable: false),
                    IfscCode = table.Column<string>(maxLength: 1000, nullable: false),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_EmployeeBankAccounts_Id", columns: x => x.Id);
                     table.UniqueConstraint(name: "UK_EmployeeBankAccounts_AccountNumber", columns: x => x.AccountNumber);
                     table.ForeignKey(name: "FK_EmployeeBankAccounts_EmployeeId", column: x => x.EmployeeId,
                         principalSchema: "dbo", principalTable: "Employees", principalColumn: "Id");

                 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_EmployeeBankAccounts_EmployeeId", table: "EmployeeBankAccounts", schema: "dbo");
            migrationBuilder.DropTable(name: "EmployeeBankAccounts", schema: "dbo");
        }
    }
}
