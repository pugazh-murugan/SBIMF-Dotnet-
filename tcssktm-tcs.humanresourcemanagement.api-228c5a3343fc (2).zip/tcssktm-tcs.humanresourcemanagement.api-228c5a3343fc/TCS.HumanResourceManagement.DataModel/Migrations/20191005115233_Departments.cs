﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace TCS.HumanResourceManagement.DataModel.Migrations
{
    public partial class Departments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Departments",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Code = table.Column<string>(nullable: false, maxLength: 20),
                    Description = table.Column<string>(nullable: false, maxLength: 255),
                    Status = table.Column<bool>(nullable: false, defaultValue: true),
                    CreatedBy = table.Column<Guid>(nullable: true),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: true),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_Departments_Id", columns: x => x.Id);
                     table.UniqueConstraint(name: "UK_Departments_Code", columns: x => x.Code);
                     table.UniqueConstraint(name: "UK_Departments_Description", columns: x => x.Description);
                 }
            );

            migrationBuilder.InsertData(schema: "dbo", table: "Departments",
                columns: new[] { "Id", "Code", "Description", "CreatedBy","LastUpdatedBy" },
                values: new object[,]
                {
                    { "5B94102A-AC8B-4FB1-9090-D09F3A48AA93", "IT", "Information Technology", "ACBA22E3-CAAD-4029-8EF9-59AA58192CE9","ACBA22E3-CAAD-4029-8EF9-59AA58192CE9" },
                    { "ABECE5B7-8764-4613-A482-318006B257B4", "MIS", "Management Information System", "ACBA22E3-CAAD-4029-8EF9-59AA58192CE9","ACBA22E3-CAAD-4029-8EF9-59AA58192CE9" },
                    { "DC04D440-62AF-489F-B8D5-FB931B06CFDE", "ONLINE", "Online", "ACBA22E3-CAAD-4029-8EF9-59AA58192CE9","ACBA22E3-CAAD-4029-8EF9-59AA58192CE9"},
                    { "8597DD03-2834-4243-B44E-8C728FD4B60B", "SKTM", "SKTM", "ACBA22E3-CAAD-4029-8EF9-59AA58192CE9","ACBA22E3-CAAD-4029-8EF9-59AA58192CE9"},
                    { "23EC945B-45B0-45BA-AE13-D1F0C8204ECC", "TCS", "TCS", "ACBA22E3-CAAD-4029-8EF9-59AA58192CE9","ACBA22E3-CAAD-4029-8EF9-59AA58192CE9"}
                }
            );


            migrationBuilder.AddColumn<Guid>(name: "DepartmentId", table: "EmployeeDetails", nullable: true);

            migrationBuilder.AddForeignKey(name: "FK_EmployeeDetails_DepartmentId", table: "EmployeeDetails", column: "DepartmentId",
                principalColumn: "Id", principalTable: "Departments", principalSchema: "dbo",
                onDelete: ReferentialAction.Cascade,
                onUpdate: ReferentialAction.NoAction);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_EmployeeDetails_DepartmentId", table: "EmployeeDetails", schema: "dbo");
            migrationBuilder.DropColumn(name: "DepartmentId", table: "EmployeeDetails", schema: "dbo");
            migrationBuilder.DropTable(name: "Departments", schema: "dbo");
        }
    }
}
