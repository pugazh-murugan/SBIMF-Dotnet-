﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace TCS.HumanResourceManagement.DataModel.Migrations
{
    public partial class designation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
               name: "Designations",
               schema: "dbo",
               columns: table => new
               {
                   Id = table.Column<Guid>(nullable: false),
                   Code = table.Column<string>(nullable: false, maxLength: 255),
                   Description = table.Column<string>(nullable: false, maxLength: 255),
                   Status = table.Column<bool>(nullable: false, defaultValue: true),
                   CreatedBy = table.Column<Guid>(nullable: true),
                   Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                   LastUpdatedBy = table.Column<Guid>(nullable: true),
                   LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
               },
               constraints: table =>
               {
                   table.PrimaryKey(name: "PK_Designations_Id", columns: x => x.Id);
                   table.UniqueConstraint(name: "UK_Designations_Code", columns: x => x.Code);
                   table.UniqueConstraint(name: "UK_Designations_Description", columns: x => x.Description);
               }
           );

            migrationBuilder.DropColumn(name: "Designation", table: "EmployeeDetails", schema: "dbo");
            migrationBuilder.AddColumn<Guid>(name: "DesignationId", table: "EmployeeDetails", nullable: true, schema: "dbo");

            migrationBuilder.AddForeignKey(name: "FK_EmployeeDetails_DesignationId", table: "EmployeeDetails", column: "DesignationId",
                principalColumn: "Id", principalTable: "Designations", principalSchema: "dbo",
                onDelete: ReferentialAction.Cascade,
                onUpdate: ReferentialAction.NoAction);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_EmployeeDetails_Designation", table: "EmployeeDetails", schema: "dbo");
            migrationBuilder.DropColumn(name: "DesignationId", table: "EmployeeDetails", schema: "dbo");
            migrationBuilder.AddColumn<string>(name: "Designation", table: "EmployeeDetails", nullable: true, schema: "dbo");
            migrationBuilder.DropTable(name: "Designations", schema: "dbo");
        }
    }
}
