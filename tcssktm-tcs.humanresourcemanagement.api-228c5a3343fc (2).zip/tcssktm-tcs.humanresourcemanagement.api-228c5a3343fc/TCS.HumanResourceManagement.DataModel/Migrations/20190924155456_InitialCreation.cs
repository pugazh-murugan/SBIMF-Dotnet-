﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace TCS.HumanResourceManagement.DataModel.Migrations
{
    public partial class InitialCreation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employees",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeCode = table.Column<string>(maxLength: 100, nullable: false),
                    FirstName = table.Column<string>(maxLength: 255, nullable: false),
                    LastName = table.Column<string>(maxLength: 255, nullable: false),
                    Gender = table.Column<string>(maxLength: 5, nullable: true),
                    Branch = table.Column<Guid>(nullable: true),
                    PANNumber = table.Column<string>(maxLength: 255, nullable: true),
                    AadharNumber = table.Column<string>(maxLength: 255, nullable: true),
                    PersonalEmail = table.Column<string>(nullable: true, maxLength: 255),
                    OfficialEmail = table.Column<string>(nullable: true, maxLength: 255),
                    MobileNumber = table.Column<string>(nullable: false, maxLength: 20),
                    IsMobileNumberVerified = table.Column<bool>(nullable: true, defaultValue: false),
                    AlternateNumber = table.Column<string>(maxLength: 20, nullable: true),
                    Avatar = table.Column<string>(nullable: true, maxLength: 2000),
                    DateOfBirth = table.Column<DateTime>(nullable: true),
                    DateOfJoin = table.Column<DateTime>(nullable: true),
                    ReportingManageId = table.Column<Guid>(nullable: true),
                    IsMarried = table.Column<bool>(nullable: true, defaultValue: false),
                    SpouseName = table.Column<string>(nullable: true, maxLength: 255),
                    HaveChild = table.Column<bool>(nullable: true, defaultValue: false),
                    NumberOfChild = table.Column<int>(nullable: true, defaultValue: 0),
                    IsActive = table.Column<bool>(nullable: false, defaultValue: true),
                    IsExitInitiated = table.Column<bool>(nullable: false, defaultValue: false),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_Employees_Id", columns: x => x.Id);
                     table.UniqueConstraint(name: "UK_Employees_EmployeeCode", columns: x => x.EmployeeCode);
                     table.UniqueConstraint(name: "UK_Employees_MobileNumber", columns: x => x.MobileNumber);
                     table.UniqueConstraint(name: "UK_Employees_PANNumber", columns: x => x.PANNumber);
                     table.UniqueConstraint(name: "UK_Employees_AadharNumber", columns: x => x.AadharNumber);
                 });
            migrationBuilder.CreateIndex(name: "IDX_Employees_EmployeeCode", table: "Employees", column: "EmployeeCode");

            migrationBuilder.CreateTable(
                name: "EmployeeDetails",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    Designation = table.Column<string>(nullable: true, maxLength: 255),
                    BasicSalary = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    HRA = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    PF = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    DA = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    SpecialAllowance = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    FoodAllowance = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    CarAllowance = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    MedicalAllowance = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    MobileAllowance = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                {
                    table.PrimaryKey(name: "PK_EmployeeDetails_Id", columns: x => x.Id);
                    table.ForeignKey(name: "FK_EmployeeDetails_EmployeeId", column: x => x.EmployeeId,
                        principalSchema: "dbo",
                        principalTable: "Employees",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade,
                        onUpdate: ReferentialAction.Cascade
                        );
                });

            migrationBuilder.CreateTable(
                name: "EmployeeAddresses",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    ResidenceAddressLine1 = table.Column<string>(maxLength: 1000, nullable: false),
                    ResidenceAddressLine2 = table.Column<string>(maxLength: 1000, nullable: true),
                    ResidenceCity = table.Column<string>(maxLength: 100, nullable: true),
                    ResidenceState = table.Column<string>(maxLength: 100, nullable: true),
                    ResidenceCountry = table.Column<string>(maxLength: 100, nullable: true),
                    ResidencePostalCode = table.Column<string>(maxLength: 10, nullable: true),
                    PermanentAddressLine1 = table.Column<string>(maxLength: 1000, nullable: false),
                    PermanentAddressLine2 = table.Column<string>(maxLength: 1000, nullable: true),
                    PermanentCity = table.Column<string>(maxLength: 100, nullable: true),
                    PermanentState = table.Column<string>(maxLength: 100, nullable: true),
                    PermanentCountry = table.Column<string>(maxLength: 100, nullable: true),
                    PermanentPostalCode = table.Column<string>(maxLength: 10, nullable: true),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                 constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_EmployeeAddresses_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_EmployeeAddresses_EmployeeId", column: x => x.EmployeeId,
                         principalSchema: "dbo",
                         principalTable: "Employees",
                         principalColumn: "Id");
                 });

            migrationBuilder.CreateTable
                (
                schema:"dbo",
                name:"EmployeeQualifications",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId=table.Column<Guid>(nullable:false),
                    Qualification=table.Column<string>(nullable:false,maxLength:100),
                    University=table.Column<string>(nullable: false, maxLength: 1000),
                    YearOfPassedOut =table.Column<int>(nullable:false),
                    Percentage=table.Column<double>(nullable:true),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                 constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_EmployeeQualifications_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_EmployeeQualifications_EmployeeId", column: x => x.EmployeeId,
                         principalSchema: "dbo",
                         principalTable: "Employees",
                         principalColumn: "Id");
                 });

            migrationBuilder.CreateTable
                (
                schema: "dbo",
                name: "EmployeeExperiences",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    From = table.Column<DateTime>(nullable: false),
                    To = table.Column<DateTime>(nullable: false),
                    CompanyName = table.Column<string>(nullable: false),
                    Designation = table.Column<string>(nullable: true),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                 constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_EmployeeExperiences_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_EmployeeExperiences_EmployeeId", column: x => x.EmployeeId,
                         principalSchema: "dbo",
                         principalTable: "Employees",
                         principalColumn: "Id");
                 });



            migrationBuilder.CreateTable(
                name: "LeaveTypes",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Code = table.Column<string>(nullable: false, maxLength: 25),
                    Description = table.Column<string>(nullable: false, maxLength: 255),
                    IsActive = table.Column<bool>(nullable: false, defaultValue: true),
                    DefaultLeaveDays = table.Column<int>(nullable: true),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_LeaveTypes_Id", columns: x => x.Id);
                     table.UniqueConstraint(name: "UK_LeaveTypes_Code", columns: x => x.Code);
                 });
            migrationBuilder.InsertData(schema: "dbo", table: "LeaveTypes",
                columns: new[] { "Id", "Code", "Description", "DefaultLeaveDays" },
                values: new object[,]
                {
                    { "D7C1647B-CC62-4A19-9BF4-943FC05C2D40", "SL", "Sick Leave", 12 },
                    { "87264578-5CF3-4419-B5ED-5B0B636B051D", "CL", "Casual Leave", null },
                    { "6E00F179-5FCB-4E95-B134-651E22412CE6", "ML", "Maternity Leave", null},
                    { "482ED001-6D26-4930-8A51-FEA121D79C24", "EL", "Earned Leave", 12},
                    { "0ED822F4-46BE-4D80-BA8F-4EA84A6360E3", "PL", "Paternity Leave", null}
                }
            );

            migrationBuilder.CreateTable(
                name: "Leaves",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    LeaveTypeId = table.Column<Guid>(nullable: false),
                    TotalDays = table.Column<double>(nullable: false, defaultValue: 0),
                    AvailableDays = table.Column<double>(nullable: false, defaultValue: 0),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_Leaves_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_Leaves_EmployeeId", column: x => x.EmployeeId,
                        principalSchema: "dbo",
                        principalTable: "Employees",
                        principalColumn: "Id"
                        );
                 });

            migrationBuilder.CreateTable(
                name: "EmployeeLeaves",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    FromDate = table.Column<DateTime>(nullable: false),
                    ToDate = table.Column<DateTime>(nullable: false),
                    TotalDays = table.Column<double>(nullable: false),
                    Reason = table.Column<string>(maxLength: 1500, nullable: true),
                    LeaveTypeId = table.Column<Guid>(nullable: false),
                    IsApproved = table.Column<bool>(nullable: true),
                    Approver = table.Column<Guid>(nullable: false),
                    ApproverRemarks = table.Column<string>(maxLength: 1500, nullable: true),
                    WorkAssignTo = table.Column<Guid>(nullable: true),
                    EmergencyContact = table.Column<string>(maxLength: 50, nullable: true),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_EmployeeLeaves_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_EmployeeLeaves_EmployeeId", column: x => x.EmployeeId,
                        principalSchema: "dbo",
                        principalTable: "Employees",
                        principalColumn: "Id"
                        );
                     table.ForeignKey(name: "FK_EmployeeLeaves_Approver", column: x => x.Approver,
                        principalSchema: "dbo",
                        principalTable: "Employees",
                        principalColumn: "Id"
                        );
                     table.ForeignKey(name: "FK_EmployeeDetails_LeaveTypeId", column: x => x.LeaveTypeId,
                         principalSchema: "dbo",
                         principalTable: "LeaveTypes",
                         principalColumn: "Id",
                         onDelete: ReferentialAction.Cascade,
                         onUpdate: ReferentialAction.Cascade
                         );
                 });

            migrationBuilder.CreateTable(
                name: "TimeAndAttendance",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    InTime = table.Column<DateTime>(nullable: true),
                    OutTime = table.Column<DateTime>(nullable: true),
                    BioMetricIP = table.Column<string>(nullable: true, maxLength: 25),
                    DeviceSerialNumber = table.Column<string>(nullable: true, maxLength: 255),
                    PunchType = table.Column<string>(maxLength: 25, nullable: false),
                    IsManual = table.Column<bool>(nullable: false, defaultValue: false),
                    Remarks = table.Column<string>(maxLength: 500, nullable: true),
                    LocationId = table.Column<Guid>(nullable: false),
                    CreatedBy = table.Column<Guid>(nullable: true),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_TimeAndAttendance_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_TimeAndAttendance_EmployeeId", column: x => x.EmployeeId,
                       principalSchema: "dbo",
                       principalTable: "Employees",
                       principalColumn: "Id"
                       );
                 });

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_TimeAndAttendance_EmployeeId", table: "TimeAndAttendance", schema: "dbo");
            migrationBuilder.DropTable("TimeAndAttendance");

            migrationBuilder.DropForeignKey(name: "FK_EmployeeDetails_LeaveTypeId", table: "EmployeeLeaves", schema: "dbo");
            migrationBuilder.DropForeignKey(name: "FK_EmployeeLeaves_Approver", table: "EmployeeLeaves", schema: "dbo");
            migrationBuilder.DropForeignKey(name: "FK_EmployeeLeaves_EmployeeId", table: "EmployeeLeaves", schema: "dbo");
            migrationBuilder.DropTable("EmployeeLeaves");

            migrationBuilder.DropForeignKey(name: "FK_Leaves_EmployeeId", table: "Leaves", schema: "dbo");
            migrationBuilder.DropTable("Leaves");

            migrationBuilder.DropTable("LeaveTypes");

            migrationBuilder.DropForeignKey(name: "FK_EmployeeExperiences_EmployeeId", table: "EmployeeExperiences", schema: "dbo");
            migrationBuilder.DropTable("EmployeeExperiences");

            migrationBuilder.DropForeignKey(name: "FK_EmployeeQualifications_EmployeeId", table: "EmployeeQualifications", schema: "dbo");
            migrationBuilder.DropTable("EmployeeQualifications");

            migrationBuilder.DropForeignKey(name: "FK_EmployeeAddresses_EmployeeId", table: "EmployeeAddresses", schema: "dbo");
            migrationBuilder.DropTable("EmployeeAddresses");

            migrationBuilder.DropForeignKey(name: "FK_EmployeeDetails_EmployeeId", table: "EmployeeDetails", schema: "dbo");
            migrationBuilder.DropTable("EmployeeDetails");

            migrationBuilder.DropIndex(name: "IDX_Employees_EmployeeCode", table: "Employees");
            migrationBuilder.DropTable("Employees");
        }
    }
}
