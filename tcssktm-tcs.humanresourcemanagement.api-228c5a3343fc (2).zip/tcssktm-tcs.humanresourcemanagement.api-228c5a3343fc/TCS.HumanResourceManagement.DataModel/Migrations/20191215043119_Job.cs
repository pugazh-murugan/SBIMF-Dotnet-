﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;

namespace TCS.HumanResourceManagement.DataModel.Migrations
{
    public partial class Job : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
              name: "DocumentTypes",
              schema: "dbo",
              columns: table => new
              {
                  Id = table.Column<Guid>(nullable: false),
                  Description = table.Column<string>(nullable: false, maxLength: 255),
                  IsActive = table.Column<bool>(nullable: false, defaultValue: true),
              },
              constraints: table =>
              {
                  table.PrimaryKey(name: "PK_DocumentTypes_Id", columns: x => x.Id);
                  table.UniqueConstraint(name: "UK_DocumentTypes_Description", columns: x => x.Description);
              });

            migrationBuilder.InsertData(schema: "dbo", table: "DocumentTypes",
               columns: new[] { "Id", "Description" },
               values: new object[,]
               {
                    { "766A1F82-26BC-452B-9D42-870948C9AB33", "Profile Photo"},
                    { "A5EC02D0-540E-4213-ACF6-210226748B8E", "PAN Card" },
                    { "4242AC68-CA14-4BE8-88C9-FC23B5803013", "Aadhar Card" },
                    { "81EED389-C5F5-4979-89BC-7EB58CCC9907", "SSLC"},
                    { "F5C4B451-F35F-49A1-9DD3-6AF3A0D645D1", "HSC"},
                    { "29B215C8-D840-4CE1-8DBF-7EFC346FDFB4", "UG"},
                    { "B59C9414-BCBD-4DF6-BE97-DC23CF01A633", "PG" },
                    { "EBCBE59E-D24B-4BDD-977D-F38B505C1F42", "Phd" },
                    { "C5E5607A-C463-43E8-8DCF-541D6CE9C234", "Bank Pass Book" }
               }
           );


            migrationBuilder.CreateTable(
               name: "Candidates",
               schema: "dbo",
               columns: table => new
               {
                   Id = table.Column<Guid>(nullable: false),
                   Location = table.Column<Guid>(nullable: false),
                   ApplicationId = table.Column<int>(nullable: false),
                   FirstName = table.Column<string>(nullable: false, maxLength: 255),
                   LastName = table.Column<string>(nullable: false, maxLength: 255),
                   DateOfBirthInCertificate = table.Column<DateTime>(nullable: false),
                   DateOfBirthOriginal = table.Column<DateTime>(nullable: false),
                   Age = table.Column<int>(nullable: false),
                   Gender = table.Column<string>(nullable: false, maxLength: 20),
                   Email = table.Column<string>(nullable: true, maxLength: 255),
                   MobileNumber = table.Column<string>(nullable: false, maxLength: 20),
                   AlternateNumber = table.Column<string>(nullable: true, maxLength: 20),
                   EmergencyContactNo = table.Column<string>(nullable: true, maxLength: 20),
                   PANNumber = table.Column<string>(maxLength: 255, nullable: false),
                   AadharNumber = table.Column<string>(maxLength: 255, nullable: false),
                   Avatar = table.Column<string>(nullable: true, maxLength: 2000),
                   WeddingDay = table.Column<DateTime>(nullable: true),
                   BloodGroup = table.Column<string>(maxLength: 20, nullable: true),
                   InterviewDate = table.Column<DateTime>(nullable: false),
                   DateOfJoin = table.Column<DateTime>(nullable: false),
                   TotalYearOfExperience = table.Column<int>(nullable: true),
                   CurrentSalary = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                   ExpectedSalary = table.Column<decimal>(nullable: true, defaultValue: "0.00"),
                   IsHostelRequired = table.Column<bool>(nullable: false, defaultValue: false),
                   Comments = table.Column<string>(nullable: true, maxLength: 5000),
                   IsOnRoll = table.Column<bool>(nullable: false, defaultValue: false),
                   CreatedBy = table.Column<Guid>(nullable: true),
                   Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                   LastUpdatedBy = table.Column<Guid>(nullable: true),
                   LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
               },
               constraints: table =>
               {
                   table.PrimaryKey(name: "PK_Candidates_Id", columns: x => x.Id);
                   table.UniqueConstraint(name: "UK_Candidates_MobileNumber", columns: x => x.MobileNumber);
                   table.UniqueConstraint(name: "UK_Candidates_PANNumber", columns: x => x.PANNumber);
                   table.UniqueConstraint(name: "UK_Candidates_AadharNumber", columns: x => x.AadharNumber);
                   table.UniqueConstraint(name: "UK_Candidates_ApplicationId", columns: x => x.ApplicationId);
               });

            migrationBuilder.CreateTable(
               name: "CandidateAddresses",
               schema: "dbo",
               columns: table => new
               {
                   Id = table.Column<Guid>(nullable: false),
                   EmployeeId = table.Column<Guid>(nullable: false),
                   ResidenceAddressLine1 = table.Column<string>(maxLength: 1000, nullable: false),
                   ResidenceAddressLine2 = table.Column<string>(maxLength: 1000, nullable: true),
                   ResidenceCity = table.Column<string>(maxLength: 100, nullable: true),
                   ResidenceState = table.Column<string>(maxLength: 100, nullable: true),
                   ResidenceCountry = table.Column<string>(maxLength: 100, nullable: true),
                   ResidencePostalCode = table.Column<string>(maxLength: 10, nullable: true),
                   ResidenceAddressType = table.Column<int>(nullable: true),
                   PermanentAddressLine1 = table.Column<string>(maxLength: 1000, nullable: false),
                   PermanentAddressLine2 = table.Column<string>(maxLength: 1000, nullable: true),
                   PermanentCity = table.Column<string>(maxLength: 100, nullable: true),
                   PermanentState = table.Column<string>(maxLength: 100, nullable: true),
                   PermanentCountry = table.Column<string>(maxLength: 100, nullable: true),
                   PermanentPostalCode = table.Column<string>(maxLength: 10, nullable: true),
                   PermanentAddressType = table.Column<int>(nullable: true),
                   CreatedBy = table.Column<Guid>(nullable: false),
                   Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                   LastUpdatedBy = table.Column<Guid>(nullable: false),
                   LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
               },
                constraints: table =>
                {
                    table.PrimaryKey(name: "PK_CandidateAddresses_Id", columns: x => x.Id);
                    table.ForeignKey(name: "FK_CandidateAddresses_EmployeeId", column: x => x.EmployeeId,
                        principalSchema: "dbo",
                        principalTable: "Candidates",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable
                (
                schema: "dbo",
                name: "CandidateQualifications",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    Qualification = table.Column<string>(nullable: false, maxLength: 100),
                    University = table.Column<string>(nullable: true, maxLength: 1000),
                    Institution = table.Column<string>(nullable: true, maxLength: 1000),
                    YearOfPassedOut = table.Column<int>(nullable: false),
                    Percentage = table.Column<double>(nullable: true),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                 constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_CandidateQualifications_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_CandidateQualifications_EmployeeId", column: x => x.EmployeeId,
                         principalSchema: "dbo",
                         principalTable: "Candidates",
                         principalColumn: "Id",
                         onDelete: ReferentialAction.Cascade);
                 });

            migrationBuilder.CreateTable
                (
                schema: "dbo",
                name: "CandidateExperiences",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    From = table.Column<DateTime>(nullable: false),
                    To = table.Column<DateTime>(nullable: false),
                    CompanyName = table.Column<string>(nullable: false, maxLength: 255),
                    Designation = table.Column<string>(nullable: true, maxLength: 255),
                    ReasonForLeaving = table.Column<string>(nullable: true, maxLength: 1000),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                 constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_CandidateExperiences_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_CandidateExperiences_EmployeeId", column: x => x.EmployeeId,
                         principalSchema: "dbo",
                         principalTable: "Candidates",
                         principalColumn: "Id",
                         onDelete: ReferentialAction.Cascade);
                 });

            migrationBuilder.CreateTable
                (
                schema: "dbo",
                name: "EmployeeDocuments",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    EmployeeId = table.Column<Guid>(nullable: false),
                    DocumentTypeId = table.Column<Guid>(nullable: false),
                    CreatedBy = table.Column<Guid>(nullable: false),
                    Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                    LastUpdatedBy = table.Column<Guid>(nullable: false),
                    LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
                },
                 constraints: table =>
                 {
                     table.PrimaryKey(name: "PK_EmployeeDocuments_Id", columns: x => x.Id);
                     table.ForeignKey(name: "FK_EmployeeDocuments_EmployeeId", column: x => x.EmployeeId,
                         principalSchema: "dbo",
                         principalTable: "Employees",
                         principalColumn: "Id",
                         onDelete: ReferentialAction.Cascade);
                     table.ForeignKey(name: "FK_EmployeeDocuments_DocumentTypeId", column: x => x.DocumentTypeId,
                        principalSchema: "dbo",
                        principalTable: "DocumentTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                 });

            migrationBuilder.CreateTable
               (
               schema: "dbo",
               name: "DependentDetails",
               columns: table => new
               {
                   Id = table.Column<Guid>(nullable: false),
                   EmployeeId = table.Column<Guid>(nullable: false),
                   Name = table.Column<string>(maxLength: 500, nullable: false),
                   Gender = table.Column<string>(maxLength: 20, nullable: false),
                   DateOfBirth = table.Column<DateTime>(nullable: true),
                   Occupation = table.Column<string>(nullable: true, maxLength: 500),
                   Relationship = table.Column<string>(nullable: false, maxLength: 255),
                   CreatedBy = table.Column<Guid>(nullable: false),
                   Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                   LastUpdatedBy = table.Column<Guid>(nullable: false),
                   LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
               },
                constraints: table =>
                {
                    table.PrimaryKey(name: "PK_DependentDetails_Id", columns: x => x.Id);
                    table.ForeignKey(name: "FK_DependentDetails_EmployeeId", column: x => x.EmployeeId,
                        principalSchema: "dbo",
                        principalTable: "Employees",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable
               (
               schema: "dbo",
               name: "CandidateFamilyDetails",
               columns: table => new
               {
                   Id = table.Column<Guid>(nullable: false),
                   EmployeeId = table.Column<Guid>(nullable: false),
                   Name = table.Column<string>(maxLength: 500, nullable: false),
                   Gender = table.Column<string>(maxLength: 20, nullable: false),
                   DateOfBirth = table.Column<DateTime>(nullable: true),
                   Occupation = table.Column<string>(nullable: true, maxLength: 500),
                   Relationship = table.Column<string>(nullable: false, maxLength: 255),
                   CreatedBy = table.Column<Guid>(nullable: false),
                   Created = table.Column<DateTime>(defaultValue: DateTime.Now),
                   LastUpdatedBy = table.Column<Guid>(nullable: false),
                   LastUpdated = table.Column<DateTime>(defaultValue: DateTime.Now)
               },
                constraints: table =>
                {
                    table.PrimaryKey(name: "PK_CandidateFamilyDetails_Id", columns: x => x.Id);
                    table.ForeignKey(name: "FK_CandidateFamilyDetails_EmployeeId", column: x => x.EmployeeId,
                        principalSchema: "dbo",
                        principalTable: "Candidates",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(name: "FK_CandidateFamilyDetails_EmployeeId", table: "CandidateFamilyDetails", schema: "dbo");
            migrationBuilder.DropTable(name: "CandidateFamilyDetails", schema: "dbo");

            migrationBuilder.DropForeignKey(name: "FK_DependentDetails_EmployeeId", table: "DependentDetails", schema: "dbo");
            migrationBuilder.DropTable(name: "DependentDetails", schema: "dbo");

            migrationBuilder.DropForeignKey(name: "FK_EmployeeDocuments_DocumentTypeId", table: "EmployeeDocuments", schema: "dbo");
            migrationBuilder.DropForeignKey(name: "FK_EmployeeDocuments_EmployeeId", table: "EmployeeDocuments", schema: "dbo");
            migrationBuilder.DropTable(name: "EmployeeDocuments", schema: "dbo");

            migrationBuilder.DropForeignKey(name: "FK_CandidateExperiences_EmployeeId", table: "CandidateExperiences", schema: "dbo");
            migrationBuilder.DropTable(name: "CandidateExperiences", schema: "dbo");

            migrationBuilder.DropForeignKey(name: "FK_CandidateQualifications_EmployeeId", table: "CandidateQualifications", schema: "dbo");
            migrationBuilder.DropTable(name: "CandidateQualifications", schema: "dbo");

            migrationBuilder.DropForeignKey(name: "FK_CandidateAddresses_EmployeeId", table: "CandidateAddresses", schema: "dbo");
            migrationBuilder.DropTable(name: "CandidateAddresses", schema: "dbo");
            migrationBuilder.DropTable(name: "Candidates", schema: "dbo");
            migrationBuilder.DropTable(name: "DocumentTypes", schema: "dbo");
        }
    }
}
