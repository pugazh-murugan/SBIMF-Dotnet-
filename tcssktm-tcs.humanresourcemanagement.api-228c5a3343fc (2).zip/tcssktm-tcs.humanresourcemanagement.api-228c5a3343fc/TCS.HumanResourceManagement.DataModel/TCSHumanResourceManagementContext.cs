﻿using Microsoft.EntityFrameworkCore;

namespace TCS.HumanResourceManagement.DataModel
{
    public class TCSHumanResourceManagementContext : DbContext
    {
        public TCSHumanResourceManagementContext(DbContextOptions options) : base(options)
        {

        }
    }
}
