﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.DataModel.Model.Departments
{
    public class Department : BaseEntity
    {
        public Guid Id { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public bool Status { get; set; }

    }
    public class Departments 
    {
        public string ID { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string Designation { get; set; }
        public bool Active { get; set; }

    }
    public class pagenationResquest
    {
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
    public class pagenationResponse
    {        
       public int CurrentPage { get; set; }
        public int TotalNoofRecords { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get; set; }
        public List<Departments> Iteams { get; set; }
        public bool HashPrevious => CurrentPage > 1;
        public bool HashNext => CurrentPage < TotalPages;
        public pagenationResponse(int CurrentPage1, int TotalNoofRecords1, int PageSize1, int TotalPages1, List<Departments> Iteams1)
        {
            CurrentPage = CurrentPage1;
            TotalNoofRecords = TotalNoofRecords1;
            PageSize = PageSize1;
            TotalPages = TotalPages1;
            Iteams = Iteams1;

        }
    }
}
