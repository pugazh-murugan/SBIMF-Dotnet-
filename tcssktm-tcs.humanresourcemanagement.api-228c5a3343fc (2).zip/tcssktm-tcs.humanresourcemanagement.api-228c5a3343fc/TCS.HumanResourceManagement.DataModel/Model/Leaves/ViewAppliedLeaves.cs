﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.Leaves
{
    public class ViewAppliedLeaves
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public string EmployeeCode { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public int TotalDays { get; set; }

        public DateTime AppliedDate { get; set; }

        public string Reason { get; set; }

        public bool? IsApproved { get; set; }

        public string ApproverName { get; set; }

        public string LeaveCode { get; set; }

        public string LeaveDescription { get; set; }

    }
}
