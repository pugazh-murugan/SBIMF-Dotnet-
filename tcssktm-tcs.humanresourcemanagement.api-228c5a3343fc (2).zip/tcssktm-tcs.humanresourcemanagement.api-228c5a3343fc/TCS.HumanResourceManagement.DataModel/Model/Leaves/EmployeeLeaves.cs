﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.DataModel.Model.Leaves
{
    public class EmployeeLeaves : BaseEntity
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public double TotalDays { get; set; }

        public Guid LeaveTypeId { get; set; }

        public bool? IsApproved { get; set; }

        public Guid Approver { get; set; }

        public string Reason { get; set; }

        public Guid WorkAssignTo { get; set; }

        public string EmergencyContact { get; set; }

        public string ApproverRemarks { get; set; }
    }
}
