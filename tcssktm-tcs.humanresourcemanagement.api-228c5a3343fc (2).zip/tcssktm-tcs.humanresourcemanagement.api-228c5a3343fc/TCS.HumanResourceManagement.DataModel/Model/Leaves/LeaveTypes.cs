﻿using System;
using TCS.HumanResourceManagement.DataModel.Interfaces;

namespace TCS.HumanResourceManagement.DataModel.Model.Leaves
{
    public class LeaveTypes : IId
    {
        public Guid Id { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public int? DefaultLeaveDays { get; set; }

        public bool IsActive { get; set; }

        public DateTime Created { get; set; }

        public string LastUpdated { get; set; }
    }
}
