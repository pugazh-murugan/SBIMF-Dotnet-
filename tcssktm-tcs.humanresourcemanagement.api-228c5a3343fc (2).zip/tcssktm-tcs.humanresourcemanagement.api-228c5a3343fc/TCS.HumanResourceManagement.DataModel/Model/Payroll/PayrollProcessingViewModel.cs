﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.Payroll
{
    public class PayrollProcessingViewModel
    {
        public Guid EmployeeId { get; set; }

        public string EmployeeCode { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfJoin { get; set; }

        public string Designation { get; set; }

        public decimal BasicSalary { get; set; } = 0;

        public decimal Incentives { get; set; } = 0;

        public decimal LossOfPay { get; set; } = 0;

        public decimal GrossAmount { get; set; } = 0;

        public int WorkingDays { get; set; } =0;

        public decimal PresentDays { get; set; } = 0;

        public decimal AbsentDays { get; set; } = 0;

        public string AccountantName { get; set; }

        public string BankName { get; set; }

        public string AccountNumber { get; set; }

        public string IfscCode { get; set; }
    }
}
