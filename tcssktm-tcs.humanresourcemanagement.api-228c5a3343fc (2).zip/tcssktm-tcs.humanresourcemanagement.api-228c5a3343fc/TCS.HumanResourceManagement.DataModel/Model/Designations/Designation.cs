﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.Designations
{
    public class Designation : BaseEntity
    {
        public Guid Id { get; set; }

        public string Code { get; set; }

        public string Description { get; set; }

        public bool Status { get; set; }
    }
}