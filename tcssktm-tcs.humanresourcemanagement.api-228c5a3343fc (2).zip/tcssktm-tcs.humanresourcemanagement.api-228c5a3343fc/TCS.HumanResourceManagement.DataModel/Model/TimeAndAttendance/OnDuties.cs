﻿using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.DataModel.Interfaces;

namespace TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance
{
    public class OnDuties : BaseEntity, IId, IEmployeeId
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public Guid Branch { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public string Reason { get; set; }

        public bool IsPresent { get; set; }

        public DateTime Present { get; set; }


    }
}
