﻿using System;
using System.Collections.Generic;
using System.Text;
using TCS.HumanResourceManagement.DataModel.Interfaces;

namespace TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance
{
    public class EmployeeAttendance : BaseEntity, IId, IEmployeeId
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public DateTime? InTime { get; set; }

        public DateTime? OutTime { get; set; }

        public string BioMetricIP { get; set; }

        public string DeviceSerialNumber { get; set; }

        public string PunchType { get; set; }

        public bool IsManual { get; set; }

        public string Remarks { get; set; }

        public Guid LocationId { get; set; }
    }
}
