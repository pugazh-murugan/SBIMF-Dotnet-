﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance
{
    public class ViewTimeAndAttendance
    {
        public Guid EmployeeId { get; set; }

        public string EmployeeCode { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Section { get; set; }

        public DateTime? InTime { get; set; }

        public DateTime? OutTime { get; set; }

        public string PunchType { get; set; }

        public string BioMetricIP { get; set; }

        public string DeviceSerialNumber { get; set; }

        public bool IsManual { get; set; }

        public Guid? LocationId { get; set; }

        public DateTime? Created { get; set; }

    }
}
