﻿using System;
using TCS.HumanResourceManagement.DataModel.Interfaces;

namespace TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance
{
    public class OnDutiesViewModel : BaseEntity , IId
    {
        public Guid Id { get; set; }

        public string EmployeeCode { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public Guid Branch { get; set; }

        public DateTime FromDate { get; set; }

        public DateTime ToDate { get; set; }

        public string Reason { get; set; }

        public bool IsPresent { get; set; }

        public DateTime? Present { get; set; }


    }
}
