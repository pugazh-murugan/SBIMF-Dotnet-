﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance
{
    public class AttendanceSheet
    {
        public string EmployeeCode { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Branch { get; set; }

        public string Section { get; set; }

    }
}
