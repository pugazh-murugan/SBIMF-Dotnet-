﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class EmployeeBankAccounts : BaseEntity
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public string AccountNumber { get; set; }

        public string AccountantName { get; set; }

        public string BankName { get; set; }

        public string IfscCode { get; set; }
    }
}
