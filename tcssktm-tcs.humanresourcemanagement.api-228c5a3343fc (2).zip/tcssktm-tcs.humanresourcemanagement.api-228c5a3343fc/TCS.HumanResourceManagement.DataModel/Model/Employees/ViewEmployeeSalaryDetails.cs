﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class ViewEmployeeSalaryDetails
    {
        public EmployeeDetails EmployeeDetails { get; set; }

        public EmployeeBankAccounts EmployeeBankAccounts { get; set; }
    }
}
