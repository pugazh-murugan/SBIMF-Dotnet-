﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class ViewEmployeeAddress
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public string ResidenceAddressLine1 { get; set; }

        public string ResidenceAddressLine2 { get; set; }

        public string ResidenceCity { get; set; }

        public string ResidenceState { get; set; }

        public string ResidenceCountry { get; set; }

        public string ResidencePostalCode { get; set; }

        public string PermanentAddressLine1 { get; set; }

        public string PermanentAddressLine2 { get; set; }

        public string PermanentCity { get; set; }

        public string PermanentState { get; set; }

        public string PermanentCountry { get; set; }

        public string PermanentPostalCode { get; set; }
    }
}
