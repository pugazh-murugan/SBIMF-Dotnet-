﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class EmployeeDetails : BaseEntity
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public Guid Designation { get; set; }

        public decimal BasicSalary { get; set; } = 0;

        public decimal HRA { get; set; } = 0;

        public decimal PF { get; set; } = 0;

        public decimal DA { get; set; } = 0;

        public decimal SpecialAllowance { get; set; } = 0;

        public decimal FoodAllowance { get; set; } = 0;

        public decimal CarAllowance { get; set; } = 0;

        public decimal MedicalAllowance { get; set; } = 0;

        public decimal MobileAllowance { get; set; } = 0;

        public Guid? DepartmentId { get; set; }
    }
}
