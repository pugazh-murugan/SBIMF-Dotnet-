﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class Employee : BaseEntity
    {
        public Employee()
        {
            EmployeeDetails = new EmployeeDetails();
            ReportingManger = new ReportingManger();
            EmployeeAddresses = new EmployeeAddresses();
            EmployeeExperiences = new List<EmployeeExperiences>();
            EmployeeQualifications = new List<EmployeeQualifications>();
            DependentDetails = new List<DependentDetails>();
        }

        public Guid Id { get; set; }

        public string EmployeeCode { get; set; }

        public Guid Branch { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Gender { get; set; }

        public string PANNumber { get; set; }

        public string AadharNumber { get; set; }

        public string PersonalEmail { get; set; } = null;

        public string OfficialEmail { get; set; } = null;

        public string MobileNumber { get; set; }

        public bool IsMobileNumberVerified { get; set; } = false;

        public string AlternateNumber { get; set; } = null;

        public string Avatar { get; set; } = null;

        public DateTime DateOfBirth { get; set; }

        public int Age
        {
            get
            {
                var age = DateTime.Now.Year - DateOfBirth.Year;
                if (DateTime.Now.DayOfYear < DateOfBirth.DayOfYear)
                    age = age - 1;
                return age;
            }
        }

        public DateTime DateOfJoin { get; set; }

        public Guid? ReportingManageId { get; set; } = null;

        public bool IsMarried { get; set; }

        public string SpouseName { get; set; }

        public bool HaveChild { get; set; }

        public int NumberOfChild { get; set; }

        public bool IsActive { get; set; } = true;

        public bool IsExitInitiated { get; set; } = false;

        public EmployeeAddresses EmployeeAddresses { get; set; }

        public EmployeeDetails EmployeeDetails { get; set; }

        public ReportingManger ReportingManger { get; set; }

        public EmployeeBankAccounts EmployeeBankAccount { get; set; }

        public List<EmployeeExperiences> EmployeeExperiences { get; set; }

        public List<EmployeeQualifications> EmployeeQualifications { get; set; }

        public List<DependentDetails> DependentDetails { get; set; }
    }
}
