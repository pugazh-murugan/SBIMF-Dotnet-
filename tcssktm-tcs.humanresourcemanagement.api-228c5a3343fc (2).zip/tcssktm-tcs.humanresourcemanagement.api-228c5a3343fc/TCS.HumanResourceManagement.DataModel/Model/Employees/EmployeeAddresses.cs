﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class EmployeeAddresses : BaseEntity
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public Addresses ResidenceAddress { get; set; }

        public Addresses PermanentAddress { get; set; }
    }

    public class Addresses
    {
        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string State { get; set; }

        public string City { get; set; }

        public string Country { get; set; }

        public string PostalCode { get; set; }

        public int AddressType { get; set; }
    }
}