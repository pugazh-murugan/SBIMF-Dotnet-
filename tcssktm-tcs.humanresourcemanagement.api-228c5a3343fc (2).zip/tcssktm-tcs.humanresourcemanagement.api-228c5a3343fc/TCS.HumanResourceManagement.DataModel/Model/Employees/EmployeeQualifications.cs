﻿using System;
using TCS.HumanResourceManagement.DataModel.Interfaces;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class EmployeeQualifications : BaseEntity, IId, IEmployeeId
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public string Qualification { get; set; }

        public string University { get; set; }

        public string Institution { get; set; }

        public int YearOfPassedOut { get; set; }

        public double Percentage { get; set; }

    }
}
