﻿using System;
using TCS.HumanResourceManagement.DataModel.Interfaces;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class DependentDetails : BaseEntity, IId, IEmployeeId
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public string Name { get; set; }

        public string Gender { get; set; }

        public DateTime? DateOfBirth { get; set; }

        public string Occupation { get; set; }

        public string Relationship { get; set; }
    }
}
