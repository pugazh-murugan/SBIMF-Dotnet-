﻿using System;
using TCS.HumanResourceManagement.DataModel.Interfaces;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class EmployeeExperiences : BaseEntity, IId, IEmployeeId, IDesignation
    {
        public Guid Id { get; set; }

        public Guid EmployeeId { get; set; }

        public DateTime From { get; set; }

        public DateTime To { get; set; }

        public string CompanyName { get; set; }

        public string Designation { get; set; }

        public string ReasonForLeaving { get; set; }
    }
}
