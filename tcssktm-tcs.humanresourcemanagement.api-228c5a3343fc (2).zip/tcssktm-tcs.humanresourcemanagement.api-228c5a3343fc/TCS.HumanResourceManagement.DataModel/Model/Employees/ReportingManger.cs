﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.DataModel.Model.Employees
{
    public class ReportingManger
    {
        public Guid Id { get; set; }

        public string EmployeeCode { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public bool IsActive { get; set; }

        public string Email { get; set; } = null;

        public string MobileNumber { get; set; }

        public string Designation { get; set; }

        public DateTime DateOfJoin { get; set; }
    }
}
