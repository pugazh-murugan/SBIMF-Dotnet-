﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.DataModel.Model.Jobs
{
    public class ViewSearchCandidates
    {

        public int ApplicationId { get; set; }

        public string Name { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfJoin { get; set; }

        public DateTime InterviewDate { get; set; }

        public string MobileNumber { get; set; }
    }
}
