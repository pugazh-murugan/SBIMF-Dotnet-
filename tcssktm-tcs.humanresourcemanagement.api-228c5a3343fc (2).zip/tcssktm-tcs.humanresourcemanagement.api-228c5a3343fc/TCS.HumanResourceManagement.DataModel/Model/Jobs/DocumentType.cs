﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model.Jobs
{
    public class DocumentType
    {
        public Guid Id { get; set; }

        public string Description { get; set; }
    }
}
