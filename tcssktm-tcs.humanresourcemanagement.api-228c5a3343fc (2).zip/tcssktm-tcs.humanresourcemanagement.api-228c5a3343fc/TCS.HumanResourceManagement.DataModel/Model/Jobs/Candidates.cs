﻿using System;
using System.Collections.Generic;
using TCS.HumanResourceManagement.DataModel.Model.Employees;

namespace TCS.HumanResourceManagement.DataModel.Model.Jobs
{
    public class Candidates : BaseEntity
    {
        public Candidates()
        {
            EmployeeAddresses = new EmployeeAddresses();
            EmployeeExperiences = new List<EmployeeExperiences>();
            EmployeeQualifications = new EmployeeQualifications();
            DependentDetails = new List<DependentDetails>();
        }

        public Guid Id { get; set; }

        public Guid Location { get; set; }

        public int ApplicationId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DateOfBirthInCertificate { get; set; }

        public DateTime DateOfBirthOriginal { get; set; }

        public int Age { get; set; }
        
        public string Gender { get; set; }

        public string Email { get; set; } = null;

        public string MobileNumber { get; set; }

        public string AlternateNumber { get; set; } = null;

        public string EmergencyContactNo { get; set; }

        public string PANNumber { get; set; }

        public string AadharNumber { get; set; }

        public string Avatar { get; set; } = null;

        public string BloodGroup { get; set; }

        public int TotalYearOfExperience { get; set; }

        public decimal? CurrentSalary { get; set; }

        public decimal ExpectedSalary { get; set; }

        public bool IsHostelRequired { get; set; }

        public DateTime InterviewDate { get; set; }

        public DateTime DateOfJoin { get; set; }

        public DateTime? WeddingDay { get; set; }

        public string Comments { get; set; }

        public EmployeeAddresses EmployeeAddresses { get; set; }

        public List<EmployeeExperiences> EmployeeExperiences { get; set; }

        public EmployeeQualifications EmployeeQualifications { get; set; }

        public List<DependentDetails> DependentDetails { get; set; }

    }
}
