﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Model
{
    public class BaseEntity
    {
        public Guid CreatedBy { get; set; }

        public DateTime Created { get; set; } = DateTime.Now;

        public Guid LastUpdatedBy { get; set; }

        public DateTime LastUpdated { get; set; } = DateTime.Now;
    }
}
