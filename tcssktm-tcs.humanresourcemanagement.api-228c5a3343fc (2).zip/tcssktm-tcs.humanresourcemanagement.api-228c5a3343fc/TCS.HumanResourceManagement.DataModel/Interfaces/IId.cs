﻿using System;

namespace TCS.HumanResourceManagement.DataModel.Interfaces
{
    public interface IId 
    {
        Guid Id { get; set; }
    }
}
