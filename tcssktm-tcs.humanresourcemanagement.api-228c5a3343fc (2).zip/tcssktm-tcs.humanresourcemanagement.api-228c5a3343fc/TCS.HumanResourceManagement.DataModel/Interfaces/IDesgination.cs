﻿namespace TCS.HumanResourceManagement.DataModel.Interfaces
{
    public interface IDesignation
    {
       string Designation { get; set; }
    }
}
