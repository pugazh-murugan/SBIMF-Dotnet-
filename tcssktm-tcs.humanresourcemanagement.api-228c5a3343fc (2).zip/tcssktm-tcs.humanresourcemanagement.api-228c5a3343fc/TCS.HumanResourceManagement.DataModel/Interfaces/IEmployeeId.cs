﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TCS.HumanResourceManagement.DataModel.Interfaces
{
    public interface IEmployeeId
    {
        Guid EmployeeId { get; set; }
    }
}
