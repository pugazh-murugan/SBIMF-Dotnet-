﻿using TCS.HumanResourceManagement.Business.Model;
using TinyCsvParser.Mapping;

namespace TCS.HumanResourceManagement.Api.Mapper
{
    public class UploadEmployeeDetailsCsvMapping : CsvMapping<UploadEmployeeDetails>
    {
        public UploadEmployeeDetailsCsvMapping() : base()
        {
            MapProperty(0, x => x.Branch);
            MapProperty(1, x => x.EmployeeCode);
            MapProperty(2, x => x.EmployeeName);
            MapProperty(3, x => x.Section);
            MapProperty(4, x => x.Designation);
            MapProperty(5, x => x.DateOfBirth);
            MapProperty(6, x => x.DateOfJoin);
            MapProperty(7, x => x.FatherName);
            MapProperty(8, x => x.Qualification);
            MapProperty(9, x => x.BloodGroup);
            MapProperty(10, x => x.Mobile);
            MapProperty(11, x => x.MaritalStatus);
        }
    }
}
