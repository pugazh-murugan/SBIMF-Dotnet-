﻿using TCS.HumanResourceManagement.Business.Model;
using TinyCsvParser.Mapping;

namespace TCS.HumanResourceManagement.Api.Mapper
{
    public class SalaryRevisionCsvMapping : CsvMapping<SalaryRevision>
    {
        public SalaryRevisionCsvMapping() : base()
        {
            MapProperty(0, x => x.EmployeeCode);
            MapProperty(1, x => x.Department);
            MapProperty(2, x => x.Designation);
            MapProperty(3, x => x.BasicSalary);
            MapProperty(4, x => x.HRA);
            MapProperty(5, x => x.PF);
            MapProperty(6, x => x.DA);
            MapProperty(7, x => x.SpecialAllowance);
            MapProperty(8, x => x.FoodAllowance);
            MapProperty(9, x => x.CarAllowance);
            MapProperty(10, x => x.MedicalAllowance);
            MapProperty(11, x => x.MobileAllowance);
        }
    }
}
