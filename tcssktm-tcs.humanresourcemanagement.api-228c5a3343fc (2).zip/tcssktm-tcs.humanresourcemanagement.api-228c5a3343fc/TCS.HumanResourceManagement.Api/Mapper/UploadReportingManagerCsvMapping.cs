﻿using TCS.HumanResourceManagement.Business.Model;
using TinyCsvParser.Mapping;

namespace TCS.HumanResourceManagement.Api.Mapper
{
    public class UploadReportingManagerCsvMapping : CsvMapping<UploadReportingManager>
    {
        public UploadReportingManagerCsvMapping() : base()
        {
            MapProperty(0, x => x.EmployeeCode);
            MapProperty(1, x => x.SupervisorCode);
            MapProperty(2, x => x.FloorHeadCode);
        }
    }
}
