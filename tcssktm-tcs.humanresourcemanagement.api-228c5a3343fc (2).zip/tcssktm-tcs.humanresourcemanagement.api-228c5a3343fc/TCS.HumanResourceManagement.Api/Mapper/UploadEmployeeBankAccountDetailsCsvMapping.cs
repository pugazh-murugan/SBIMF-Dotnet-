﻿using TCS.HumanResourceManagement.Business.Model;
using TinyCsvParser.Mapping;

namespace TCS.HumanResourceManagement.Api.Mapper
{
    public class UploadEmployeeBankAccountDetailsCsvMapping : CsvMapping<UploadEmployeeBankAccountDetails>
    {
        public UploadEmployeeBankAccountDetailsCsvMapping() : base()
        {
            MapProperty(0, x => x.EmployeeCode);
            MapProperty(1, x => x.AccountantName);
            MapProperty(2, x => x.AccountNumber);
            MapProperty(3, x => x.IfscCode);
            MapProperty(4, x => x.BankName);
            MapProperty(5, x => x.UanNumber);
        }
    }
}
