﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TCS.HumanResourceManagement.Business.Constants;
using MediatR;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using TinyCsvParser;
using TCS.HumanResourceManagement.Api.Mapper;
using System.Text;
using TCS.HumanResourceManagement.Api.Helper;
using TCS.HumanResourceManagement.Business.Model;
using TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeDetails;
using System.Net.Http;
using System.Net;
using System.Net.Http.Headers;
using TCS.HumanResourceManagement.Business.UploadData.UploadEmployeeBankAccountDetails;
using TCS.HumanResourceManagement.Business.UploadData.UploadReportingManager;
using TCS.HumanResourceManagement.Business.UploadData.EmployeeSalaryRevision;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = Policy.BearerOnly)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class UploadController : ControllerBase
    {
        private readonly IHostingEnvironment hostingEnvironment;

        private readonly IMediator mediator;

        private string folderName = "uploads";

        private string webRootPath = string.Empty;

        private string filePath = string.Empty;

        public UploadController(
            IMediator mediator,
            IHostingEnvironment hostingEnvironment)
        {
            this.mediator = mediator;
            this.hostingEnvironment = hostingEnvironment;
            webRootPath = hostingEnvironment.WebRootPath;
            webRootPath = Path.Combine(webRootPath, folderName);
        }

        [HttpPost, DisableRequestSizeLimit]
        [Route("uploademployeedetails")]
        public async Task<IActionResult> UploadEmployeeDetails()
        {
            Utility.CreateDirectory(webRootPath);
            filePath = Utility.FileUpload(Request, webRootPath);

            CsvParserOptions csvParserOptions = new CsvParserOptions(true, ',');
            var csvParser = new CsvParser<UploadEmployeeDetails>(csvParserOptions, new UploadEmployeeDetailsCsvMapping());
            var records = csvParser.ReadFromFile(filePath, Encoding.UTF8);

            var result = records.ToList();

            var uploadEmployeeDetails = result.Select(c => c.Result).ToList();

            var command = new UploadEmployeeDetailsCommand()
            {
                UploadEmployeeDetails = uploadEmployeeDetails
            };

            var response = await mediator.Send(command);

            return Ok(response);
        }

        [HttpPost, DisableRequestSizeLimit]
        [Route("uploademployeebanaccounts")]
        public async Task<IActionResult> UploadBankAcoounts()
        {
            Utility.CreateDirectory(webRootPath);
            filePath = Utility.FileUpload(Request, webRootPath);

            CsvParserOptions csvParserOptions = new CsvParserOptions(true, ',');
            var csvParser = new CsvParser<UploadEmployeeBankAccountDetails>(csvParserOptions, new UploadEmployeeBankAccountDetailsCsvMapping());
            var records = csvParser.ReadFromFile(filePath, Encoding.UTF8);

            var result = records.ToList();

            var uploadEmployeeAccounts = result.Select(c => c.Result).ToList();

            var command = new UploadEmployeeBankAccountDetailsCommand()
            {
                UploadEmployeeBankAccountDetails = uploadEmployeeAccounts
            };

            var response = await mediator.Send(command);

            return Ok(response);
        }

        [HttpPost, DisableRequestSizeLimit]
        [Route("uploadreportingmanager")]
        public async Task<IActionResult> UploadReportingManager()
        {
            Utility.CreateDirectory(webRootPath);
            filePath = Utility.FileUpload(Request, webRootPath);

            CsvParserOptions csvParserOptions = new CsvParserOptions(true, ',');
            var csvParser = new CsvParser<UploadReportingManager>(csvParserOptions, new UploadReportingManagerCsvMapping());
            var records = csvParser.ReadFromFile(filePath, Encoding.UTF8);

            var result = records.ToList();

            var uploadReportingManagers = result.Select(c => c.Result).ToList();

            var command = new UploadReportingManagerCommand()
            {
                UploadReportingManagers = uploadReportingManagers
            };

            var response = await mediator.Send(command);

            return Ok(response);
        }


        [HttpPost, DisableRequestSizeLimit]
        [Route("salaryrevision")]
        public async Task<IActionResult> SalaryRevision()
        {
            Utility.CreateDirectory(webRootPath);
            filePath = Utility.FileUpload(Request, webRootPath);

            CsvParserOptions csvParserOptions = new CsvParserOptions(true, ',');
            var csvParser = new CsvParser<SalaryRevision>(csvParserOptions, new SalaryRevisionCsvMapping());
            var records = csvParser.ReadFromFile(filePath, Encoding.UTF8);

            var result = records.ToList();

            var salaryRevisions = result.Select(c => c.Result).ToList();

            var command = new SalaryRevisionCommand()
            {
                SalaryRevisions = salaryRevisions
            };

            var response = await mediator.Send(command);

            return Ok(response);
        }


        [HttpGet]
        [Route("downloadtemplate")]
        public async Task<HttpResponseMessage> DownloadTemplate(string fileName)
        {
            var fileLocation = Path.Combine(hostingEnvironment.WebRootPath, "upload-templates");
            byte[] bytes = System.IO.File.ReadAllBytes(Path.Combine(fileLocation, fileName));

            //var stream = new FileStream(Path.Combine(fileLocation, fileName), FileMode.Open);
            ////return new FileStreamResult(stream, "application/vnd.ms-excel");

            //var dataBytes = System.IO.File.ReadAllBytes(Path.Combine(fileLocation, fileName));
            ////adding bytes to memory stream   
            //var dataStream = new MemoryStream(dataBytes);

            //HttpResponseMessage httpResponseMessage =Request. (HttpStatusCode.OK);
            //httpResponseMessage.Content = new StreamContent(dataStream);
            //httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
            //httpResponseMessage.Content.Headers.ContentDisposition.FileName = fileName;
            //httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

            //return httpResponseMessage;


            MemoryStream stream = new MemoryStream(bytes);

            HttpResponseMessage httpResponseMessage = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StreamContent(stream)
            };
            httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment")
            {
                FileName = fileName
            };
            httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/vnd.ms-excel");

            //ResponseMessageResult responseMessageResult = ResponseMessage(httpResponseMessage);
           
            return httpResponseMessage;


            // return File(bytes, "text/csv", fileName);
        }
    }
}