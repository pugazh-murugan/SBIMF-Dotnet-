﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using TCS.HumanResourceManagement.Business.Departments.AddNewDepartment;
using TCS.HumanResourceManagement.DataModel.Model.Departments;
using TCS.HumanResourceManagement.Business.Departments.GetAllDepartments;
using TCS.HumanResourceManagement.Business.Constants;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = Policy.BearerOnly)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class DepartmentController : ControllerBase
    {
        private readonly IMediator mediator;

        public DepartmentController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost]
        [Route("create")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> Create([FromBody] AddNewDepartmentCommand command)
        {
            await mediator.Send(command);
            return Ok(StatusCodes.Status201Created);
        }

        [HttpPost]
        [Route("getall")]
        //[ProducesResponseType(typeof(List<Departments>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAll([FromBody] GetAllDepartmentsQuery command)
        {
            var response = await mediator.Send(command);
            return Ok(response);
        }


    }
}
   
    
