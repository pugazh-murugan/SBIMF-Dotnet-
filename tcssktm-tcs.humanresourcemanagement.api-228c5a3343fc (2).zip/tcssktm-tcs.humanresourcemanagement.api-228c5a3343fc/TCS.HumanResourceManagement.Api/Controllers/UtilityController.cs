﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using TCS.HumanResourceManagement.Business.Utilities.AgeCalculatorByDateOfBirth;
using Microsoft.AspNetCore.Authorization;
using TCS.HumanResourceManagement.Business.Constants;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = Policy.BearerOnly)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class UtilityController : ControllerBase
    {
        private readonly IMediator mediator;

        public UtilityController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost]
        [Route("getagefromdateofbirth")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAgeFromDateOfBirth([FromBody] AgeCalculatorByDateOfBirthCommand command)
        {
            var response = await mediator.Send(command);
            return Ok(response);
        }


    }
}