﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.EmployeeTimeAndAttendance;
using TCS.HumanResourceManagement.Business.Constants;
using System;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.GetTimeAndAttendance;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.GetAttendanceSheet;
using TCS.HumanResourceManagement.DataModel.Model.TimeAndAttendance;
using System.Collections.Generic;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.OnDuty;
using TCS.HumanResourceManagement.Business.TimeAndAttendance.GetOnDuties;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class TimeAndAttendanceController : ControllerBase
    {
        private readonly IMediator mediator;

        public TimeAndAttendanceController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost]
        [Route("attendance")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Authorize(Policy = Policy.TerritoryTokenHolderOnly)]
        public async Task<IActionResult> Attendance([FromBody] EmployeeTimeAndAttendanceCommand command)
        {
            await mediator.Send(command);
            return Ok();
        }

        [HttpPost]
        [Route("manualattendance")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Authorize(Policy = Policy.BearerOnly)]
        public async Task<IActionResult> ManualAttendance([FromBody] EmployeeTimeAndAttendanceCommand command)
        {
            await mediator.Send(command);
            return Ok();
        }

        [HttpGet]
        [Route("viewtimeandattendance")]
        public async Task<IActionResult> ViewTimeAndAttendance([FromQuery] string employeeCode = null, DateTime? fromDate = null, DateTime? toDate = null, Guid? location = null, bool isSectionWise=false)
        {
            var query = new GetTimeAndAttendanceQuery()
            {
                EmployeeCode = employeeCode,
                FromDate = fromDate ?? DateTime.Now,
                ToDate = toDate ?? DateTime.Now,
                Location = location,
                IsSectionWise = isSectionWise
            };

            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("getattendancesheet")]
        [ProducesResponseType(typeof(List<AttendanceSheet>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAttendanceSheet([FromQuery] Guid? location = null)
        {
            var query = new GetAttendanceSheetQuery()
            {
                Branch = location,
            };

            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpPost]
        [Route("postonduties")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Authorize(Policy = Policy.BearerOnly)]
        public async Task<IActionResult> PostOnDuties([FromBody] OnDutyCommand command)
        {
            await mediator.Send(command);
            return Ok();
        }

        [HttpGet]
        [Route("getonduties")]
        [ProducesResponseType(typeof(List<OnDutiesViewModel>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetOnDuties([FromQuery] string employeeCode = null, DateTime? fromDate = null, DateTime? toDate = null, Guid? location = null)
        {
            var query = new GetOnDutiesQuery()
            {
                EmployeeCode = employeeCode,
                FromDate = fromDate ?? DateTime.Now,
                ToDate = toDate ?? DateTime.Now,
                Branch = location
            };

            var response = await mediator.Send(query);
            return Ok(response);
        }
    }
}