﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using TCS.HumanResourceManagement.Business.Employees.AddNewEmployee;
using TCS.HumanResourceManagement.Business.Employees.GetAllEmployees;
using Microsoft.AspNetCore.Authorization;
using TCS.HumanResourceManagement.Business.Employees.EmployeeAsReportingManager;
using TCS.HumanResourceManagement.Business.Constants;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeesByEmployeeCode;
using TCS.HumanResourceManagement.DataModel.Model.Employees;
using System;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeeAddreeses;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeeExperience;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeeSalaryDetails;
using TCS.HumanResourceManagement.Business.Employees.GetEmployeeById;
using TCS.HumanResourceManagement.Business.Employees.AssignReportingManagerByEmployee;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = Policy.BearerOnly)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class EmployeeController : ControllerBase
    {
        private readonly IMediator mediator;

        public EmployeeController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost]
        [Route("create")]
        [ProducesResponseType(StatusCodes.Status200OK)]

        public async Task<IActionResult> Create([FromBody] AddNewEmployeeCommand command)
        {
            var response = await mediator.Send(command);
            return Ok(response);
        }

        [HttpGet]
        [Route("getallemployees")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllEmployees()
        {
            var query = new GetAllEmployeeQuery();
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("employeeasreportingmanager")]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        public async Task<IActionResult> EmployeeAsReportingManager()
        {
            var response = await mediator.Send(new EmployeeAsReportingManagerQuery());
            return Ok(response);
        }

        [HttpGet]
        [Route("getemployeebyemployeecode/{employeeCode}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEmployeeByEmployeeCode([FromRoute] string employeeCode)
        {
            var query = new GetEmployeesByEmployeeCodeQuery() { EmployeeCode = employeeCode };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("getemployeebyid/{employeeId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEmployeeById([FromRoute] Guid employeeId)
        {
            var query = new GetEmployeeByIdQuery() { EmployeeId = employeeId };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("getemployeeaddresses/{employeeId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEmployeeAddresses([FromRoute] Guid employeeId)
        {
            var query = new GetEmployeeAddreesesQuery() { EmployeeId = employeeId };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("getemployeeexperience/{employeeId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEmployeeExperience([FromRoute] Guid employeeId)
        {
            var query = new GetEmployeeExperienceQuery() { EmployeeId = employeeId };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("getemployeesalarydetails/{employeeId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> GetEmployeeSalaryDetails([FromRoute] Guid employeeId)
        {
            var query = new GetEmployeeSalaryDetailsQuery() { EmployeeId = employeeId };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpPost]
        [Route("assignreportingmanager")]
        [ProducesResponseType(StatusCodes.Status202Accepted)]

        public async Task<IActionResult> AssignReportingManager([FromBody] AssignReportingManagerByEmployeeCommand command)
        {
            var response = await mediator.Send(command);
            return Ok(response);
        }

    }
}