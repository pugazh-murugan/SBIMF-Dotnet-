﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TCS.HumanResourceManagement.Business.Constants;
using TCS.HumanResourceManagement.Business.Designations.AddNewDesignation;
using TCS.HumanResourceManagement.Business.Designations.GetAllDesignations;
using TCS.HumanResourceManagement.DataModel.Model.Designations;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = Policy.BearerOnly)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class DesignationController : ControllerBase
    {
        private readonly IMediator mediator;

        public DesignationController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost]
        [Route("create")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> Create([FromBody] AddNewDesignationCommand command)
        {
            await mediator.Send(command);
            return Ok(StatusCodes.Status201Created);
        }

        [HttpGet]
        [Route("getall")]
        [ProducesResponseType(typeof(List<Designation>), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAll()
        {
            var response = await mediator.Send(new GetAllDesignationsQuery());
            return Ok(response);
        }
    }
}