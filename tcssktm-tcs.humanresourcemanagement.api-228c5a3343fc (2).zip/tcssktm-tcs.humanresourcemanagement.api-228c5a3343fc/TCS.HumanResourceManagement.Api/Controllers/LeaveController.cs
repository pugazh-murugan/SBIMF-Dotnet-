﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using TCS.HumanResourceManagement.Business.Leaves.ApplyLeave;
using TCS.HumanResourceManagement.Business.Leaves.ApproveOrRejectLeave;
using TCS.HumanResourceManagement.Business.Leaves.GetEmployeeLeavesById;
using TCS.HumanResourceManagement.DataModel.Model.Leaves;
using TCS.HumanResourceManagement.Business.Leaves.GetLeaveTypes;
using TCS.HumanResourceManagement.Business.Constants;
using TCS.HumanResourceManagement.Business.Leaves.GetAppliedLeaves;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = Policy.BearerOnly)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class LeaveController : ControllerBase
    {
        private readonly IMediator mediator;

        public LeaveController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost]
        [Route("applyleave")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult> ApplyLeave([FromBody] ApplyLeaveCommand command)
        {
            await mediator.Send(command);
            return Ok();
        }

        [HttpPut]
        [Route("approveorrejectleave")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult> ApproveOrRejectLeave([FromBody] ApproveOrRejectLeaveCommand command)
        {
            await mediator.Send(command);
            return Ok();
        }

        [HttpGet]
        [Route("{employeeCode}/getemployeeLeaves")]
        [ProducesResponseType(typeof(List<ViewEmployeeLeaves>), StatusCodes.Status200OK)]
        public async Task<ActionResult> GetEmployeeLeaves([FromRoute] string employeeCode)
        {
            var query = new GetEmployeeLeavesByIdQuery() { EmployeeCode = employeeCode };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("getallleavetypes")]
        [ProducesResponseType(typeof(List<LeaveTypes>), StatusCodes.Status200OK)]
        public async Task<ActionResult> GetAllLeaveTypes()
        {
            var response = await mediator.Send(new GetLeaveTypesQuery());
            return Ok(response);
        }

        [HttpGet]
        [Route("viewappliedleaves")]
        public async Task<IActionResult> ViewAppliedLeaves([FromQuery] string employeeCode = null, DateTime? fromDate = null, DateTime? toDate = null, bool? isApproved = null, Guid? approverId = null)
        {
            var query = new GetAppliedLeavesQuery()
            {
                EmployeeCode = employeeCode,
                FromDate = fromDate ?? DateTime.Now.Date,
                ToDate = toDate ?? DateTime.Now.Date,
                IsApproved = isApproved,
                ApproverId = approverId
            };
            var response = await mediator.Send(query);
            return Ok(response);
        }
    }
}