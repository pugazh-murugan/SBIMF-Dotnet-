﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using TCS.HumanResourceManagement.Business.Constants;
using TCS.HumanResourceManagement.Business.Jobs.AddNewCandidate;
using TCS.HumanResourceManagement.Business.Jobs.GetCandidates;
using TCS.HumanResourceManagement.Business.Jobs.CandidateSearch;
using TCS.HumanResourceManagement.Business.Jobs.GetCandidateByApplicationNumber;
using TCS.HumanResourceManagement.Business.Jobs.OnRollCandidate;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = Policy.BearerOnly)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class JobController : ControllerBase
    {
        private readonly IMediator mediator;

        public JobController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpPost]
        [Route("candidate")]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<IActionResult> CreateCandidate([FromBody] AddNewCandidateCommand command)
        {
            var response = await mediator.Send(command);
            return Ok(response);
        }

        [HttpGet]
        [Route("getcandidates")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ViewCandidate([FromQuery] int? applicationNumber=null,DateTime? interviewDate=null,Guid? location=null)
        {
            var query = new GetCandidatesQuery()
            {
                ApplicationNumber = applicationNumber,
                InterviewDate = interviewDate,
                Location = location
            };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("searchtext")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> SearchText([FromQuery] string searchText)
        {
            var query = new CandidateSearchQuery()
            {
                SearchText = searchText
            };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpGet]
        [Route("candidatebyapplicationnumber")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> CandidateByApplicationnumber([FromQuery] int applicationNumber)
        {
            var query = new GetCandidateByApplicationNumberCommand()
            {
                ApplicationNumber = applicationNumber
            };
            var response = await mediator.Send(query);
            return Ok(response);
        }

        [HttpPost]
        [Route("onroll")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> OnRoll([FromBody] OnRollCandidatecommand command)
        {
            var response = await mediator.Send(command);
            return Ok(response);
        }
    }
}