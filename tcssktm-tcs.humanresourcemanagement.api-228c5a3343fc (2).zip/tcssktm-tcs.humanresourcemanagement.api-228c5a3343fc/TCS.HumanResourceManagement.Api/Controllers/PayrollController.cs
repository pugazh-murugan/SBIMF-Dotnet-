﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TCS.HumanResourceManagement.Business.Constants;
using TCS.HumanResourceManagement.Business.Employees.EmployeePayroll;
using TCS.HumanResourceManagement.DataModel.Model.Payroll;

namespace TCS.HumanResourceManagement.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = Policy.BearerOnly)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public class PayrollController : ControllerBase
    {
        private readonly IMediator mediator;

        public PayrollController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        [Route("process")]
        [ProducesResponseType(typeof(List<PayrollProcessingViewModel>), StatusCodes.Status200OK)]
        public async Task<ActionResult> PayrollProcessing()
        {
            var response = await mediator.Send(new EmployeePayrollQuery());
            return Ok(response);
        }
    }
}