﻿using Microsoft.AspNetCore.Authorization;
using System.Linq;
using System.Threading.Tasks;
using TCS.HumanResourceManagement.Business.Constants;

namespace TCS.HumanResourceManagement.Api.Filters
{
    public class BearerTokenAttribute : AuthorizationHandler<BearerTokenAttribute>, IAuthorizationRequirement
    {
        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, BearerTokenAttribute requirement)
        {
            if (context.User.Identities.Any(x => x.AuthenticationType == AuthenticationConstants.ClaimsIdentityBearer && x.IsAuthenticated == true))
            {
                context.Succeed(requirement);
                await Task.CompletedTask;
                return;
            }
            await Task.CompletedTask;
            return;
        }
    }
}
