﻿using System.IdentityModel.Tokens.Jwt;

namespace TCS.HumanResourceManagement.Api.Validators
{
    public interface IJwtTokenValidator
    {
        JwtSecurityToken ValidateToken(string token);
    }
}
