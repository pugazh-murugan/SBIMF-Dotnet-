﻿using Microsoft.AspNetCore.Http;
using System;
using System.IO;
using System.Net.Http.Headers;

namespace TCS.HumanResourceManagement.Api.Helper
{
    public static class Utility
    {
        public static void CreateDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        public static void DeleteFile(string path)
        {
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }

        public static string FileUpload (HttpRequest request,string filePath)
        {
            var file = request.Form.Files[0];
            if (file.Length > 0)
            {
                string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                filePath = Path.Combine(filePath, string.Format("{0}_{1}", fileName, DateTime.Now.ToString("ddMMyyyhhMMss")));
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }

                return filePath;
            }
            else
            {
                return string.Empty;
            }

            
        }
    }
}
